import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component41.dart';
import 'xd_checkout_edit_card3.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_checkout_payments_pay_pal2.dart';
import 'xd_chat.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDBookIroning extends StatelessWidget {
  XDBookIroning({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -460.0, end: -81.0),
            Pin(size: 474.0, start: 95.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.0, end: 23.0),
            Pin(size: 69.2, middle: 0.1939),
            child: SvgPicture.string(
              _svg_ls1dav,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 20.0, end: 14.7),
                  Pin(size: 16.0, middle: 0.5357),
                  child:
                      // Adobe XD layer: 'status bar/light' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 24.3, end: 0.0),
                        Pin(start: 2.3, end: 2.3),
                        child:
                            // Adobe XD layer: 'Battery' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 2.3),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Border' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_i4lwc,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_hn,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.3, end: 0.0),
                              Pin(size: 4.0, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Cap' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tszyk4,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_w6qqk0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 18.0, start: 2.0),
                              Pin(size: 7.3, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Capacity' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_hy2fm,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_avi4k,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 15.3, end: 29.4),
                        Pin(size: 11.0, start: 2.3),
                        child:
                            // Adobe XD layer: 'Wifi' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Wifi' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tav08,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_iki5el,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 17.0, end: 49.7),
                        Pin(size: 10.7, middle: 0.5),
                        child:
                            // Adobe XD layer: 'Cellular Connection' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Cellular Connection' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_nqpuq1,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_n4r2,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 54.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Bars/_/Time Black' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Background' (shape)
                                  SvgPicture.string(
                                _svg_u6yej,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.8, end: 13.7),
                              Pin(size: 10.3, end: 0.8),
                              child:
                                  // Adobe XD layer: '↳ Time' (shape)
                                  SvgPicture.string(
                                _svg_snrsq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 225.0, start: 33.0),
            Pin(size: 45.0, middle: 0.2216),
            child: Text(
              'Kuzguncuk, 34674 Üsküdar/İstanbul\n',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xff383838),
                height: 1.8571428571428572,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 33.0),
            Pin(size: 12.0, middle: 0.1925),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 3,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 52.0, start: 51.0),
            Pin(size: 16.0, middle: 0.191),
            child: Text(
              'Service at',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                color: const Color(0x99383838),
                height: 2.1666666666666665,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 1.0, middle: 0.5027),
            Pin(size: 116.0, middle: 0.3147),
            child: SvgPicture.string(
              _svg_bozojd,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 44.0, start: 44.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDCheckoutEditCard3(),
                ),
              ],
              child: XDComponent41(),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 164.0, end: 79.0),
            child: SvgPicture.string(
              _svg_xcuq,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 84.0, end: 0.0),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_o4yqo0,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, end: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDCheckoutPaymentsPayPal2(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.0),
                        color: const Color(0xffff7f00),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 84.0, middle: 0.5161),
                    Pin(size: 14.0, middle: 0.5278),
                    child: Text(
                      'Request Now',
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 14,
                        color: const Color(0xffffffff),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, start: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Button' (shape)
                Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25.0),
                border: Border.all(width: 2.0, color: const Color(0xffffffff)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 100.0, start: 53.0),
            Pin(size: 14.0, end: 34.0),
            child: Text(
              'Cancel Request',
              style: TextStyle(
                fontFamily: 'SF Pro Text',
                fontSize: 14,
                color: const Color(0xffffffff),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.2, end: 5.5),
            Pin(size: 72.0, middle: 0.7878),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 62.0, middle: 0.2034),
                  Pin(size: 17.0, middle: 0.3818),
                  child: Text(
                    'Housewife',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      color: const Color(0xff898a8f),
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 22.0, middle: 0.18),
                  Pin(size: 17.0, middle: 0.7818),
                  child: Text(
                    '£ 10',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      color: const Color(0xff313450),
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 97.0, middle: 0.2295),
                  Pin(size: 20.0, start: 0.0),
                  child: Text(
                    'Zeynep Demir',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      color: const Color(0xff313450),
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, end: -1.0),
                  child: SvgPicture.string(
                    _svg_y6krt8,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 52.0, start: 22.0),
            Pin(size: 17.0, end: 96.0),
            child: Text(
              'Call Now',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 12,
                color: const Color(0xff898a8f),
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 72.0, middle: 0.3795),
            Pin(size: 17.0, end: 96.0),
            child: Text(
              'Share Detail',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 12,
                color: const Color(0xff898a8f),
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 29.0, middle: 0.659),
            Pin(size: 17.0, end: 96.0),
            child: Text(
              'Chat',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 12,
                color: const Color(0xff898a8f),
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 28.0),
            Pin(size: 17.0, end: 96.0),
            child: Text(
              'More',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 12,
                color: const Color(0xff898a8f),
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 26.4, start: 14.7),
            Pin(size: 11.0, middle: 0.7857),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 11.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '4.2',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 8,
                      color: const Color(0xff898a8f),
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 11.2, start: 0.0),
                  Pin(start: 0.2, end: 0.1),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_p3sot7,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 22.2, start: 37.0),
            Pin(size: 22.3, end: 121.7),
            child:
                // Adobe XD layer: 'telephone-2' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_j20hp,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 26.4, middle: 0.3982),
            Pin(size: 26.0, end: 120.0),
            child:
                // Adobe XD layer: 'share-lines' (shape)
                SvgPicture.string(
              _svg_lyfx2z,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.5164),
            Pin(size: 40.0, middle: 0.4301),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, start: 22.0),
            Pin(size: 35.0, middle: 0.4337),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, end: 54.0),
            Pin(size: 35.0, middle: 0.3398),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, middle: 0.2),
            Pin(size: 35.0, middle: 0.2741),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, middle: 0.2176),
            Pin(size: 35.0, middle: 0.6113),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, middle: 0.7382),
            Pin(size: 35.0, middle: 0.6564),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, middle: 0.4853),
            Pin(size: 35.0, middle: 0.5315),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 55.0, start: 4.0),
            Pin(size: 55.0, middle: 0.7596),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ls1dav =
    '<svg viewBox="24.0 144.0 328.0 69.2" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(1282.0, 144.0)" d="M -1106.000122070312 55.99980163574219 L -1251.999877929688 55.99980163574219 C -1255.313720703125 55.99980163574219 -1258.000244140625 53.31330108642578 -1258.000244140625 50.00040054321289 L -1258.000244140625 6.00029993057251 C -1258.000244140625 2.686500072479248 -1255.313720703125 0 -1251.999877929688 0 L -936 0 C -932.6862182617188 0 -929.9996948242188 2.686500072479248 -929.9996948242188 6.00029993057251 L -929.9996948242188 50.00040054321289 C -929.9996948242188 53.31330108642578 -932.6862182617188 55.99980163574219 -936 55.99980163574219 L -1081.999877929688 55.99980163574219 L -1094.499877929688 69.24960327148438 L -1106.000122070312 55.99980163574219 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_bozojd =
    '<svg viewBox="188.0 219.0 1.0 116.0" ><path transform="translate(188.0, 219.0)" d="M 0 0 L 0 116" fill="none" stroke="#022c43" stroke-width="2" stroke-dasharray="4 9" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_xcuq =
    '<svg viewBox="0.0 569.0 375.0 164.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="-1" stdDeviation="16"/></filter></defs><path transform="translate(0.0, 569.0)" d="M 0 0 L 375 0 L 375 164.0000152587891 L 0 164.0000152587891 L 0 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_o4yqo0 =
    '<svg viewBox="0.0 728.0 375.0 84.0" ><path transform="translate(0.0, 772.0)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 40.00000381469727 L 0 40.00000381469727 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_y6krt8 =
    '<svg viewBox="24.5 603.0 369.3 1.0" ><path transform="translate(-129.5, 547.0)" d="M 154.0000610351562 56 L 523.2966918945312 56" fill="none" stroke="#ececec" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_p3sot7 =
    '<svg viewBox="0.0 0.2 11.2 10.7" ><path transform="translate(0.0, -1.15)" d="M 5.619501113891602 1.317999958992004 L 7.355801105499268 4.836499691009521 L 11.23879432678223 5.400869846343994 L 8.429043769836426 8.139473915100098 L 9.09230899810791 12.0068187713623 L 5.619501113891602 10.1810131072998 L 2.146484851837158 12.0068187713623 L 2.809750556945801 8.139473915100098 L 0 5.400869846343994 L 3.882993221282959 4.836499691009521 L 5.619501113891602 1.317999958992004 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_j20hp =
    '<svg viewBox="0.0 0.0 22.2 22.3" ><path transform="translate(-0.91, 0.0)" d="M 5.409077167510986 14.80888652801514 C 7.606406688690186 17.43552780151367 10.25151252746582 19.50360488891602 13.27053546905518 20.96694946289062 C 14.41997909545898 21.51166725158691 15.95718765258789 22.15793800354004 17.66981315612793 22.26873207092285 C 17.77598571777344 22.27334594726562 17.87754440307617 22.27796363830566 17.98371696472168 22.27796363830566 C 19.1331615447998 22.27796363830566 20.05641174316406 21.88096809387207 20.80885887145996 21.06389617919922 C 20.81347465515137 21.05927848815918 20.82270431518555 21.05004501342773 20.82732391357422 21.04081344604492 C 21.09506416320801 20.71767616271973 21.39973831176758 20.42685127258301 21.71825981140137 20.1175651550293 C 21.93522071838379 19.90983390808105 22.15679931640625 19.69286918640137 22.36914825439453 19.47129249572754 C 23.3524055480957 18.44648551940918 23.3524055480957 17.14470481872559 22.35991477966309 16.15221405029297 L 19.58555221557617 13.37785530090332 C 19.11469459533691 12.8885326385498 18.55151176452637 12.63002395629883 17.96063232421875 12.63002395629883 C 17.3697566986084 12.63002395629883 16.80195999145508 12.8885326385498 16.31725311279297 13.37323760986328 L 14.66464138031006 15.02584934234619 C 14.51230525970459 14.93814277648926 14.35535049438477 14.85966777801514 14.20763206481934 14.78580665588379 C 14.02298069000244 14.69347953796387 13.85218143463135 14.60577201843262 13.6998462677002 14.50883102416992 C 12.19495010375977 13.55327033996582 10.82854270935059 12.30688190460205 9.522147178649902 10.70504760742188 C 8.862024307250977 9.869508743286133 8.418865203857422 9.167839050292969 8.109578132629395 8.452322006225586 C 8.543502807617188 8.059942245483398 8.949733734130859 7.649094581604004 9.34211254119873 7.247484683990479 C 9.48060131072998 7.104378700256348 9.623703956604004 6.961276054382324 9.766807556152344 6.818171977996826 C 10.26536178588867 6.319617748260498 10.53310298919678 5.742588043212891 10.53310298919678 5.156325817108154 C 10.53310298919678 4.570063591003418 10.26997852325439 3.993032932281494 9.766807556152344 3.494478702545166 L 8.391168594360352 2.118839263916016 C 8.229598999023438 1.957271337509155 8.077262878417969 1.800318956375122 7.92031192779541 1.638750314712524 C 7.615637302398682 1.324846029281616 7.297118186950684 1.00170910358429 6.983212947845459 0.7108858823776245 C 6.507740497589111 0.244645431637764 5.949175834655762 -1.52587872435106e-05 5.358297824859619 -1.52587872435106e-05 C 4.772034168243408 -1.52587872435106e-05 4.208853721618652 0.2446455061435699 3.714915990829468 0.7155023217201233 L 1.988440752029419 2.441976547241211 C 1.360631942749023 3.069784879684448 1.005181193351746 3.831464529037476 0.9313215017318726 4.713167190551758 C 0.8436129093170166 5.816449165344238 1.046727538108826 6.988973617553711 1.572978854179382 8.406159400939941 C 2.380822420120239 10.59887599945068 3.599510192871094 12.63463878631592 5.409077167510986 14.80888652801514 Z M 2.057685136795044 4.81010913848877 C 2.113080501556396 4.19614839553833 2.348508358001709 3.683745145797729 2.791668176651001 3.240586757659912 L 4.508910655975342 1.52334463596344 C 4.776651859283447 1.264835238456726 5.072091579437256 1.130964279174805 5.358298778533936 1.130964279174805 C 5.639889717102051 1.130964279174805 5.926095962524414 1.264835238456726 6.189221382141113 1.532577276229858 C 6.498508930206299 1.818784713745117 6.789332866668701 2.118840217590332 7.103236198425293 2.437360763549805 C 7.260188102722168 2.598929166793823 7.421757698059082 2.760497570037842 7.583324909210205 2.926682472229004 L 8.958966255187988 4.302322387695312 C 9.245172500610352 4.588528156280518 9.392891883850098 4.87935209274292 9.392891883850098 5.165558815002441 C 9.392891883850098 5.451765537261963 9.245172500610352 5.742588520050049 8.958966255187988 6.028796195983887 C 8.815861701965332 6.171899795532227 8.672759056091309 6.319617748260498 8.529654502868652 6.46272087097168 C 8.100345611572266 6.896647930145264 7.69873046875 7.307493209838867 7.255572319030762 7.699875354766846 C 7.246338844299316 7.709106922149658 7.24172306060791 7.713723659515381 7.232491493225098 7.722955703735352 C 6.849341869354248 8.10610294342041 6.909354209899902 8.470787048339844 7.001678943634033 8.747761726379395 C 7.006295680999756 8.761609077453613 7.010911464691162 8.770843505859375 7.015528202056885 8.78469181060791 C 7.370977401733398 9.63869571685791 7.864916324615479 10.4511547088623 8.635828018188477 11.42056655883789 C 10.0206995010376 13.12857532501221 11.4794340133667 14.45343589782715 13.08588218688965 15.47362899780273 C 13.28438282012939 15.60288047790527 13.49673175811768 15.70443916320801 13.69522953033447 15.80599498748779 C 13.87987613677979 15.89831924438477 14.05068016052246 15.9860315322876 14.20301818847656 16.08296966552734 C 14.22147846221924 16.09220314025879 14.23532962799072 16.1014347076416 14.25379467010498 16.11066818237305 C 14.4061279296875 16.18914604187012 14.55385112762451 16.22607612609863 14.70157241821289 16.22607612609863 C 15.07086849212646 16.22607612609863 15.31091594696045 15.99064922332764 15.38938999176025 15.9121732711792 L 17.11586761474609 14.18569850921631 C 17.38360404968262 13.9179573059082 17.6744327545166 13.77485370635986 17.96063232421875 13.77485370635986 C 18.31147003173828 13.77485370635986 18.59767723083496 13.99181652069092 18.77770805358887 14.18569850921631 L 21.56130218505859 16.96467399597168 C 22.1152515411377 17.51862144470215 22.11063575744629 18.11873245239258 21.54745292663574 18.70499801635742 C 21.35357093811035 18.91272735595703 21.15045928955078 19.11122703552246 20.93349456787109 19.31895637512207 C 20.61035919189453 19.63286018371582 20.27337646484375 19.95599937438965 19.96870231628418 20.32068252563477 C 19.43783187866211 20.89309692382812 18.80540657043457 21.16083717346191 17.98833847045898 21.16083717346191 C 17.90985870361328 21.16083717346191 17.82676696777344 21.15622138977051 17.74828910827637 21.1516056060791 C 16.23416519165039 21.05466461181641 14.82621002197266 20.46378898620605 13.76908874511719 19.96061706542969 C 10.89778804779053 18.57112693786621 8.377320289611816 16.5999927520752 6.286164283752441 14.09798908233643 C 4.564304828643799 12.02529811859131 3.40562891960144 10.09570789337158 2.63933277130127 8.027633666992188 C 2.163859128952026 6.758161067962646 1.983825445175171 5.737973213195801 2.057685136795044 4.81010913848877 Z" fill="#ff7f00" stroke="#ff7f00" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lyfx2z =
    '<svg viewBox="138.8 666.0 26.4 26.0" ><path transform="translate(136.78, 666.0)" d="M 6.956027984619141 8.030019760131836 C 8.329216957092285 8.030019760131836 9.569967269897461 8.587660789489746 10.46916198730469 9.486855506896973 C 10.67130661010742 9.689000129699707 10.85951042175293 9.912055969238281 11.02680110931396 10.14905261993408 L 18.86861801147461 6.886857032775879 C 18.61767959594727 6.294364929199219 18.4852409362793 5.64610767364502 18.4852409362793 4.969968795776367 C 18.4852409362793 3.596779823303223 19.04288101196289 2.356030225753784 19.94207763671875 1.456835269927979 C 20.84127044677734 0.5576402544975281 22.0820198059082 0 23.45520973205566 0 C 24.82839965820312 0 26.06914710998535 0.5576402544975281 26.96834564208984 1.456835269927979 C 27.8675422668457 2.356030225753784 28.4251823425293 3.596779823303223 28.4251823425293 4.969968795776367 C 28.4251823425293 6.343158721923828 27.8675422668457 7.583908081054688 26.96834564208984 8.483102798461914 C 26.06914710998535 9.382297515869141 24.82839965820312 9.939937591552734 23.45520973205566 9.939937591552734 C 22.0820198059082 9.939937591552734 20.84127044677734 9.382297515869141 19.94207763671875 8.483102798461914 C 19.78872489929199 8.329751968383789 19.6423454284668 8.162459373474121 19.5099048614502 7.988196849822998 L 11.61929416656494 11.27130317687988 C 11.82143974304199 11.80803298950195 11.93296718597412 12.39355564117432 11.93296718597412 12.99998950958252 C 11.93296718597412 13.37639713287354 11.89114475250244 13.73886394500732 11.81446933746338 14.09435749053955 L 19.69810676574707 17.78872489929199 C 19.7747859954834 17.6981086730957 19.85842895507812 17.60749244689941 19.94904708862305 17.51687431335449 C 20.84824180603027 16.6176815032959 22.08899116516113 16.06003952026367 23.46218299865723 16.06003952026367 C 24.83536720275879 16.06003952026367 26.07611846923828 16.6176815032959 26.97531509399414 17.51687431335449 C 27.87450790405273 18.41607093811035 28.43214988708496 19.65682029724121 28.43214988708496 21.03001022338867 C 28.43214988708496 22.4031982421875 27.87450790405273 23.64394760131836 26.97531509399414 24.54314231872559 C 26.07611846923828 25.44233894348145 24.83536720275879 25.99997901916504 23.46218299865723 25.99997901916504 C 22.08899116516113 25.99997901916504 20.84824180603027 25.44233894348145 19.94904708862305 24.54314231872559 C 19.04985237121582 23.64394760131836 18.49221038818359 22.4031982421875 18.49221038818359 21.03001022338867 C 18.49221038818359 20.24931335449219 18.67344284057617 19.50346755981445 19.00105857849121 18.84824180603027 L 11.38926792144775 15.2793436050415 C 11.15227127075195 15.73939800262451 10.8455696105957 16.15762519836426 10.48310375213623 16.51312255859375 C 9.583908081054688 17.41231727600098 8.343157768249512 17.96995735168457 6.969969749450684 17.96995735168457 C 5.596779823303223 17.96995735168457 4.356030464172363 17.41231727600098 3.456835269927979 16.51312255859375 C 2.557640314102173 15.61392784118652 2 14.37317848205566 2 12.99998950958252 C 2 11.62679862976074 2.557640314102173 10.3860502243042 3.456835269927979 9.486855506896973 C 4.356030464172363 8.587660789489746 5.596779823303223 8.030019760131836 6.969969749450684 8.030019760131836 L 6.956027984619141 8.030019760131836 Z M 26.06914710998535 2.349059581756592 C 25.39997863769531 1.679891228675842 24.47290420532227 1.261661171913147 23.44823837280273 1.261661171913147 C 22.42357444763184 1.261661171913147 21.49649810791016 1.679891228675842 20.82732963562012 2.349059581756592 C 20.15816307067871 3.018227815628052 19.73993110656738 3.945304870605469 19.73993110656738 4.969968795776367 C 19.73993110656738 5.994632720947266 20.15816307067871 6.921710014343262 20.82732963562012 7.590878009796143 C 21.49649810791016 8.26004695892334 22.42357444763184 8.678276062011719 23.44823837280273 8.678276062011719 C 24.47290420532227 8.678276062011719 25.39997863769531 8.26004695892334 26.06914710998535 7.590878009796143 C 26.73831748962402 6.921710014343262 27.15654945373535 5.994632720947266 27.15654945373535 4.969968795776367 C 27.15654945373535 3.945304870605469 26.73831748962402 3.018227815628052 26.06914710998535 2.349059581756592 Z M 26.06914710998535 18.40213012695312 C 25.39997863769531 17.73295974731445 24.47290420532227 17.31472969055176 23.44823837280273 17.31472969055176 C 22.42357444763184 17.31472969055176 21.49649810791016 17.73295974731445 20.82732963562012 18.40213012695312 C 20.15816307067871 19.07129859924316 19.73993110656738 19.99837303161621 19.73993110656738 21.02303695678711 C 19.73993110656738 22.04770088195801 20.15816307067871 22.97477722167969 20.82732963562012 23.64394760131836 C 21.49649810791016 24.3131160736084 22.42357444763184 24.73134613037109 23.44823837280273 24.73134613037109 C 24.47290420532227 24.73134613037109 25.39997863769531 24.3131160736084 26.06914710998535 23.64394760131836 C 26.73831748962402 22.97477722167969 27.15654945373535 22.04770088195801 27.15654945373535 21.02303695678711 C 27.15654945373535 19.99837303161621 26.73831748962402 19.07129859924316 26.06914710998535 18.40213012695312 Z M 9.576937675476074 10.37210941314697 C 8.907769203186035 9.702939987182617 7.980692386627197 9.284709930419922 6.956027984619141 9.284709930419922 C 5.931364059448242 9.284709930419922 5.004286766052246 9.702939987182617 4.335118770599365 10.37210941314697 C 3.665950298309326 11.0412769317627 3.247720241546631 11.96835517883301 3.247720241546631 12.99301815032959 C 3.247720241546631 14.01768207550049 3.665950298309326 14.94475746154785 4.335118770599365 15.61392784118652 C 5.004286766052246 16.2830982208252 5.931364059448242 16.70132637023926 6.956027984619141 16.70132637023926 C 7.980692386627197 16.70132637023926 8.907769203186035 16.2830982208252 9.576937675476074 15.61392784118652 C 10.24610614776611 14.94475746154785 10.66433620452881 14.01768207550049 10.66433620452881 12.99301815032959 C 10.66433620452881 11.96835517883301 10.24610614776611 11.0412769317627 9.576937675476074 10.37210941314697 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
