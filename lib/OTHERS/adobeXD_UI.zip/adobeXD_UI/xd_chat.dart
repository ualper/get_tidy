import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import 'xd_component21.dart';
import 'xd_chat1.dart';
import 'package:adobe_xd/page_link.dart';
import './xd_book_ironing.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDChat extends StatelessWidget {
  XDChat({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: SvgPicture.string(
              _svg_nn7ad,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 19.0, end: 17.0),
            Pin(size: 540.0, end: 93.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(36.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 7,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 20.0, end: 14.7),
                  Pin(size: 16.0, middle: 0.5357),
                  child:
                      // Adobe XD layer: 'status bar/light' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 24.3, end: 0.0),
                        Pin(start: 2.3, end: 2.3),
                        child:
                            // Adobe XD layer: 'Battery' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 2.3),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Border' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_i4lwc,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_hn,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.3, end: 0.0),
                              Pin(size: 4.0, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Cap' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tszyk4,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_w6qqk0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 18.0, start: 2.0),
                              Pin(size: 7.3, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Capacity' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_hy2fm,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_avi4k,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 15.3, end: 29.4),
                        Pin(size: 11.0, start: 2.3),
                        child:
                            // Adobe XD layer: 'Wifi' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Wifi' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tav08,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_iki5el,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 17.0, end: 49.7),
                        Pin(size: 10.7, middle: 0.5),
                        child:
                            // Adobe XD layer: 'Cellular Connection' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Cellular Connection' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_nqpuq1,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_n4r2,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 54.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Bars/_/Time Black' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Background' (shape)
                                  SvgPicture.string(
                                _svg_u6yej,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.8, end: 13.7),
                              Pin(size: 10.3, end: 0.8),
                              child:
                                  // Adobe XD layer: '↳ Time' (shape)
                                  SvgPicture.string(
                                _svg_snrsq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.5, end: 47.0),
            Pin(size: 127.0, middle: 0.2613),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 122.0, start: 0.0),
                  Pin(start: 0.0, end: 5.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 122.0, end: 0.0),
                  Pin(start: 5.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 265.0, start: 19.0),
            Pin(size: 60.0, start: 34.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 212.0, end: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: XDComponent21(),
                      ),
                      Pinned.fromPins(
                        Pin(size: 9.4, middle: 0.4912),
                        Pin(size: 8.5, start: 4.3),
                        child:
                            // Adobe XD layer: 'blob (1)' (shape)
                            SvgPicture.string(
                          _svg_azsewr,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 19.0, end: 17.0),
            Pin(start: 94.0, end: 27.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 12.0, end: 13.6),
                              Pin(size: 441.2, middle: 0.4363),
                              child: Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Message ' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 235.0, end: 1.4),
                                          Pin(size: 132.0, middle: 0.4108),
                                          child:
                                              // Adobe XD layer: 'Rectangle' (shape)
                                              SvgPicture.string(
                                            _svg_m04p2i,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 235.6, end: 0.0),
                                          Pin(size: 64.2, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'Rectangle Copy 2' (shape)
                                              SvgPicture.string(
                                            _svg_wnefp,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 45.4),
                                          Pin(size: 115.0, start: 0.0),
                                          child: Transform.rotate(
                                            angle: 3.1416,
                                            child:
                                                // Adobe XD layer: 'Rectangle Copy' (shape)
                                                Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(41.5),
                                                  bottomRight: Radius.circular(41.5),
                                                  bottomLeft: Radius.circular(41.5),
                                                ),
                                                color: const Color(0xfff4f6ff),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 45.4),
                                          Pin(size: 80.0, middle: 0.7614),
                                          child: Transform.rotate(
                                            angle: 3.1416,
                                            child:
                                                // Adobe XD layer: 'Rectangle Copy 3' (shape)
                                                Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(41.5),
                                                  bottomRight: Radius.circular(41.5),
                                                  bottomLeft: Radius.circular(41.5),
                                                ),
                                                color: const Color(0xfff4f6ff),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 201.0, end: 18.4),
                                          Pin(size: 89.0, middle: 0.4231),
                                          child:
                                              // Adobe XD layer: 'Hello Sayed! what’s' (text)
                                              Text(
                                            'Thanks Charlotte can you please send me a picture of the new Shower',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xffffffff),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 203.0, end: 6.4),
                                          Pin(size: 47.0, end: 8.2),
                                          child:
                                              // Adobe XD layer: 'Ohh sure! How is you' (text)
                                              Scrollbar(
                                            child: SingleChildScrollView(
                                              child: Text(
                                                'Thanks I am waiting for the picture to better advise you.\n\n ',
                                                style: TextStyle(
                                                  fontFamily: 'Arial',
                                                  fontSize: 14,
                                                  color: const Color(0xffffffff),
                                                  letterSpacing: 0.12999999809265136,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.7142857142857142,
                                                ),
                                                textHeightBehavior:
                                                    TextHeightBehavior(applyHeightToFirstAscent: false),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 27.0, end: 68.4),
                                          Pin(size: 97.0, start: 13.0),
                                          child:
                                              // Adobe XD layer: 'That ways we don’t b' (text)
                                              Text(
                                            'Hi my name is Charlotte and Purchased  a new Shower , so I want to new  Installation for it.',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xff4d5a80),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 36.0, end: 58.4),
                                          Pin(size: 43.0, middle: 0.7384),
                                          child:
                                              // Adobe XD layer: '$400 USD. You will d' (text)
                                              Text(
                                            'Yes I will send you a picture now.',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xff4d5a80),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.1053, endFraction: 0.8022),
                                          Pin(size: 24.0, middle: 0.4339),
                                          child:
                                              // Adobe XD layer: '12:10' (text)
                                              Text(
                                            '12:15\n',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.1053, endFraction: 0.8022),
                                          Pin(size: 12.0, middle: 0.939),
                                          child:
                                              // Adobe XD layer: '01:10' (text)
                                              Text(
                                            '01:12',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.8871, endFraction: 0.0204),
                                          Pin(size: 24.0, middle: 0.1103),
                                          child:
                                              // Adobe XD layer: '12:15' (text)
                                              Text(
                                            '12:10\n',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.8871, endFraction: 0.0172),
                                          Pin(size: 26.0, middle: 0.7443),
                                          child:
                                              // Adobe XD layer: '01:12' (text)
                                              Text(
                                            '01:10\n',
                                            style: TextStyle(
                                              fontFamily: 'Helvetica',
                                              fontSize: 12,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.11142856979370117,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 29.3, end: 11.7),
                              Pin(size: 29.3, start: 0.0),
                              child:
                                  // Adobe XD layer: 'baseline-duo-24px' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: SvgPicture.string(
                                      _svg_kx7cpj,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 282.0, end: 0.0),
                              Pin(size: 49.0, end: 0.0),
                              child: PageLink(
                                links: [
                                  PageLinkInfo(
                                    transition: LinkTransition.Fade,
                                    ease: Curves.easeOut,
                                    duration: 0.3,
                                    pageBuilder: () => XDChat1(),
                                  ),
                                ],
                                child: SvgPicture.string(
                                  _svg_io510,
                                  allowDrawingOutsideViewBox: true,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 116.0, middle: 0.3498),
                              Pin(size: 15.0, end: 17.0),
                              child: Text(
                                'Type message here',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 12,
                                  color: const Color(0xffc4c4c4),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 49.0, start: 0.0),
                              Pin(size: 49.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'upload_image' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                        color: const Color(0xffff7f00),
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 22.1, middle: 0.4825),
                                    Pin(size: 17.4, middle: 0.5057),
                                    child:
                                        // Adobe XD layer: 'camera (2)' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child: Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_vbumi6,
                                                        allowDrawingOutsideViewBox: true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(size: 10.3, middle: 0.5),
                                                      Pin(size: 10.3, end: 2.5),
                                                      child: SvgPicture.string(
                                                        _svg_lp1ix9,
                                                        allowDrawingOutsideViewBox: true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(size: 2.1, end: 2.5),
                                                      Pin(size: 2.1, middle: 0.2932),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.all(
                                                              Radius.elliptical(9999.0, 9999.0)),
                                                          color: const Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 96.0, middle: 0.4979),
                  Pin(size: 80.0, start: 3.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 19.0, end: 0.0),
                        child: Text(
                          'Sujen Matin',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 17,
                            color: const Color(0xffffffff),
                            fontWeight: FontWeight.w700,
                            height: 0.8823529411764706,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 17.0, end: 18.0),
                        Pin(size: 61.0, start: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(38.0),
                            image: DecorationImage(
                              image: const AssetImage(''),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 25.3, end: 30.3),
            Pin(size: 21.9, end: 39.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_tjds53,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_nn7ad =
    '<svg viewBox="0.0 0.0 375.0 812.0" ><path  d="M 0 0 L 375 0 L 375 812 L 0 812 L 0 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_azsewr =
    '<svg viewBox="99.5 4.3 9.4 8.5" ><path transform="translate(168.8, 61.01)" d="M -59.98715591430664 -54.07463455200195 C -59.54228591918945 -52.58687591552734 -60.56329345703125 -50.74176406860352 -62.18232345581055 -49.51655578613281 C -63.80864715576172 -48.29134368896484 -66.02569580078125 -47.67873764038086 -67.50616455078125 -48.6268196105957 C -68.98662567138672 -49.57489776611328 -69.73050689697266 -52.08366394042969 -69.05955505371094 -53.87772369384766 C -68.39590454101562 -55.66448974609375 -66.32470703125 -56.73654937744141 -64.333740234375 -56.70737838745117 C -62.34276962280273 -56.68550109863281 -60.43202209472656 -55.56239318847656 -59.98715591430664 -54.07463455200195 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_m04p2i =
    '<svg viewBox="77.4 129.8 235.0 132.0" ><path transform="translate(77.39, 129.81)" d="M 41.5 0 L 193.5 0 C 216.4198150634766 0 235 18.58018112182617 235 41.5 L 235 132 L 41.5 132 C 18.58018112182617 132 0 113.4198150634766 0 90.5 L 0 41.5 C 0 18.58018112182617 18.58018112182617 0 41.5 0 Z" fill="#115173" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_wnefp =
    '<svg viewBox="78.2 379.8 235.6 64.2" ><path transform="translate(78.22, 379.81)" d="M 32.08093643188477 0 L 203.4722290039062 0 C 221.1900482177734 0 235.5531768798828 14.36312389373779 235.5531768798828 32.08093643188477 L 235.5531768798828 64.16187286376953 L 32.08093643188477 64.16187286376953 C 14.36312389373779 64.16187286376953 0 49.79874801635742 0 32.08093643188477 C 0 14.36312389373779 14.36312389373779 0 32.08093643188477 0 Z" fill="#115173" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_kx7cpj =
    '<svg viewBox="0.0 0.0 29.3 29.3" ><path  d="M 0 0 L 29.333984375 0 L 29.333984375 29.333984375 L 0 29.333984375 L 0 0 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_io510 =
    '<svg viewBox="76.0 736.0 282.0 49.0" ><path transform="translate(76.0, 736.0)" d="M 24.5 0 L 257.5 0 C 271.0309753417969 0 282 10.96902275085449 282 24.5 C 282 38.03097534179688 271.0309753417969 49 257.5 49 L 24.5 49 C 10.96902275085449 49 0 38.03097534179688 0 24.5 C 0 10.96902275085449 10.96902275085449 0 24.5 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_vbumi6 =
    '<svg viewBox="0.0 0.0 22.1 17.4" ><path transform="translate(0.0, -44.8)" d="M 21.3242301940918 47.50484466552734 C 20.8839054107666 47.04355239868164 20.27584075927734 46.77097320556641 19.58390235900879 46.77097320556641 L 16.10325050354004 46.77097320556641 L 16.10325050354004 46.72903442382812 C 16.10325050354004 46.20484161376953 15.89357280731201 45.70161437988281 15.5371208190918 45.36612701416016 C 15.18066883087158 45.00967788696289 14.69841003417969 44.79999923706055 14.17421436309814 44.79999923706055 L 7.883877277374268 44.79999923706055 C 7.338715076446533 44.79999923706055 6.856455326080322 45.00967788696289 6.500003337860107 45.36612701416016 C 6.143550395965576 45.72257995605469 5.933872699737549 46.20484161376953 5.933872699737549 46.72903442382812 L 5.933872699737549 46.77097320556641 L 2.474187612533569 46.77097320556641 C 1.7822505235672 46.77097320556641 1.174184679985046 47.04355239868164 0.7338611483573914 47.50484466552734 C 0.2935376465320587 47.94516754150391 -1.1444091796875e-05 48.57420349121094 -1.1444091796875e-05 49.24517059326172 L -1.1444091796875e-05 59.68712615966797 C -1.084419818653259e-05 60.37906646728516 0.2725704312324524 60.98713684082031 0.7338617444038391 61.42745208740234 C 1.174185276031494 61.86777496337891 1.803218960762024 62.16133117675781 2.474188566207886 62.16133117675781 L 19.58390426635742 62.16133117675781 C 20.27584075927734 62.16133117675781 20.8839054107666 61.88874816894531 21.32423210144043 61.42745208740234 C 21.76455497741699 60.98713684082031 22.05810546875 60.35810089111328 22.05810546875 59.68712615966797 L 22.05810546875 49.24517059326172 C 22.05810356140137 48.55323028564453 21.78552055358887 47.94516754150391 21.3242301940918 47.50484466552734 Z M 20.9677791595459 59.68712615966797 L 20.94681167602539 59.68712615966797 C 20.94681167602539 60.06455230712891 20.80003547668457 60.40003204345703 20.54842376708984 60.65164184570312 C 20.29680824279785 60.90325927734375 19.96132278442383 61.05003356933594 19.58390426635742 61.05003356933594 L 2.474188566207886 61.05003356933594 C 2.096768140792847 61.05003356933594 1.761283278465271 60.90325927734375 1.509669899940491 60.65164184570312 C 1.258056402206421 60.40003204345703 1.111281991004944 60.06454467773438 1.111281991004944 59.68712615966797 L 1.111281991004944 49.24517059326172 C 1.111281991004944 48.86775207519531 1.258056402206421 48.53226470947266 1.509669899940491 48.2806510925293 C 1.761283397674561 48.02903747558594 2.096768140792847 47.88226318359375 2.474188566207886 47.88226318359375 L 6.520970821380615 47.88226318359375 C 6.835487842559814 47.88226318359375 7.087101459503174 47.63065338134766 7.087101459503174 47.31613540649414 L 7.087101459503174 46.70806884765625 C 7.087101459503174 46.47742080688477 7.170973300933838 46.26774597167969 7.317747116088867 46.12096786499023 C 7.464520454406738 45.97419738769531 7.674199104309082 45.89032363891602 7.904844760894775 45.89032363891602 L 14.17421436309814 45.89032363891602 C 14.40485954284668 45.89032363891602 14.61453723907471 45.97419738769531 14.76131248474121 46.12096786499023 C 14.9080867767334 46.26774597167969 14.99195861816406 46.47742462158203 14.99195861816406 46.70806884765625 L 14.99195861816406 47.31613159179688 C 14.99195861816406 47.63065338134766 15.24357128143311 47.88226318359375 15.55808925628662 47.88226318359375 L 19.60487174987793 47.88226318359375 C 19.98229217529297 47.88226318359375 20.31777763366699 48.02903747558594 20.56939125061035 48.2806510925293 C 20.82100296020508 48.53226470947266 20.9677791595459 48.86774826049805 20.9677791595459 49.24517059326172 L 20.9677791595459 59.68712615966797 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lp1ix9 =
    '<svg viewBox="5.9 4.5 10.3 10.3" ><path transform="translate(-106.13, -126.29)" d="M 117.1580581665039 130.8000030517578 C 115.7322463989258 130.8000030517578 114.4322509765625 131.3870849609375 113.5096664428711 132.3096771240234 C 112.5661163330078 133.2532348632812 111.9999847412109 134.5322723388672 111.9999847412109 135.9580688476562 C 111.9999847412109 137.3838806152344 112.5870819091797 138.6838836669922 113.5096664428711 139.6064758300781 C 114.4532089233398 140.5500183105469 115.7322463989258 141.1161499023438 117.1580581665039 141.1161499023438 C 118.583869934082 141.1161499023438 119.8838729858398 140.529052734375 120.8064575195312 139.6064758300781 C 121.75 138.6629180908203 122.3161392211914 137.3838806152344 122.3161392211914 135.9580688476562 C 122.3161392211914 134.5322723388672 121.7290420532227 133.2322692871094 120.8064575195312 132.3096771240234 C 119.8838729858398 131.3870849609375 118.583869934082 130.8000030517578 117.1580581665039 130.8000030517578 Z M 120.0096817016602 138.8306579589844 C 119.2758102416992 139.5435638427734 118.2693557739258 140.0048522949219 117.1580581665039 140.0048522949219 C 116.0467681884766 140.0048522949219 115.0403137207031 139.5435638427734 114.3064422607422 138.8306579589844 C 113.5725708007812 138.0967864990234 113.1322479248047 137.09033203125 113.1322479248047 135.9790344238281 C 113.1322479248047 134.8677520751953 113.5935363769531 133.8612976074219 114.3064422607422 133.1274261474609 C 115.0403137207031 132.3935546875 116.0467681884766 131.9532318115234 117.1580581665039 131.9532318115234 C 118.2693557739258 131.9532318115234 119.2758102416992 132.4145202636719 120.0096817016602 133.1274261474609 C 120.7435531616211 133.8612976074219 121.1838760375977 134.8677520751953 121.1838760375977 135.9790344238281 C 121.2048416137695 137.09033203125 120.7435531616211 138.0967864990234 120.0096817016602 138.8306579589844 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tjds53 =
    '<svg viewBox="-6.0 68.0 25.3 21.9" ><path transform="translate(-6.0, 32.89)" d="M 23.8277530670166 43.78146743774414 L 3.385984420776367 35.29932022094727 C 2.524804830551147 34.94194412231445 1.551889300346375 35.09915542602539 0.8469818830490112 35.70940017700195 C 0.1420744508504868 36.31974411010742 -0.1527544558048248 37.2601432800293 0.07764557003974915 38.1635856628418 L 1.897142887115479 45.29886245727539 L 10.80564785003662 45.29886245727539 C 11.21557807922363 45.29886245727539 11.54796504974365 45.63119888305664 11.54796504974365 46.04117584228516 C 11.54796504974365 46.45110702514648 11.21562671661377 46.78349685668945 10.80564785003662 46.78349685668945 L 1.897142887115479 46.78349685668945 L 0.07764557003974915 53.91872406005859 C -0.1527544558048248 54.82220840454102 0.1420249789953232 55.76261520385742 0.8469817638397217 56.37290954589844 C 1.553324222564697 56.98439025878906 2.526338815689087 57.13967132568359 3.386033773422241 56.78298568725586 L 23.82780265808105 48.3008918762207 C 24.75850677490234 47.91471481323242 25.33663558959961 47.04883193969727 25.33663558959961 46.04117584228516 C 25.33663558959961 45.03352355957031 24.75850677490234 44.16759490966797 23.8277530670166 43.78146743774414 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
