import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component41.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDRequestAccept3 extends StatelessWidget {
  XDRequestAccept3({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 287.0, start: 0.0),
            child: SvgPicture.string(
              _svg_qyqsi1,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.0, end: 23.0),
            Pin(size: 164.0, middle: 0.2778),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5.0),
                color: const Color(0x7affffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x14000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 34.0, end: 34.0),
            Pin(size: 186.0, middle: 0.2716),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5.0),
                color: const Color(0x45ffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x0b000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 14.0, end: 13.0),
            Pin(size: 188.0, middle: 0.3045),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.2478),
            Pin(size: 18.0, middle: 0.4106),
            child: Text(
              '3250',
              style: TextStyle(
                fontFamily: 'Microsoft YaHei UI',
                fontSize: 18,
                color: const Color(0xff022c43),
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 25.0, middle: 0.7143),
            Pin(size: 18.0, middle: 0.4106),
            child: Text(
              '2.5',
              style: TextStyle(
                fontFamily: 'Microsoft YaHei UI',
                fontSize: 18,
                color: const Color(0xff000000),
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 65.0, middle: 0.2419),
            Pin(size: 19.0, middle: 0.4351),
            child: Text(
              'Total Jobs',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0x78000000),
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 36.0, middle: 0.7227),
            Pin(size: 19.0, middle: 0.4351),
            child: Text(
              'Years',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0x78022c43),
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 14.5, end: 12.5),
            Pin(size: 1.0, middle: 0.3779),
            child: SvgPicture.string(
              _svg_vy0iv2,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 51.3, middle: 0.4859),
            Pin(size: 21.7, middle: 0.3033),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 21.0, end: 0.0),
                  Pin(start: 0.7, end: 0.0),
                  child: Text(
                    '4.2',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 15,
                      color: const Color(0xff898a8f),
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 22.1, start: 0.0),
                  Pin(start: 0.0, end: 0.7),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_ritbyw,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 106.0, middle: 0.5019),
            Pin(size: 29.0, middle: 0.3359),
            child: Text(
              'Ahmet Bey',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 22,
                color: const Color(0xff022c43),
                height: 1.6363636363636365,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 20.0, end: 14.7),
                  Pin(size: 16.0, middle: 0.5357),
                  child:
                      // Adobe XD layer: 'status bar/light' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 24.3, end: 0.0),
                        Pin(start: 2.3, end: 2.3),
                        child:
                            // Adobe XD layer: 'Battery' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 2.3),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Border' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_i4lwc,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_hn,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.3, end: 0.0),
                              Pin(size: 4.0, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Cap' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tszyk4,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_w6qqk0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 18.0, start: 2.0),
                              Pin(size: 7.3, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Capacity' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_hy2fm,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_avi4k,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 15.3, end: 29.4),
                        Pin(size: 11.0, start: 2.3),
                        child:
                            // Adobe XD layer: 'Wifi' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Wifi' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_tav08,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_iki5el,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 17.0, end: 49.7),
                        Pin(size: 10.7, middle: 0.5),
                        child:
                            // Adobe XD layer: 'Cellular Connection' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Cellular Connection' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: -5.0, end: -5.0),
                                    Pin(start: -5.0, end: -5.0),
                                    child:
                                        // Adobe XD layer: 'Fill' (shape)
                                        SvgPicture.string(
                                      _svg_nqpuq1,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Shape' (shape)
                                        SvgPicture.string(
                                      _svg_n4r2,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 54.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Bars/_/Time Black' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Background' (shape)
                                  SvgPicture.string(
                                _svg_u6yej,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.8, end: 13.7),
                              Pin(size: 10.3, end: 0.8),
                              child:
                                  // Adobe XD layer: '↳ Time' (shape)
                                  SvgPicture.string(
                                _svg_snrsq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 44.0, start: 44.0),
            child: XDComponent41(),
          ),
          Pinned.fromPins(
            Pin(size: 1.0, middle: 0.504),
            Pin(size: 71.0, middle: 0.4136),
            child: SvgPicture.string(
              _svg_tjmdb0,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 34.0, end: 34.4),
            Pin(size: 64.9, end: 36.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Service good,   ',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 12,
                      color: const Color(0xff9a9a9a),
                      height: 1.5833333333333333,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 34.0, start: 51.0),
            Pin(size: 12.0, end: 107.0),
            child: Text(
              'SIVAG',
              style: TextStyle(
                fontFamily: 'Microsoft YaHei UI',
                fontSize: 12,
                color: const Color(0xff000000),
                fontWeight: FontWeight.w300,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 20.0, start: 29.0),
            Pin(size: 20.0, end: 105.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 3.8, end: 3.7),
                  Pin(size: 16.6, end: 0.3),
                  child:
                      // Adobe XD layer: 'NoPath - Copy' (shape)
                      SvgPicture.string(
                    _svg_s3edwn,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                      color: const Color(0xffcecece),
                      border: Border.all(width: 1.0, color: const Color(0xff707070)),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 95.1, middle: 0.3287),
            Pin(size: 14.0, end: 108.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 15.1, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Favorites' (shape)
                      SvgPicture.string(
                    _svg_ryy2a1,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 15.1, middle: 0.25),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Favorites' (shape)
                      SvgPicture.string(
                    _svg_phm9v,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 15.1, middle: 0.5),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Favorites' (shape)
                      SvgPicture.string(
                    _svg_awi7i5,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 15.1, middle: 0.75),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Favorites' (shape)
                      SvgPicture.string(
                    _svg_nii1a5,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 15.1, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Favorites' (shape)
                      SvgPicture.string(
                    _svg_qo5qm2,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 17.0),
            Pin(size: 215.4, middle: 0.738),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.7, end: 1.2),
                  Pin(start: 0.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12.0),
                            color: const Color(0xfffcfcfc),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 24.2, end: 19.2),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.9),
                        Pin(size: 1.0, end: 31.8),
                        child: SvgPicture.string(
                          _svg_d252ty,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.9),
                        Pin(size: 1.0, middle: 0.4893),
                        child: SvgPicture.string(
                          _svg_z3hy3a,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.9, end: 0.0),
                        Pin(size: 1.0, start: 32.8),
                        child: SvgPicture.string(
                          _svg_bz0fiw,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 107.0, middle: 0.3272),
                        Pin(size: 13.0, start: 0.0),
                        child: Text(
                          '+91 931 488 2375',
                          style: TextStyle(
                            fontFamily: 'Proxima Nova Alt',
                            fontSize: 13,
                            color: const Color(0xff404040),
                            letterSpacing: 0.13,
                            height: 1.6153846153846154,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 100.0, middle: 0.3177),
                        Pin(size: 13.0, middle: 0.2704),
                        child: Text(
                          'Alex@getfix.com',
                          style: TextStyle(
                            fontFamily: 'Proxima Nova Alt',
                            fontSize: 13,
                            color: const Color(0xff404040),
                            letterSpacing: 0.13,
                            height: 1.6153846153846154,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 120.0, middle: 0.3465),
                        Pin(size: 13.0, middle: 0.6038),
                        child: Text(
                          'English and Apanish',
                          style: TextStyle(
                            fontFamily: 'Proxima Nova Alt',
                            fontSize: 13,
                            color: const Color(0xff404040),
                            letterSpacing: 0.13,
                            height: 1.6153846153846154,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 168.0, middle: 0.4426),
                        Pin(size: 13.0, end: 0.0),
                        child: Text(
                          'RM8 NL, PO3457, New York',
                          style: TextStyle(
                            fontFamily: 'Proxima Nova Alt',
                            fontSize: 13,
                            color: const Color(0xff404040),
                            letterSpacing: 0.13,
                            height: 1.6153846153846154,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 119.0, middle: 0.5),
            Pin(size: 119.0, start: 111.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_qyqsi1 =
    '<svg viewBox="0.0 0.0 375.0 287.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path  d="M 0 0 L 375 0 L 375 287 L 0 287 L 0 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_ritbyw =
    '<svg viewBox="0.0 0.3 22.1 21.0" ><path transform="translate(0.0, -0.98)" d="M 11.03089904785156 1.317999958992004 L 14.43920040130615 8.224700927734375 L 22.0613899230957 9.332541465759277 L 16.54594039916992 14.70833301544189 L 17.84790992736816 22.29980659484863 L 11.03089904785156 18.7158088684082 L 4.213480472564697 22.29980659484863 L 5.515449523925781 14.70833301544189 L 0 9.332541465759277 L 7.622190475463867 8.224700927734375 L 11.03089904785156 1.317999958992004 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_vy0iv2 =
    '<svg viewBox="14.5 306.5 348.0 1.0" ><path transform="translate(14.5, 306.5)" d="M 0 0 L 348 0" fill="none" fill-opacity="0.34" stroke="#a5a5a5" stroke-width="1" stroke-opacity="0.34" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tjmdb0 =
    '<svg viewBox="188.5 306.5 1.0 71.0" ><path transform="translate(188.5, 306.5)" d="M 0 0 L 0 71" fill="none" fill-opacity="0.34" stroke="#a5a5a5" stroke-width="1" stroke-opacity="0.34" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_s3edwn =
    '<svg viewBox="129.8 373.1 12.5 16.6" ><defs><pattern id="image" patternUnits="userSpaceOnUse" width="800.0" height="800.0"><image xlink:href="null" x="0" y="0" width="800.0" height="800.0" /></pattern></defs><path transform="translate(129.8, 373.11)" d="M 0 0 L 12.54164505004883 0 L 12.54164505004883 16.6114501953125 L 0 16.6114501953125 L 0 0 Z" fill="url(#image)" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ryy2a1 =
    '<svg viewBox="96.0 662.0 15.1 14.0" ><path transform="translate(86.0, 659.0)" d="M 20.06035804748535 7.887477874755859 C 19.79689788818359 7.888903617858887 19.56216621398926 7.723835945129395 19.47795104980469 7.477917671203613 L 18.12086486816406 3.410040855407715 C 18.03565979003906 3.164781093597412 17.80160903930664 3 17.53845977783203 3 C 17.27530670166016 3 17.041259765625 3.164781093597412 16.9560546875 3.410040855407715 L 15.59896564483643 7.477917671203613 C 15.51475143432617 7.723835945129395 15.28002166748047 7.888903617858887 15.01655864715576 7.887477874755859 L 10.61089897155762 7.887477874755859 C 10.3491325378418 7.881691932678223 10.11404037475586 8.044477462768555 10.03093528747559 8.289065361022949 C 9.947830200195312 8.533653259277344 10.03607654571533 8.803047180175781 10.24863624572754 8.953652381896973 L 13.82388210296631 11.48403072357178 C 14.03512382507324 11.63181114196777 14.12430763244629 11.89770889282227 14.04402542114258 12.14037132263184 L 12.68136405944824 16.22636413574219 C 12.62280082702637 16.40863227844238 12.65682506561279 16.60752105712891 12.77279186248779 16.76081466674805 C 12.88875961303711 16.91411018371582 13.07250881195068 17.00308799743652 13.26655578613281 16.99991798400879 C 13.39595699310303 16.99932289123535 13.52182674407959 16.95828056335449 13.62603092193604 16.88270378112793 L 17.17619705200195 14.37044239044189 C 17.39285850524902 14.21782779693604 17.68405914306641 14.21782779693604 17.90072250366211 14.37044239044189 L 21.45088577270508 16.88270378112793 C 21.55509185791016 16.95828056335449 21.68095970153809 16.99932289123535 21.81036186218262 16.99991798400879 C 22.0044116973877 17.00308799743652 22.18815994262695 16.91411018371582 22.30412864685059 16.76081466674805 C 22.42009353637695 16.60752105712891 22.4541187286377 16.40863227844238 22.39555549621582 16.22636413574219 L 21.03289222717285 12.14037132263184 C 20.95261001586914 11.89770889282227 21.04179573059082 11.63181114196777 21.2530345916748 11.48403072357178 L 24.82828140258789 8.953652381896973 C 25.04084205627441 8.803047180175781 25.12908935546875 8.533653259277344 25.04598426818848 8.289065361022949 C 24.96287727355957 8.044477462768555 24.72778701782227 7.881691932678223 24.46602058410645 7.887477874755859 L 20.06035804748535 7.887477874755859 Z" fill="#ff9500" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_phm9v =
    '<svg viewBox="116.0 662.0 15.1 14.0" ><path transform="translate(106.0, 659.0)" d="M 20.06035804748535 7.887477874755859 C 19.79689788818359 7.888903617858887 19.56216621398926 7.723835945129395 19.47795104980469 7.477917671203613 L 18.12086486816406 3.410040855407715 C 18.03565979003906 3.164781093597412 17.80160903930664 3 17.53845977783203 3 C 17.27530670166016 3 17.041259765625 3.164781093597412 16.9560546875 3.410040855407715 L 15.59896564483643 7.477917671203613 C 15.51475143432617 7.723835945129395 15.28002166748047 7.888903617858887 15.01655864715576 7.887477874755859 L 10.61089897155762 7.887477874755859 C 10.3491325378418 7.881691932678223 10.11404037475586 8.044477462768555 10.03093528747559 8.289065361022949 C 9.947830200195312 8.533653259277344 10.03607654571533 8.803047180175781 10.24863624572754 8.953652381896973 L 13.82388210296631 11.48403072357178 C 14.03512382507324 11.63181114196777 14.12430763244629 11.89770889282227 14.04402542114258 12.14037132263184 L 12.68136405944824 16.22636413574219 C 12.62280082702637 16.40863227844238 12.65682506561279 16.60752105712891 12.77279186248779 16.76081466674805 C 12.88875961303711 16.91411018371582 13.07250881195068 17.00308799743652 13.26655578613281 16.99991798400879 C 13.39595699310303 16.99932289123535 13.52182674407959 16.95828056335449 13.62603092193604 16.88270378112793 L 17.17619705200195 14.37044239044189 C 17.39285850524902 14.21782779693604 17.68405914306641 14.21782779693604 17.90072250366211 14.37044239044189 L 21.45088577270508 16.88270378112793 C 21.55509185791016 16.95828056335449 21.68095970153809 16.99932289123535 21.81036186218262 16.99991798400879 C 22.0044116973877 17.00308799743652 22.18815994262695 16.91411018371582 22.30412864685059 16.76081466674805 C 22.42009353637695 16.60752105712891 22.4541187286377 16.40863227844238 22.39555549621582 16.22636413574219 L 21.03289222717285 12.14037132263184 C 20.95261001586914 11.89770889282227 21.04179573059082 11.63181114196777 21.2530345916748 11.48403072357178 L 24.82828140258789 8.953652381896973 C 25.04084205627441 8.803047180175781 25.12908935546875 8.533653259277344 25.04598426818848 8.289065361022949 C 24.96287727355957 8.044477462768555 24.72778701782227 7.881691932678223 24.46602058410645 7.887477874755859 L 20.06035804748535 7.887477874755859 Z" fill="#ff9500" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_awi7i5 =
    '<svg viewBox="136.0 662.0 15.1 14.0" ><path transform="translate(126.0, 659.0)" d="M 20.06035804748535 7.887477874755859 C 19.79689788818359 7.888903617858887 19.56216621398926 7.723835945129395 19.47795104980469 7.477917671203613 L 18.12086486816406 3.410040855407715 C 18.03565979003906 3.164781093597412 17.80160903930664 3 17.53845977783203 3 C 17.27530670166016 3 17.041259765625 3.164781093597412 16.9560546875 3.410040855407715 L 15.59896564483643 7.477917671203613 C 15.51475143432617 7.723835945129395 15.28002166748047 7.888903617858887 15.01655864715576 7.887477874755859 L 10.61089897155762 7.887477874755859 C 10.3491325378418 7.881691932678223 10.11404037475586 8.044477462768555 10.03093528747559 8.289065361022949 C 9.947830200195312 8.533653259277344 10.03607654571533 8.803047180175781 10.24863624572754 8.953652381896973 L 13.82388210296631 11.48403072357178 C 14.03512382507324 11.63181114196777 14.12430763244629 11.89770889282227 14.04402542114258 12.14037132263184 L 12.68136405944824 16.22636413574219 C 12.62280082702637 16.40863227844238 12.65682506561279 16.60752105712891 12.77279186248779 16.76081466674805 C 12.88875961303711 16.91411018371582 13.07250881195068 17.00308799743652 13.26655578613281 16.99991798400879 C 13.39595699310303 16.99932289123535 13.52182674407959 16.95828056335449 13.62603092193604 16.88270378112793 L 17.17619705200195 14.37044239044189 C 17.39285850524902 14.21782779693604 17.68405914306641 14.21782779693604 17.90072250366211 14.37044239044189 L 21.45088577270508 16.88270378112793 C 21.55509185791016 16.95828056335449 21.68095970153809 16.99932289123535 21.81036186218262 16.99991798400879 C 22.0044116973877 17.00308799743652 22.18815994262695 16.91411018371582 22.30412864685059 16.76081466674805 C 22.42009353637695 16.60752105712891 22.4541187286377 16.40863227844238 22.39555549621582 16.22636413574219 L 21.03289222717285 12.14037132263184 C 20.95261001586914 11.89770889282227 21.04179573059082 11.63181114196777 21.2530345916748 11.48403072357178 L 24.82828140258789 8.953652381896973 C 25.04084205627441 8.803047180175781 25.12908935546875 8.533653259277344 25.04598426818848 8.289065361022949 C 24.96287727355957 8.044477462768555 24.72778701782227 7.881691932678223 24.46602058410645 7.887477874755859 L 20.06035804748535 7.887477874755859 Z" fill="#ff9500" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nii1a5 =
    '<svg viewBox="156.0 662.0 15.1 14.0" ><path transform="translate(146.0, 659.0)" d="M 20.06035804748535 7.887477874755859 C 19.79689788818359 7.888903617858887 19.56216621398926 7.723835945129395 19.47795104980469 7.477917671203613 L 18.12086486816406 3.410040855407715 C 18.03565979003906 3.164781093597412 17.80160903930664 3 17.53845977783203 3 C 17.27530670166016 3 17.041259765625 3.164781093597412 16.9560546875 3.410040855407715 L 15.59896564483643 7.477917671203613 C 15.51475143432617 7.723835945129395 15.28002166748047 7.888903617858887 15.01655864715576 7.887477874755859 L 10.61089897155762 7.887477874755859 C 10.3491325378418 7.881691932678223 10.11404037475586 8.044477462768555 10.03093528747559 8.289065361022949 C 9.947830200195312 8.533653259277344 10.03607654571533 8.803047180175781 10.24863624572754 8.953652381896973 L 13.82388210296631 11.48403072357178 C 14.03512382507324 11.63181114196777 14.12430763244629 11.89770889282227 14.04402542114258 12.14037132263184 L 12.68136405944824 16.22636413574219 C 12.62280082702637 16.40863227844238 12.65682506561279 16.60752105712891 12.77279186248779 16.76081466674805 C 12.88875961303711 16.91411018371582 13.07250881195068 17.00308799743652 13.26655578613281 16.99991798400879 C 13.39595699310303 16.99932289123535 13.52182674407959 16.95828056335449 13.62603092193604 16.88270378112793 L 17.17619705200195 14.37044239044189 C 17.39285850524902 14.21782779693604 17.68405914306641 14.21782779693604 17.90072250366211 14.37044239044189 L 21.45088577270508 16.88270378112793 C 21.55509185791016 16.95828056335449 21.68095970153809 16.99932289123535 21.81036186218262 16.99991798400879 C 22.0044116973877 17.00308799743652 22.18815994262695 16.91411018371582 22.30412864685059 16.76081466674805 C 22.42009353637695 16.60752105712891 22.4541187286377 16.40863227844238 22.39555549621582 16.22636413574219 L 21.03289222717285 12.14037132263184 C 20.95261001586914 11.89770889282227 21.04179573059082 11.63181114196777 21.2530345916748 11.48403072357178 L 24.82828140258789 8.953652381896973 C 25.04084205627441 8.803047180175781 25.12908935546875 8.533653259277344 25.04598426818848 8.289065361022949 C 24.96287727355957 8.044477462768555 24.72778701782227 7.881691932678223 24.46602058410645 7.887477874755859 L 20.06035804748535 7.887477874755859 Z" fill="#ff9500" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_qo5qm2 =
    '<svg viewBox="176.0 662.0 15.1 14.0" ><path transform="translate(166.0, 659.0)" d="M 20.06035804748535 7.887477874755859 C 19.79689788818359 7.888903617858887 19.56216621398926 7.723835945129395 19.47795104980469 7.477917671203613 L 18.12086486816406 3.410040855407715 C 18.03565979003906 3.164781093597412 17.80160903930664 3 17.53845977783203 3 C 17.27530670166016 3 17.041259765625 3.164781093597412 16.9560546875 3.410040855407715 L 15.59896564483643 7.477917671203613 C 15.51475143432617 7.723835945129395 15.28002166748047 7.888903617858887 15.01655864715576 7.887477874755859 L 10.61089897155762 7.887477874755859 C 10.3491325378418 7.881691932678223 10.11404037475586 8.044477462768555 10.03093528747559 8.289065361022949 C 9.947830200195312 8.533653259277344 10.03607654571533 8.803047180175781 10.24863624572754 8.953652381896973 L 13.82388210296631 11.48403072357178 C 14.03512382507324 11.63181114196777 14.12430763244629 11.89770889282227 14.04402542114258 12.14037132263184 L 12.68136405944824 16.22636413574219 C 12.62280082702637 16.40863227844238 12.65682506561279 16.60752105712891 12.77279186248779 16.76081466674805 C 12.88875961303711 16.91411018371582 13.07250881195068 17.00308799743652 13.26655578613281 16.99991798400879 C 13.39595699310303 16.99932289123535 13.52182674407959 16.95828056335449 13.62603092193604 16.88270378112793 L 17.17619705200195 14.37044239044189 C 17.39285850524902 14.21782779693604 17.68405914306641 14.21782779693604 17.90072250366211 14.37044239044189 L 21.45088577270508 16.88270378112793 C 21.55509185791016 16.95828056335449 21.68095970153809 16.99932289123535 21.81036186218262 16.99991798400879 C 22.0044116973877 17.00308799743652 22.18815994262695 16.91411018371582 22.30412864685059 16.76081466674805 C 22.42009353637695 16.60752105712891 22.4541187286377 16.40863227844238 22.39555549621582 16.22636413574219 L 21.03289222717285 12.14037132263184 C 20.95261001586914 11.89770889282227 21.04179573059082 11.63181114196777 21.2530345916748 11.48403072357178 L 24.82828140258789 8.953652381896973 C 25.04084205627441 8.803047180175781 25.12908935546875 8.533653259277344 25.04598426818848 8.289065361022949 C 24.96287727355957 8.044477462768555 24.72778701782227 7.881691932678223 24.46602058410645 7.887477874755859 L 20.06035804748535 7.887477874755859 Z" fill="#d9d9d9" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_d252ty =
    '<svg viewBox="-146.4 440.8 340.1 1.0" ><path transform="translate(-146.4, 440.84)" d="M 0 0 L 340.1213073730469 0" fill="none" fill-opacity="0.1" stroke="#707070" stroke-width="1" stroke-opacity="0.1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_z3hy3a =
    '<svg viewBox="-146.4 385.3 340.1 1.0" ><path transform="translate(-146.4, 385.34)" d="M 0 0 L 340.1213073730469 0" fill="none" fill-opacity="0.1" stroke="#707070" stroke-width="1" stroke-opacity="0.1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_bz0fiw =
    '<svg viewBox="-145.5 334.5 340.1 1.0" ><path transform="translate(-145.49, 334.49)" d="M 0 0 L 340.1213073730469 0" fill="none" fill-opacity="0.1" stroke="#707070" stroke-width="1" stroke-opacity="0.1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
