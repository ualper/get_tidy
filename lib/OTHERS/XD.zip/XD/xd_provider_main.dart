import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import 'xd_icon_arrow_left.dart';
import 'xd_home_chose_service_provider.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_component_avatar.dart';
import 'xd_component281.dart';
import 'xd_component291.dart';
import 'xd_component_mesage.dart';
import 'xd_comp_tidy.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDProviderMain extends StatelessWidget {
  XDProviderMain({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: SvgPicture.string(
              _svg_nn7ad,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.5, end: 48.0),
            Pin(size: 127.0, middle: 0.3328),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 122.0, start: 0.0),
                  Pin(start: 0.0, end: 5.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 122.0, end: 0.0),
                  Pin(start: 5.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 44.0, end: 15.0),
            Pin(start: 44.0, end: 724.0),
            child:
                // Adobe XD layer: 'icon-arrow-left' (component)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDHomeChoseServiceProvider(),
                ),
              ],
              child: XDIconArrowLeft(),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 18.0, end: 18.0),
            Pin(start: 113.0, end: 44.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 426.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(36.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 1),
                          blurRadius: 7,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 104.0, middle: 0.5021),
                  Pin(size: 90.0, start: 0.0),
                  child: XDcomponent_avatar(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 56.0, middle: 0.4875),
                  child: XDComponent281(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 55.0, middle: 0.6083),
                  child: XDComponent291(),
                ),
                Pinned.fromPins(
                  Pin(size: 86.0, middle: 0.502),
                  Pin(size: 77.0, middle: 0.1886),
                  child: XDcomponent_mesage(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 56.0, middle: 0.7295),
                  child: XDComponent281(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 55.0, end: 90.0),
                  child: XDComponent291(),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.5, end: 21.5),
            Pin(size: 81.7, start: 25.2),
            child: XDcomp_tidy(),
          ),
        ],
      ),
    );
  }
}

const String _svg_nn7ad =
    '<svg viewBox="0.0 0.0 375.0 812.0" ><path  d="M 0 0 L 375 0 L 375 812 L 0 812 L 0 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
