import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component21.dart';
import 'xd_vetx_verify_success.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDVetxVerifySuccess2 extends StatelessWidget {
  XDVetxVerifySuccess2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -60.6, end: -167.8),
            Pin(size: 200.6, middle: 0.6942),
            child: SvgPicture.string(
              _svg_owlr05,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: -60.6, end: -167.8),
            Pin(size: 356.4, middle: 0.4127),
            child: SvgPicture.string(
              _svg_sdjxnv,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 16.0, start: 17.0),
            Pin(size: 16.0, start: 51.0),
            child:
                // Adobe XD layer: 'ic_arrow_forward_24…' (shape)
                SvgPicture.string(
              _svg_xweay0,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 43.0, end: 35.0),
            Pin(size: 99.0, start: 40.0),
            child: XDComponent21(),
          ),
          Pinned.fromPins(
            Pin(start: 23.0, end: 33.0),
            Pin(size: 131.0, middle: 0.4934),
            child: SvgPicture.string(
              _svg_b53q9,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 21.1, middle: 0.6701),
            Pin(size: 19.2, start: 47.8),
            child:
                // Adobe XD layer: 'blob (1)' (shape)
                SvgPicture.string(
              _svg_x9xr4e,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 260.0, start: 48.0),
            Pin(size: 95.0, middle: 0.4937),
            child:
                // Adobe XD layer: 'At least 8 character' (text)
                Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 17,
                  color: const Color(0xff1d1d1d),
                  height: 1.411764705882353,
                ),
                children: [
                  TextSpan(
                    text: 'Please enter the 4 digit verification\nCode sent to your cell number\n',
                  ),
                  TextSpan(
                    text: '555 555 5555 ',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: ' via SMS message\nor ',
                  ),
                  TextSpan(
                    text: 'CHANGE',
                    style: TextStyle(
                      color: const Color(0xffff7f00),
                      fontWeight: FontWeight.w700,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  TextSpan(
                    text: ' your number.',
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 47.0, end: 47.0),
            Pin(size: 58.0, middle: 0.6393),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 58.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 58.0, middle: 0.3318),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 58.0, middle: 0.6682),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 58.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 82.0, middle: 0.4983),
            Pin(size: 19.0, middle: 0.7024),
            child: Text(
              'Resend OTP',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xff022c43),
                letterSpacing: 0.7000000000000001,
                fontWeight: FontWeight.w500,
                decoration: TextDecoration.underline,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 211.0, start: 47.3),
            Pin(size: 71.0, middle: 0.3428),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 27,
                  color: const Color(0xffffffff),
                  height: 1.3333333333333333,
                ),
                children: [
                  TextSpan(
                    text: 'Please verify\nyour ',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'Cell Number',
                    style: TextStyle(
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_owlr05 =
    '<svg viewBox="-60.6 424.4 603.4 200.6" ><path transform="translate(-333.48, 114.3)" d="M 875.9535522460938 310.1129455566406 L 334.1761474609375 311.7389526367188 C 313.4140014648438 318.7294006347656 297.2854614257812 330.2019958496094 291.9845581054688 343.5234375 C 283.84326171875 363.9826049804688 298.9574584960938 385.8193054199219 289.5859375 406.1090393066406 C 286.208984375 413.4234924316406 279.7791748046875 420.1817626953125 275.9049072265625 427.4171447753906 C 272.0305786132812 434.6506042480469 270.9998168945312 442.9300231933594 278.0023803710938 449.3771057128906 C 288.9806518554688 459.4888916015625 313.7314453125 460.840576171875 331.6793823242188 467.0354614257812 C 349.9612426757812 473.3462524414062 360.6318969726562 484.5481567382812 373.7599487304688 494.0908813476562 C 386.8814086914062 503.6336059570312 406.46875 512.443359375 427.6038208007812 510.3974609375 C 459.1674194335938 507.3405151367188 470.96044921875 483.1375732421875 501.2381591796875 477.2631530761719 C 515.6553344726562 474.4659729003906 531.5679931640625 476.4381713867188 545.9853515625 479.2390747070312 C 560.3961181640625 482.0382080078125 574.6136474609375 485.6843872070312 589.8294067382812 486.2552185058594 C 605.0452270507812 486.8261108398438 622.0344848632812 483.4321899414062 628.5460205078125 475.672119140625 C 637.2730712890625 465.2638549804688 652.2891235351562 455.1558227539062 671.7454833984375 451.6109008789062 C 691.1956176757812 448.0660400390625 712.0820922851562 447.7566223144531 731.7871704101562 444.6905212402344 C 751.4988403320312 441.6225280761719 771.3936767578125 434.685546875 776.8748168945312 423.5996704101562 C 782.496337890625 412.2320251464844 771.5245971679688 400.6599426269531 763.3834838867188 389.785888671875 C 755.2423095703125 378.91357421875 750.7855224609375 364.7873840332031 765.8604736328125 356.5871276855469 C 780.5986328125 348.5673522949219 804.4855346679688 351.1730041503906 824.5800170898438 348.885986328125 C 846.926025390625 346.3428955078125 866.2383422851562 336.63623046875 873.2474975585938 324.4289245605469 C 875.891357421875 319.8232421875 876.7453002929688 314.9266662597656 875.9535522460938 310.1129455566406 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_sdjxnv =
    '<svg viewBox="-60.6 188.0 603.4 356.4" ><path transform="translate(-333.48, -122.11)" d="M 875.9535522460938 666.5302734375 L 334.1761474609375 663.6410522460938 C 313.4140014648438 651.2196655273438 297.2854614257812 630.8338623046875 291.9845581054688 607.1629028320312 C 283.84326171875 570.808837890625 298.9574584960938 532.0069580078125 289.5859375 495.9539794921875 C 286.208984375 482.9568481445312 279.7791748046875 470.947998046875 275.9049072265625 458.0914306640625 C 272.0305786132812 445.2382202148438 270.9998168945312 430.5264282226562 278.0023803710938 419.070556640625 C 288.9806518554688 401.1028442382812 313.7314453125 398.7010498046875 331.6793823242188 387.6932983398438 C 349.9612426757812 376.4795532226562 360.6318969726562 356.5748291015625 373.7599487304688 339.6182250976562 C 386.8814086914062 322.6616821289062 406.46875 307.007568359375 427.6038208007812 310.6429443359375 C 459.1674194335938 316.0748291015625 470.96044921875 359.0812377929688 501.2381591796875 369.5195922851562 C 515.6553344726562 374.4899291992188 531.5679931640625 370.9855346679688 545.9853515625 366.008544921875 C 560.3961181640625 361.0347290039062 574.6136474609375 354.5558471679688 589.8294067382812 353.54150390625 C 605.0452270507812 352.527099609375 622.0344848632812 358.5577392578125 628.5460205078125 372.3467407226562 C 637.2730712890625 390.8412475585938 652.2891235351562 408.8023071289062 671.7454833984375 415.101318359375 C 691.1956176757812 421.4002075195312 712.0820922851562 421.9500122070312 731.7871704101562 427.398193359375 C 751.4988403320312 432.8497314453125 771.3936767578125 445.1760864257812 776.8748168945312 464.8746948242188 C 782.496337890625 485.073974609375 771.5245971679688 505.6365356445312 763.3834838867188 524.958740234375 C 755.2423095703125 544.27783203125 750.7855224609375 569.3787841796875 765.8604736328125 583.9498901367188 C 780.5986328125 598.2003173828125 804.4855346679688 593.5703125 824.5800170898438 597.6341552734375 C 846.926025390625 602.1529541015625 866.2383422851562 619.4008178710938 873.2474975585938 641.0921020507812 C 875.891357421875 649.2760009765625 876.7453002929688 657.9767456054688 875.9535522460938 666.5302734375 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_xweay0 =
    '<svg viewBox="17.0 51.0 16.0 16.0" ><path transform="translate(13.0, 47.0)" d="M 12 20 L 13.40999984741211 18.59000015258789 L 7.829999923706055 13 L 20 13 L 20 11 L 7.829999923706055 11 L 13.40999984741211 5.409999847412109 L 12 4 L 4 12 L 12 20 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b53q9 =
    '<svg viewBox="23.0 336.0 319.0 131.0" ><defs><filter id="shadow"><feDropShadow dx="5" dy="3" stdDeviation="21"/></filter></defs><path transform="translate(11.0, 306.0)" d="M 24.88787078857422 29.99999809265137 L 318.0869140625 29.99999809265137 C 325.2046813964844 29.99999809265137 330.9747924804688 36.51673889160156 330.9747924804688 44.5555534362793 L 330.9747924804688 146.4444427490234 C 330.9747924804688 154.4832458496094 325.2046813964844 161 318.0869140625 161 L 24.88787078857422 161 C 17.77009582519531 161 12 154.4832458496094 12 146.4444427490234 L 12 44.5555534362793 C 12 36.51673889160156 17.77009582519531 29.99999809265137 24.88787078857422 29.99999809265137 Z" fill="#fafafa" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_x9xr4e =
    '<svg viewBox="237.1 47.8 21.1 19.2" ><path transform="translate(306.42, 104.55)" d="M -48.40910339355469 -50.80363845825195 C -47.41164398193359 -47.46786117553711 -49.70090484619141 -43.33084106445312 -53.33101654052734 -40.5837287902832 C -56.97747802734375 -37.83661651611328 -61.94844436645508 -36.46305847167969 -65.26786804199219 -38.58880233764648 C -68.58729553222656 -40.71454620361328 -70.25518798828125 -46.33958435058594 -68.75082397460938 -50.36213684082031 C -67.26280212402344 -54.36834335327148 -62.61886978149414 -56.77206802368164 -58.15481567382812 -56.70666122436523 C -53.69075775146484 -56.6576042175293 -49.40657043457031 -54.13941955566406 -48.40910339355469 -50.80363845825195 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
