import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component21.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDIPhoneXXS11Pro3 extends StatelessWidget {
  XDIPhoneXXS11Pro3({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 35.0, middle: 0.5),
            Pin(size: 35.0, middle: 0.3308),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                gradient: LinearGradient(
                  begin: Alignment(0.0, -1.0),
                  end: Alignment(0.0, 1.0),
                  colors: [const Color(0xe5ffffff), const Color(0x73ffffff)],
                  stops: [0.0, 1.0],
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.2, middle: 0.5),
            Pin(size: 30.2, middle: 0.3318),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 1.0, middle: 0.5171),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_xganpy,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, middle: 0.5171),
                  child: SvgPicture.string(
                    _svg_x1worb,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: -67.8, end: -172.7),
            Pin(start: 71.5, end: 117.4),
            child: SvgPicture.string(
              _svg_gk4ccz,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 122.0, end: -43.0),
            Pin(size: 122.0, end: 117.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 208.0, start: -40.0),
            Pin(size: 207.0, end: -70.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0x75022c43),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 39.0, end: 39.0),
            Pin(size: 99.0, middle: 0.5372),
            child: XDComponent21(),
          ),
          Pinned.fromPins(
            Pin(size: 21.1, middle: 0.6529),
            Pin(size: 19.2, middle: 0.4944),
            child:
                // Adobe XD layer: 'blob (1)' (shape)
                SvgPicture.string(
              _svg_g2riz,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.4623),
            Pin(size: 150.0, middle: 0.2106),
            child: Transform.rotate(
              angle: 0.9599,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28.0),
                  color: const Color(0xe4ff7f00),
                  border: Border.all(width: 1.0, color: const Color(0xe4115173)),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.5377),
            Pin(size: 150.0, middle: 0.271),
            child: Transform.rotate(
              angle: 0.9599,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(27.0),
                  color: const Color(0xe4022c43),
                  border: Border.all(width: 1.0, color: const Color(0xe4ff7f00)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_xganpy =
    '<svg viewBox="15.1 0.0 1.0 30.2" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(15.1, 0.0)" d="M 0 0 L 0 30.20000076293945" fill="none" stroke="#ffffff" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" filter="url(#shadow)"/></svg>';
const String _svg_x1worb =
    '<svg viewBox="0.0 15.1 30.2 1.0" ><path transform="matrix(0.0, 1.0, -1.0, 0.0, 30.2, 15.1)" d="M 0 0 L 0 30.19999885559082" fill="none" stroke="#ffffff" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_gk4ccz =
    '<svg viewBox="-67.8 71.5 615.5 623.1" ><defs><linearGradient id="gradient" x1="0.899556" y1="0.834565" x2="0.387556" y2="0.514368"><stop offset="0.0" stop-color="#00ffd700" stop-opacity="0.0" /><stop offset="0.213327" stop-color="#ffffd700"  /><stop offset="1.0" stop-color="#00ffd700" stop-opacity="0.0" /></linearGradient></defs><path transform="matrix(0.71934, 0.694658, -0.694658, 0.71934, 343.47, 71.43)" d="M 146.9557189941406 0.08650227636098862 C 225.3801574707031 0.08650227636098862 284 63.5755615234375 284 142 L 284 450 C 284 528.4244384765625 220.4244384765625 592 142 592 C 63.5755615234375 592 0 528.4244384765625 0 450 L 0 142 C 0 63.5755615234375 68.53128814697266 0.08650227636098862 146.9557189941406 0.08650227636098862 Z" fill="url(#gradient)" fill-opacity="0.19" stroke="none" stroke-width="1" stroke-opacity="0.19" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_g2riz =
    '<svg viewBox="231.1 392.0 21.1 19.2" ><path transform="translate(300.36, 448.71)" d="M -48.40910339355469 -50.80363845825195 C -47.41164398193359 -47.46786117553711 -49.70090484619141 -43.33084106445312 -53.33101654052734 -40.5837287902832 C -56.97747802734375 -37.83661651611328 -61.94844436645508 -36.46305847167969 -65.26786804199219 -38.58880233764648 C -68.58729553222656 -40.71454620361328 -70.25518798828125 -46.33958435058594 -68.75082397460938 -50.36213684082031 C -67.26280212402344 -54.36834335327148 -62.61886978149414 -56.77206802368164 -58.15481567382812 -56.70666122436523 C -53.69075775146484 -56.6576042175293 -49.40657043457031 -54.13941955566406 -48.40910339355469 -50.80363845825195 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
