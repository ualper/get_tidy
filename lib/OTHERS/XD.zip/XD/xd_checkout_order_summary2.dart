import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component71.dart';
import 'xd_checkout_edit_card2.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_checkout_payments_cash_on_delivery2.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDCheckoutOrderSummary2 extends StatelessWidget {
  XDCheckoutOrderSummary2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 202.0, middle: 0.2492),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28.0),
                      color: const Color(0xffffffff),
                      border: Border.all(width: 0.6, color: const Color(0xffe2e2e2)),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x0a000000),
                          offset: Offset(0, 3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 18.0, end: 18.0),
                  Pin(start: 30.0, end: 30.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 56.0, start: 0.0),
                        Pin(size: 16.0, end: 0.0),
                        child: Text(
                          'Edit',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 14,
                            color: const Color(0xffff7f00),
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 24.0, end: 0.0),
                        Pin(size: 24.0, middle: 0.5508),
                        child:
                            // Adobe XD layer: 'Checkbox' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Dot 2' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                  color: const Color(0xffff7f00),
                                ),
                              ),
                            ),
                            Transform.translate(
                              offset: Offset(5.8, 7.0),
                              child: SizedBox(
                                width: 13.0,
                                height: 10.0,
                                child:
                                    // Adobe XD layer: 'Checkmark' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox(
                                      width: 13.0,
                                      height: 10.0,
                                      child: SvgPicture.string(
                                        _svg_gve4pw,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 57.0),
                        Pin(size: 78.0, middle: 0.5938),
                        child: Text(
                          '34 Keshar Vihar ,Civil line , near high, court, Jaipur',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 16,
                            color: const Color(0xff000000),
                            height: 1.625,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 170.0, start: 0.0),
                        Pin(size: 18.0, start: 0.0),
                        child: Text(
                          'Address for Service',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 18,
                            color: const Color(0xff383838),
                            fontWeight: FontWeight.w700,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 202.0, middle: 0.6049),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28.0),
                      color: const Color(0xffffffff),
                      border: Border.all(width: 0.6, color: const Color(0xffe2e2e2)),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x0a000000),
                          offset: Offset(0, 3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 18.0, end: 18.0),
                  Pin(size: 112.0, middle: 0.4889),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 54.0, start: 0.0),
                        Pin(size: 14.0, end: 0.0),
                        child: Text(
                          'Update',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 14,
                            color: const Color(0xffff7f00),
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 24.0, end: 0.0),
                        Pin(size: 24.0, middle: 0.5795),
                        child:
                            // Adobe XD layer: 'Checkbox' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Dot 2' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                  color: const Color(0xffff7f00),
                                ),
                              ),
                            ),
                            Transform.translate(
                              offset: Offset(5.8, 7.0),
                              child: SizedBox(
                                width: 13.0,
                                height: 10.0,
                                child:
                                    // Adobe XD layer: 'Checkmark' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox(
                                      width: 13.0,
                                      height: 10.0,
                                      child: SvgPicture.string(
                                        _svg_qdunsd,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 26.0),
                        Pin(size: 50.0, middle: 0.6129),
                        child:
                            // Adobe XD layer: 'Payment Method' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'BG' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(width: 1.0, color: const Color(0x00000000)),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 137.0, middle: 0.5347),
                              Pin(size: 16.0, end: 7.0),
                              child: Text(
                                '****  ****  ****  4748',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 16,
                                  color: const Color(0xff000000),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 66.0, middle: 0.3628),
                              Pin(size: 12.0, middle: 0.2368),
                              child: Text(
                                'Master Card',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 12,
                                  color: const Color(0xff929292),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Transform.translate(
                              offset: Offset(0.3, 4.0),
                              child: SizedBox(
                                width: 59.0,
                                height: 42.0,
                                child:
                                    // Adobe XD layer: 'Icon_MasterCard' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox(
                                      width: 59.0,
                                      height: 42.0,
                                      child: SvgPicture.string(
                                        _svg_l5fxwk,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 75.0, start: 0.0),
                        Pin(size: 18.0, start: 0.0),
                        child: Text(
                          'Payment',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 18,
                            color: const Color(0xff383838),
                            fontWeight: FontWeight.w700,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: XDComponent71(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 84.0, end: 0.0),
            child:
                // Adobe XD layer: 'Bottom' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'BG' (shape)
                      SvgPicture.string(
                    _svg_izk15e,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 146.0, end: 30.0),
                  Pin(size: 50.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Primary Button - Sm…' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Button' (shape)
                            PageLink(
                          links: [
                            PageLinkInfo(
                              transition: LinkTransition.Fade,
                              ease: Curves.easeOut,
                              duration: 0.3,
                              pageBuilder: () => XDCheckoutEditCard2(),
                            ),
                          ],
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25.0),
                              color: const Color(0xffff7f00),
                            ),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 26.0, middle: 0.5),
                        Pin(size: 14.0, middle: 0.5278),
                        child: Text(
                          'PAY',
                          style: TextStyle(
                            fontFamily: 'SF Pro Text',
                            fontSize: 14,
                            color: const Color(0xffffffff),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 146.0, start: 30.0),
                  Pin(size: 50.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Secondary Button - …' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Button' (shape)
                            PageLink(
                          links: [
                            PageLinkInfo(
                              transition: LinkTransition.Fade,
                              ease: Curves.easeOut,
                              duration: 0.3,
                              pageBuilder: () => XDCheckoutPaymentsCashOnDelivery2(),
                            ),
                          ],
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25.0),
                              border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                            ),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 38.0, middle: 0.5),
                        Pin(size: 14.0, middle: 0.5278),
                        child: Text(
                          'BACK',
                          style: TextStyle(
                            fontFamily: 'SF Pro Text',
                            fontSize: 14,
                            color: const Color(0xffffffff),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_gve4pw =
    '<svg viewBox="0.0 0.0 13.0 9.7" ><path transform="translate(-0.01, -0.05)" d="M 0.4007799327373505 4.559262752532959 C 0.8408106565475464 4.163235187530518 1.544859886169434 4.207238674163818 1.940887689590454 4.691272735595703 L 4.273050785064697 7.067438125610352 L 11.18153381347656 0.334968239068985 C 11.62156391143799 -0.0610593743622303 12.32561302185059 -0.0610593743622303 12.72164154052734 0.4229744076728821 C 13.11766815185547 0.9070081114768982 13.11766815185547 1.567054271697998 12.63363456726074 1.963082194328308 L 4.977098941802979 9.443604469299316 C 4.845089912414551 9.575613021850586 4.713080406188965 9.619616508483887 4.581071376800537 9.663619995117188 C 4.581071376800537 9.663619995117188 4.537067890167236 9.663619995117188 4.537067890167236 9.663619995117188 C 4.49306583404541 9.707622528076172 4.449062347412109 9.707622528076172 4.405059337615967 9.707622528076172 C 4.361056327819824 9.707622528076172 4.361056327819824 9.707622528076172 4.317053318023682 9.707622528076172 C 4.273050785064697 9.707622528076172 4.229047775268555 9.707622528076172 4.185043811798096 9.707622528076172 C 4.141040325164795 9.707622528076172 4.097037315368652 9.707622528076172 4.053034782409668 9.707622528076172 C 4.053034782409668 9.707622528076172 4.009031295776367 9.707622528076172 4.009031295776367 9.707622528076172 C 3.965028285980225 9.707622528076172 3.877022266387939 9.663619995117188 3.833019733428955 9.663619995117188 C 3.833019733428955 9.663619995117188 3.833019733428955 9.663619995117188 3.833019733428955 9.663619995117188 C 3.70100998878479 9.619616508483887 3.569000720977783 9.487607955932617 3.436991691589355 9.399600028991699 L 0.312773734331131 6.143373489379883 C -0.1272569745779037 5.615336894989014 -0.08325387537479401 4.955290794372559 0.4007799327373505 4.559262752532959 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_qdunsd =
    '<svg viewBox="0.0 0.0 13.0 9.7" ><path transform="translate(-0.01, -0.05)" d="M 0.4007799327373505 4.559262752532959 C 0.8408106565475464 4.163235187530518 1.544859886169434 4.207238674163818 1.940887689590454 4.691272735595703 L 4.273050785064697 7.067438125610352 L 11.18153381347656 0.334968239068985 C 11.62156391143799 -0.0610593743622303 12.32561302185059 -0.0610593743622303 12.72164154052734 0.4229744076728821 C 13.11766815185547 0.9070081114768982 13.11766815185547 1.567054271697998 12.63363456726074 1.963082194328308 L 4.977098941802979 9.443604469299316 C 4.845089912414551 9.575613021850586 4.713080406188965 9.619616508483887 4.581071376800537 9.663619995117188 C 4.581071376800537 9.663619995117188 4.537067890167236 9.663619995117188 4.537067890167236 9.663619995117188 C 4.49306583404541 9.707622528076172 4.449062347412109 9.707622528076172 4.405059337615967 9.707622528076172 C 4.361056327819824 9.707622528076172 4.361056327819824 9.707622528076172 4.317053318023682 9.707622528076172 C 4.273050785064697 9.707622528076172 4.229047775268555 9.707622528076172 4.185043811798096 9.707622528076172 C 4.141040325164795 9.707622528076172 4.097037315368652 9.707622528076172 4.053034782409668 9.707622528076172 C 4.053034782409668 9.707622528076172 4.009031295776367 9.707622528076172 4.009031295776367 9.707622528076172 C 3.965028285980225 9.707622528076172 3.877022266387939 9.663619995117188 3.833019733428955 9.663619995117188 C 3.833019733428955 9.663619995117188 3.833019733428955 9.663619995117188 3.833019733428955 9.663619995117188 C 3.70100998878479 9.619616508483887 3.569000720977783 9.487607955932617 3.436991691589355 9.399600028991699 L 0.312773734331131 6.143373489379883 C -0.1272569745779037 5.615336894989014 -0.08325387537479401 4.955290794372559 0.4007799327373505 4.559262752532959 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_l5fxwk =
    '<svg viewBox="0.0 0.0 58.9 42.1" ><path transform="translate(-3.0, -9.0)" d="M 61.89778518676758 45.46053314208984 C 61.89778518676758 48.56093978881836 59.38888168334961 51.06984710693359 56.28847122192383 51.06984710693359 L 8.609312057495117 51.06984710693359 C 5.508849620819092 51.06984710693359 3 48.56093978881836 3 45.46053314208984 L 3 14.60931205749512 C 3 11.50890445709229 5.508849620819092 9 8.609312057495117 9 L 56.28847122192383 9 C 59.38888168334961 9 61.89778518676758 11.50890445709229 61.89778518676758 14.60931205749512 L 61.89778518676758 45.46053314208984 Z" fill="#3f51b5" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(3.84, -6.99)" d="M 48.04656219482422 28.02328491210938 C 48.04656219482422 35.76890182495117 41.76889419555664 42.04656219482422 34.02328109741211 42.04656219482422 C 26.27766227722168 42.04656219482422 20 35.76890182495117 20 28.02328491210938 C 20 20.27766227722168 26.27766227722168 13.99999904632568 34.02328109741211 13.99999904632568 C 41.76889419555664 13.99999904632568 48.04656219482422 20.27766227722168 48.04656219482422 28.02328491210938 Z" fill="#ffc107" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-1.39, -6.99)" d="M 28.05679702758789 36.43724822998047 C 27.40499496459961 35.57173538208008 26.84616851806641 34.63497924804688 26.4079418182373 33.63259506225586 L 33.87435531616211 33.63259506225586 C 34.26322555541992 32.73973083496094 34.57005310058594 31.80298042297363 34.76721954345703 30.82793998718262 L 25.51507759094238 30.82793998718262 C 25.32884979248047 29.92413902282715 25.23026657104492 28.98738479614258 25.23026657104492 28.02328491210938 L 35.04656600952148 28.02328491210938 C 35.04656600952148 27.05918502807617 34.94797897338867 26.12242698669434 34.76721954345703 25.21862983703613 L 25.50960731506348 25.21862983703613 C 25.7123851776123 24.24358749389648 26.01360511779785 23.30683135986328 26.4079418182373 22.41397285461426 L 33.87435531616211 22.41397285461426 C 33.43613052368164 21.41158866882324 32.87730407714844 20.47483062744141 32.22549819946289 19.60931587219238 L 28.05679702758789 19.60931587219238 C 28.66484832763672 18.79862594604492 29.36054039001465 18.03716850280762 30.1329460144043 17.37442398071289 C 27.67886734008789 15.27639770507812 24.50175857543945 13.99999904632568 21.02328109741211 13.99999904632568 C 13.277663230896 13.99999904632568 6.999999523162842 20.27766227722168 6.999999523162842 28.02328491210938 C 6.999999523162842 35.76890182495117 13.277663230896 42.04656219482422 21.02328109741211 42.04656219482422 C 25.60819625854492 42.04656219482422 29.66190338134766 39.83901977539062 32.22003173828125 36.43724822998047 L 28.05679702758789 36.43724822998047 Z" fill="#ff3d00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_izk15e =
    '<svg viewBox="475.0 874.0 375.0 84.0" ><path transform="translate(475.0, 918.0)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 40.00000381469727 L 0 40.00000381469727 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
