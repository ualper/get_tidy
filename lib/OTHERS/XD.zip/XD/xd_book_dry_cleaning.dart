import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component41.dart';
import 'xd_home_service_recipient1.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDBookDryCleaning extends StatelessWidget {
  XDBookDryCleaning({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -29.0, end: -323.0),
            Pin(size: 376.0, start: 95.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.0, end: 23.0),
            Pin(size: 69.2, middle: 0.1939),
            child: SvgPicture.string(
              _svg_ls1dav,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 205.0, start: 33.0),
            Pin(size: 45.0, middle: 0.2216),
            child: Text(
              'Salacak, 34674 Üsküdar/İstanbul\n',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xff383838),
                height: 1.8571428571428572,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 33.0),
            Pin(size: 12.0, middle: 0.1925),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 3,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 52.0, start: 51.0),
            Pin(size: 16.0, middle: 0.191),
            child: Text(
              'Service at',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                color: const Color(0x99383838),
                height: 2.1666666666666665,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 1.0, middle: 0.5027),
            Pin(size: 116.0, middle: 0.3147),
            child: SvgPicture.string(
              _svg_bozojd,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 44.0, start: 44.0),
            child: XDComponent41(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 197.0, middle: 0.7659),
            child: SvgPicture.string(
              _svg_dpy,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 230.0, end: 0.0),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_b9galx,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, end: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDHomeServiceRecipient1(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.0),
                        color: const Color(0xffff7f00),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 64.0, middle: 0.5),
                    Pin(size: 14.0, middle: 0.5278),
                    child: Text(
                      'Book Now',
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 14,
                        color: const Color(0xffffffff),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, start: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Button' (shape)
                Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25.0),
                border: Border.all(width: 2.0, color: const Color(0xffffffff)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 82.0, middle: 0.2116),
            Pin(size: 14.0, end: 34.0),
            child: Text(
              'Service Later',
              style: TextStyle(
                fontFamily: 'SF Pro Text',
                fontSize: 14,
                color: const Color(0xffffffff),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 160.0, middle: 0.3023),
            Pin(size: 32.0, middle: 0.7551),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 24,
                  color: const Color(0xffffffff),
                  height: 1.5,
                ),
                children: [
                  TextSpan(
                    text: 'Per Outfit : £',
                  ),
                  TextSpan(
                    text: '10',
                    style: TextStyle(
                      color: const Color(0xffff7f00),
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 173.0, start: 27.0),
            Pin(size: 18.0, middle: 0.7834),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 13,
                  color: const Color(0xffff7f00),
                ),
                children: [
                  TextSpan(
                    text: 'Note: ',
                  ),
                  TextSpan(
                    text: 'Parts price is additional ',
                    style: TextStyle(
                      color: const Color(0xffffffff),
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 76.0, end: 87.0),
            child: SvgPicture.string(
              _svg_ppojg,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.0, start: 47.0),
            Pin(size: 17.0, end: 131.0),
            child: Text(
              'Enter job description for service..',
              style: TextStyle(
                fontFamily: 'Lato',
                fontSize: 14,
                color: const Color(0xffb7bec6),
                height: 1.4285714285714286,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 52.0),
            Pin(size: 30.0, middle: 0.4514),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, start: 51.0),
            Pin(size: 30.0, middle: 0.3811),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 22.0),
            Pin(size: 30.0, start: 114.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 15.0),
            Pin(size: 30.0, middle: 0.3274),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.5015),
            Pin(size: 40.0, middle: 0.4054),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, middle: 0.7333),
            Pin(size: 30.0, middle: 0.2609),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, middle: 0.7217),
            Pin(size: 30.0, middle: 0.5639),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, start: 24.0),
            Pin(size: 30.0, middle: 0.5128),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 111.5, middle: 0.6717),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_fpz075,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 224.6, middle: 0.5831),
            Pin(size: 111.0, middle: 0.6719),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ls1dav =
    '<svg viewBox="24.0 144.0 328.0 69.2" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(1282.0, 144.0)" d="M -1106.000122070312 55.99980163574219 L -1251.999877929688 55.99980163574219 C -1255.313720703125 55.99980163574219 -1258.000244140625 53.31330108642578 -1258.000244140625 50.00040054321289 L -1258.000244140625 6.00029993057251 C -1258.000244140625 2.686500072479248 -1255.313720703125 0 -1251.999877929688 0 L -936 0 C -932.6862182617188 0 -929.9996948242188 2.686500072479248 -929.9996948242188 6.00029993057251 L -929.9996948242188 50.00040054321289 C -929.9996948242188 53.31330108642578 -932.6862182617188 55.99980163574219 -936 55.99980163574219 L -1081.999877929688 55.99980163574219 L -1094.499877929688 69.24960327148438 L -1106.000122070312 55.99980163574219 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_bozojd =
    '<svg viewBox="188.0 219.0 1.0 116.0" ><path transform="translate(188.0, 219.0)" d="M 0 0 L 0 116" fill="none" stroke="#022c43" stroke-width="2" stroke-dasharray="4 9" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_dpy =
    '<svg viewBox="0.0 471.0 375.0 197.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="-1" stdDeviation="16"/></filter></defs><path transform="translate(0.0, 471.0)" d="M 0 0 L 375 0 L 375 197 L 0 197 L 0 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_b9galx =
    '<svg viewBox="0.0 582.0 375.0 230.0" ><path transform="translate(0.0, 626.04)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 185.9560852050781 L 0 185.9560852050781 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ppojg =
    '<svg viewBox="17.0 649.0 343.0 76.0" ><path transform="translate(17.0, 649.0)" d="M 11.35761642456055 0 L 331.6423950195312 0 C 337.9150390625 0 343 5.148725032806396 343 11.5 L 343 64.5 C 343 70.85127258300781 337.9150390625 76 331.6423950195312 76 L 11.35761642456055 76 C 5.084977626800537 76 0 70.85127258300781 0 64.5 L 0 11.5 C 0 5.148725032806396 5.084977626800537 0 11.35761642456055 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_fpz075 =
    '<svg viewBox="0.0 470.5 375.0 111.5" ><path transform="translate(0.0, 514.52)" d="M 0 -44 L 375 -44 L 375 67.52203369140625 L 0 67.52203369140625 L 0 -44 Z" fill="#ffa700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
