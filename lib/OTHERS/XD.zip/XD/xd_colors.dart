import 'package:flutter/material.dart';

class XDColors {
  static const Color b100FF = const Color(0xffb100ff);
}
