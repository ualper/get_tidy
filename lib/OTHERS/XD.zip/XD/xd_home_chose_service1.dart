import 'package:flutter/material.dart';

class XDHomeChoseService1 extends StatelessWidget {
  XDHomeChoseService1({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[],
      ),
    );
  }
}
