import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import 'xd_component21.dart';
import 'xd_provider_main.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_provider_chat.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDProviderMessages extends StatelessWidget {
  XDProviderMessages({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffff7f00),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: SvgPicture.string(
              _svg_ouvc7r,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.5, end: 48.0),
            Pin(size: 127.0, middle: 0.3328),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 122.0, start: 0.0),
                  Pin(start: 0.0, end: 5.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 122.0, end: 0.0),
                  Pin(start: 5.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 265.0, start: 19.0),
            Pin(size: 60.0, start: 34.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 212.0, end: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: XDComponent21(),
                      ),
                      Pinned.fromPins(
                        Pin(size: 9.4, middle: 0.4912),
                        Pin(size: 8.5, start: 4.3),
                        child:
                            // Adobe XD layer: 'blob (1)' (shape)
                            SvgPicture.string(
                          _svg_azsewr,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(start: 11.0, end: 10.0),
            Pin(size: 414.0, middle: 0.5),
            child:
                // Adobe XD layer: 'New Customers' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Bg' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x14152232),
                          offset: Offset(0, 1),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                  ),
                ),
                Container(),
                Pinned.fromPins(
                  Pin(start: 30.0, end: 30.2),
                  Pin(size: 1.0, start: 368.5),
                  child:
                      // Adobe XD layer: 'Line' (shape)
                      Container(
                    decoration: BoxDecoration(
                      color: const Color(0xffe6e9f4),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 280.0, middle: 0.4702),
                  child:
                      // Adobe XD layer: 'Customers' (group)
                      Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      SizedBox(
                        height: 70.0,
                        child: Container(),
                      ),
                      SizedBox(
                        height: 70.0,
                        child: Container(),
                      ),
                      SizedBox(
                        height: 70.0,
                        child: Container(),
                      ),
                      SizedBox(
                        height: 70.0,
                        child: Container(),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.0763, endFraction: 0.6977),
                  Pin(size: 21.0, middle: 0.0712),
                  child:
                      // Adobe XD layer: 'Title' (text)
                      Text(
                    'MESSAGES',
                    style: TextStyle(
                      fontFamily: 'Poppins-SemiBold',
                      fontSize: 15,
                      color: const Color(0xff131523),
                      letterSpacing: 0.09375,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_ouvc7r =
    '<svg viewBox="0.0 0.0 375.0 812.0" ><path  d="M 375 0 L 375 812 L 0 812 L 375 0 Z" fill="#053f5e" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_azsewr =
    '<svg viewBox="99.5 4.3 9.4 8.5" ><path transform="translate(168.8, 61.01)" d="M -59.98715591430664 -54.07463455200195 C -59.54228591918945 -52.58687591552734 -60.56329345703125 -50.74176406860352 -62.18232345581055 -49.51655578613281 C -63.80864715576172 -48.29134368896484 -66.02569580078125 -47.67873764038086 -67.50616455078125 -48.6268196105957 C -68.98662567138672 -49.57489776611328 -69.73050689697266 -52.08366394042969 -69.05955505371094 -53.87772369384766 C -68.39590454101562 -55.66448974609375 -66.32470703125 -56.73654937744141 -64.333740234375 -56.70737838745117 C -62.34276962280273 -56.68550109863281 -60.43202209472656 -55.56239318847656 -59.98715591430664 -54.07463455200195 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
