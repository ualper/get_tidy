import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDcomponent_mesage extends StatelessWidget {
  XDcomponent_mesage({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Pinned.fromPins(
          Pin(start: 15.0, end: 16.0),
          Pin(size: 55.0, start: 0.0),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28.0),
              color: const Color(0xfff5c9ff),
              boxShadow: [
                BoxShadow(
                  color: const Color(0x29000000),
                  offset: Offset(0, 1),
                  blurRadius: 7,
                ),
              ],
            ),
          ),
        ),
        Transform.translate(
          offset: Offset(28.0, 14.0),
          child: SizedBox(
            width: 30.0,
            height: 27.0,
            child:
                // Adobe XD layer: 'ic-contact-chat' (group)
                Stack(
              children: <Widget>[
                SizedBox(
                  width: 30.0,
                  height: 27.0,
                  child: SvgPicture.string(
                    _svg_ldpd34,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
        ),
        Pinned.fromPins(
          Pin(start: 0.0, end: 0.0),
          Pin(size: 17.0, end: 0.0),
          child: Text(
            'MESSAGES',
            style: TextStyle(
              fontFamily: 'Arial',
              fontSize: 15,
              color: const Color(0xff115173),
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}

const String _svg_ldpd34 =
    '<svg viewBox="2.0 3.0 30.0 27.0" ><path  d="M 5 3 L 20 3 C 21.6568546295166 3 23 4.343145847320557 23 6 L 23 15 C 23 16.6568546295166 21.6568546295166 18 20 18 L 15.5 18 L 11 22.5 L 6.5 18 L 5 18 C 3.343145847320557 18 2 16.6568546295166 2 15 L 2 6 C 2 4.343145847320557 3.343146324157715 2.999999523162842 5.000000953674316 3 Z" fill="#ff0303" fill-opacity="0.0" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /><path transform="translate(3.0, 2.5)" d="M 20 8 L 26 8 C 27.65685653686523 8 29 9.343145370483398 29 11 L 29 20 C 29 21.65685653686523 27.65685272216797 23 26 23 L 23 23 L 20 27.5 L 15.5 23 L 11 23 C 9.343145370483398 23 8 21.65685272216797 8 20 L 8 20" fill="#ff0303" fill-opacity="0.0" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /></svg>';
