import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component401.dart';
import 'xd_component_main_label.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDSamsungGalaxyS101 extends StatelessWidget {
  XDSamsungGalaxyS101({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 80.5, end: 80.5),
            Pin(size: 71.0, middle: 0.2276),
            child: XDComponent401(),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 24.0),
            Pin(size: 12.0, middle: 0.6738),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, middle: 0.5),
            Pin(size: 50.0, end: 53.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Button' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25.0),
                      color: const Color(0xff053f5e),
                      border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 56.0, middle: 0.5),
                  Pin(size: 14.0, middle: 0.5278),
                  child: Text(
                    'Continue',
                    style: TextStyle(
                      fontFamily: 'SF Pro Text',
                      fontSize: 14,
                      color: const Color(0xffffffff),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 28.0, end: 28.0),
            Pin(size: 186.0, middle: 0.77),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 20,
                  color: const Color(0xff115173),
                ),
                children: [
                  TextSpan(
                    text: 'WHAT DO YOU NEED?\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Recipient: \n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text:
                        'Do you want to dry-clean your clothes \nor find the nearest ironing service\n without wasting your time?\n',
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                  TextSpan(
                    text: '\n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Provider: \n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: ' ',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text:
                        'Are you seeking service for your dry cleaning \nor serving people by ironing from your home?',
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 10.0, end: 10.0),
            Pin(size: 5.0, middle: 0.5411),
            child: SvgPicture.string(
              _svg_e3dat3,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 14.0, end: 14.0),
            Pin(size: 81.7, start: 46.6),
            child: XDComponentMainLabel(),
          ),
          Pinned.fromPins(
            Pin(size: 164.0, end: 10.0),
            Pin(size: 124.0, middle: 0.4025),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 164.0, start: 10.0),
            Pin(size: 124.0, middle: 0.4025),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Container(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_e3dat3 =
    '<svg viewBox="10.0 408.5 340.0 5.0" ><path transform="translate(8.0, 348.52)" d="M 336.3333435058594 65 L 7.666667938232422 65 C 4.53705358505249 65 1.999999761581421 63.88069915771484 1.999999761581421 62.49998474121094 C 1.999999761581421 61.11928558349609 4.53705358505249 60 7.666667938232422 60 L 336.3333435058594 60 C 339.4629821777344 60 342 61.11928558349609 342 62.49998474121094 C 342 63.88069915771484 339.4629821777344 65 336.3333435058594 65 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
