import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component71.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDCheckoutEditCard3 extends StatelessWidget {
  XDCheckoutEditCard3({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 401.0, start: 70.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: XDComponent71(),
          ),
          Pinned.fromPins(
            Pin(start: 22.6, end: 22.4),
            Pin(size: 20.0, middle: 0.4046),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 83.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Date & Time',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 147.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '22 Dec\'20 at 9 :42 am',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 22.6, end: 22.4),
            Pin(size: 20.0, middle: 0.4413),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 88.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Service Type',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 61.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Plumber ',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 37.6, end: 23.4),
            Pin(size: 25.0, middle: 0.2128),
            child: Text(
              'Payment made successfully by Card',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 19,
                color: const Color(0xff404040),
                letterSpacing: 0.19,
                fontWeight: FontWeight.w500,
                height: 1.105263157894737,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 88.0, middle: 0.4793),
            Pin(size: 33.0, start: 117.5),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 17,
                  color: const Color(0xffff7f00),
                  letterSpacing: 0.17,
                  height: 0.84,
                ),
                children: [
                  TextSpan(
                    text: '\$',
                    style: TextStyle(
                      fontSize: 25,
                      letterSpacing: 0.25,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: '154.75',
                    style: TextStyle(
                      fontSize: 25,
                      letterSpacing: 0.25,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1.0, middle: 0.2497),
            child: SvgPicture.string(
              _svg_uhyi4p,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1.0, middle: 0.3767),
            child: SvgPicture.string(
              _svg_mg679d,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 77.0, start: 21.6),
            Pin(size: 20.0, middle: 0.2771),
            child: Text(
              'Job Deatils',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 15,
                color: const Color(0xb0404040),
                letterSpacing: 0.15,
                fontWeight: FontWeight.w500,
                height: 1.4,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 56.0, end: 22.4),
            Pin(size: 24.0, middle: 0.2785),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 17,
                  color: const Color(0xffff7f00),
                  letterSpacing: 0.17,
                  height: 1.1666666666666667,
                ),
                children: [
                  TextSpan(
                    text: '2Hrs.30min',
                    style: TextStyle(
                      fontSize: 18,
                      letterSpacing: 0.18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 23.0, end: 29.0),
            Pin(size: 37.0, middle: 0.3226),
            child: Text(
              'new shower installed with wall sockets and  general  service and cleaning  pipe...',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xffa4a4a4),
                letterSpacing: 0.14,
                height: 1.2857142857142858,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 22.6, end: 22.4),
            Pin(size: 20.0, middle: 0.4753),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 63.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Job Type',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 76.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Installation',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 286.0, end: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.6, end: 26.4),
            Pin(size: 20.0, middle: 0.6711),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 62.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Job Fees',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 57.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '\$100.25',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.6, end: 35.4),
            Pin(size: 20.0, middle: 0.719),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 24.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Tax',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 48.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '\$10.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.6, end: 35.4),
            Pin(size: 20.0, middle: 0.767),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 86.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '+ Parts Amt.',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 48.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '\$50.50',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.6, end: 35.4),
            Pin(size: 20.0, middle: 0.815),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 61.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Discount',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 48.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '\$10.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.6, end: 35.4),
            Pin(size: 20.0, end: 108.5),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 90.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    'Topup Added',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0xb0404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 48.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Text(
                    '\$25.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 15,
                      color: const Color(0x63404040),
                      letterSpacing: 0.15,
                      fontWeight: FontWeight.w700,
                      height: 1.4,
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 133.0, start: 48.6),
            Pin(size: 18.0, middle: 0.5485),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 13,
                  color: const Color(0xffa4a4a4),
                  letterSpacing: 0.13,
                  height: 1.6153846153846154,
                ),
                children: [
                  TextSpan(
                    text: 'You rated',
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: ' "Ahmet “Bey',
                    style: TextStyle(
                      color: const Color(0xff404040),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 19.6, end: 41.4),
            Pin(size: 29.0, end: 18.5),
            child: Text(
              'This job was towards you expectation you received Guaranteed\nGood Service',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 11,
                color: const Color(0xffa4a4a4),
                letterSpacing: 0.11,
                height: 1.2727272727272727,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 101.3, end: 35.7),
            Pin(size: 14.0, middle: 0.5482),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 14.7, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_k0fj69,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 14.7, middle: 0.2515),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_ywhl90,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 14.7, middle: 0.503),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_nq1ciz,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 14.7, middle: 0.7485),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_imvve,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 14.7, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_fa0t3w,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1.0, end: 92.5),
            child: SvgPicture.string(
              _svg_su687n,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 96.0, start: 17.6),
            Pin(size: 20.0, end: 62.5),
            child: Text(
              'Your Payment',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 15,
                color: const Color(0xb02fa23c),
                letterSpacing: 0.15,
                fontWeight: FontWeight.w700,
                height: 1.4,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 53.0, end: 25.4),
            Pin(size: 20.0, end: 62.5),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 15,
                  color: const Color(0xff2fa23c),
                  letterSpacing: 0.15,
                  height: 1.4,
                ),
                children: [
                  TextSpan(
                    text: '\$',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: '175.25',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 50.0, middle: 0.5692),
            Pin(size: 50.0, middle: 0.5499),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_uhyi4p =
    '<svg viewBox="0.0 202.5 375.0 1.0" ><path transform="translate(0.0, 202.5)" d="M 0 0 L 375 0" fill="none" fill-opacity="0.35" stroke="#a4a4a4" stroke-width="1" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_mg679d =
    '<svg viewBox="0.0 305.5 375.0 1.0" ><path transform="translate(0.0, 305.5)" d="M 0 0 L 375 0" fill="none" fill-opacity="0.35" stroke="#a4a4a4" stroke-width="1" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_k0fj69 =
    '<svg viewBox="82.0 652.0 14.7 14.0" ><path transform="translate(82.0, 650.68)" d="M 7.353281497955322 1.318000197410583 L 9.62528133392334 5.922060012817383 L 14.70629024505615 6.6605544090271 L 11.02965068817139 10.24409770965576 L 11.89755249023438 15.30463600158691 L 7.353281497955322 12.91551399230957 L 2.808738231658936 15.30463600158691 L 3.676640748977661 10.24409770965576 L 0 6.6605544090271 L 5.081010818481445 5.922060012817383 L 7.353281497955322 1.318000197410583 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ywhl90 =
    '<svg viewBox="103.8 652.0 14.7 14.0" ><path transform="translate(103.78, 650.68)" d="M 7.353281497955322 1.318000197410583 L 9.62528133392334 5.922060012817383 L 14.70629024505615 6.6605544090271 L 11.02965068817139 10.24409770965576 L 11.89755249023438 15.30463600158691 L 7.353281497955322 12.91551399230957 L 2.808738231658936 15.30463600158691 L 3.676640748977661 10.24409770965576 L 0 6.6605544090271 L 5.081010818481445 5.922060012817383 L 7.353281497955322 1.318000197410583 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nq1ciz =
    '<svg viewBox="125.6 652.0 14.7 14.0" ><path transform="translate(125.57, 650.68)" d="M 7.353281497955322 1.318000197410583 L 9.62528133392334 5.922060012817383 L 14.70629024505615 6.6605544090271 L 11.02965068817139 10.24409770965576 L 11.89755249023438 15.30463600158691 L 7.353281497955322 12.91551399230957 L 2.808738231658936 15.30463600158691 L 3.676640748977661 10.24409770965576 L 0 6.6605544090271 L 5.081010818481445 5.922060012817383 L 7.353281497955322 1.318000197410583 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_imvve =
    '<svg viewBox="146.8 652.0 14.7 14.0" ><path transform="translate(146.83, 650.68)" d="M 7.353281497955322 1.318000197410583 L 9.62528133392334 5.922060012817383 L 14.70629024505615 6.6605544090271 L 11.02965068817139 10.24409770965576 L 11.89755249023438 15.30463600158691 L 7.353281497955322 12.91551399230957 L 2.808738231658936 15.30463600158691 L 3.676640748977661 10.24409770965576 L 0 6.6605544090271 L 5.081010818481445 5.922060012817383 L 7.353281497955322 1.318000197410583 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_fa0t3w =
    '<svg viewBox="168.6 652.0 14.7 14.0" ><path transform="translate(168.62, 650.68)" d="M 7.353281497955322 1.318000197410583 L 9.62528133392334 5.922060012817383 L 14.70629024505615 6.6605544090271 L 11.02965068817139 10.24409770965576 L 11.89755249023438 15.30463600158691 L 7.353281497955322 12.91551399230957 L 2.808738231658936 15.30463600158691 L 3.676640748977661 10.24409770965576 L 0 6.6605544090271 L 5.081010818481445 5.922060012817383 L 7.353281497955322 1.318000197410583 Z" fill="#a4a4a4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_su687n =
    '<svg viewBox="0.0 718.5 375.0 1.0" ><path transform="translate(0.0, 718.5)" d="M 0 0 L 375 0" fill="none" stroke="#a4a4a4" stroke-width="1" stroke-dasharray="5 5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
