import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import 'xd_component21.dart';
import 'xd_chat1.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_book_ironing.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDChat extends StatelessWidget {
  XDChat({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: SvgPicture.string(
              _svg_nn7ad,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 19.0, end: 17.0),
            Pin(size: 540.0, end: 93.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(36.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 7,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.5, end: 47.0),
            Pin(size: 127.0, middle: 0.2613),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 122.0, start: 0.0),
                  Pin(start: 0.0, end: 5.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 122.0, end: 0.0),
                  Pin(start: 5.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 265.0, start: 19.0),
            Pin(size: 60.0, start: 34.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 212.0, end: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: XDComponent21(),
                      ),
                      Pinned.fromPins(
                        Pin(size: 9.4, middle: 0.4912),
                        Pin(size: 8.5, start: 4.3),
                        child:
                            // Adobe XD layer: 'blob (1)' (shape)
                            SvgPicture.string(
                          _svg_azsewr,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 19.0, end: 17.0),
            Pin(start: 94.0, end: 27.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 12.0, end: 13.6),
                              Pin(size: 441.2, middle: 0.4363),
                              child: Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child:
                                        // Adobe XD layer: 'Message ' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 235.0, end: 1.4),
                                          Pin(size: 132.0, middle: 0.4108),
                                          child:
                                              // Adobe XD layer: 'Rectangle' (shape)
                                              SvgPicture.string(
                                            _svg_m04p2i,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 235.6, end: 0.0),
                                          Pin(size: 64.2, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'Rectangle Copy 2' (shape)
                                              SvgPicture.string(
                                            _svg_wnefp,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 45.4),
                                          Pin(size: 115.0, start: 0.0),
                                          child: Transform.rotate(
                                            angle: 3.1416,
                                            child:
                                                // Adobe XD layer: 'Rectangle Copy' (shape)
                                                Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(41.5),
                                                  bottomRight: Radius.circular(41.5),
                                                  bottomLeft: Radius.circular(41.5),
                                                ),
                                                color: const Color(0xfff4f6ff),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 45.4),
                                          Pin(size: 80.0, middle: 0.7614),
                                          child: Transform.rotate(
                                            angle: 3.1416,
                                            child:
                                                // Adobe XD layer: 'Rectangle Copy 3' (shape)
                                                Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(41.5),
                                                  bottomRight: Radius.circular(41.5),
                                                  bottomLeft: Radius.circular(41.5),
                                                ),
                                                color: const Color(0xfff4f6ff),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 201.0, end: 18.4),
                                          Pin(size: 89.0, middle: 0.4231),
                                          child:
                                              // Adobe XD layer: 'Hello Sayed! what’s' (text)
                                              Text(
                                            'Thanks Charlotte can you please send me a picture of the new Shower',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xffffffff),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 203.0, end: 6.4),
                                          Pin(size: 47.0, end: 8.2),
                                          child:
                                              // Adobe XD layer: 'Ohh sure! How is you' (text)
                                              Scrollbar(
                                            child: SingleChildScrollView(
                                              child: Text(
                                                'Thanks I am waiting for the picture to better advise you.\n\n ',
                                                style: TextStyle(
                                                  fontFamily: 'Arial',
                                                  fontSize: 14,
                                                  color: const Color(0xffffffff),
                                                  letterSpacing: 0.12999999809265136,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.7142857142857142,
                                                ),
                                                textHeightBehavior:
                                                    TextHeightBehavior(applyHeightToFirstAscent: false),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 27.0, end: 68.4),
                                          Pin(size: 97.0, start: 13.0),
                                          child:
                                              // Adobe XD layer: 'That ways we don’t b' (text)
                                              Text(
                                            'Hi my name is Charlotte and Purchased  a new Shower , so I want to new  Installation for it.',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xff4d5a80),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(start: 36.0, end: 58.4),
                                          Pin(size: 43.0, middle: 0.7384),
                                          child:
                                              // Adobe XD layer: '$400 USD. You will d' (text)
                                              Text(
                                            'Yes I will send you a picture now.',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 14,
                                              color: const Color(0xff4d5a80),
                                              letterSpacing: 0.12999999809265136,
                                              fontWeight: FontWeight.w700,
                                              height: 1.7142857142857142,
                                            ),
                                            textHeightBehavior:
                                                TextHeightBehavior(applyHeightToFirstAscent: false),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.1053, endFraction: 0.8022),
                                          Pin(size: 24.0, middle: 0.4339),
                                          child:
                                              // Adobe XD layer: '12:10' (text)
                                              Text(
                                            '12:15\n',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.1053, endFraction: 0.8022),
                                          Pin(size: 12.0, middle: 0.939),
                                          child:
                                              // Adobe XD layer: '01:10' (text)
                                              Text(
                                            '01:12',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.8871, endFraction: 0.0204),
                                          Pin(size: 24.0, middle: 0.1103),
                                          child:
                                              // Adobe XD layer: '12:15' (text)
                                              Text(
                                            '12:10\n',
                                            style: TextStyle(
                                              fontFamily: 'Arial',
                                              fontSize: 11,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.10214285564422608,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(startFraction: 0.8871, endFraction: 0.0172),
                                          Pin(size: 26.0, middle: 0.7443),
                                          child:
                                              // Adobe XD layer: '01:12' (text)
                                              Text(
                                            '01:10\n',
                                            style: TextStyle(
                                              fontFamily: 'Helvetica',
                                              fontSize: 12,
                                              color: const Color(0xffabafbc),
                                              letterSpacing: 0.11142856979370117,
                                            ),
                                            textAlign: TextAlign.left,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 29.3, end: 11.7),
                              Pin(size: 29.3, start: 0.0),
                              child:
                                  // Adobe XD layer: 'baseline-duo-24px' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: SvgPicture.string(
                                      _svg_kx7cpj,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 282.0, end: 0.0),
                              Pin(size: 49.0, end: 0.0),
                              child: PageLink(
                                links: [
                                  PageLinkInfo(
                                    transition: LinkTransition.Fade,
                                    ease: Curves.easeOut,
                                    duration: 0.3,
                                    pageBuilder: () => XDChat1(),
                                  ),
                                ],
                                child: SvgPicture.string(
                                  _svg_io510,
                                  allowDrawingOutsideViewBox: true,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 116.0, middle: 0.3498),
                              Pin(size: 15.0, end: 17.0),
                              child: Text(
                                'Type message here',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 12,
                                  color: const Color(0xffc4c4c4),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 49.0, start: 0.0),
                              Pin(size: 49.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'upload_image' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                        color: const Color(0xffff7f00),
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 22.1, middle: 0.4825),
                                    Pin(size: 17.4, middle: 0.5057),
                                    child:
                                        // Adobe XD layer: 'camera (2)' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(start: 0.0, end: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child: Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_vbumi6,
                                                        allowDrawingOutsideViewBox: true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(size: 10.3, middle: 0.5),
                                                      Pin(size: 10.3, end: 2.5),
                                                      child: SvgPicture.string(
                                                        _svg_lp1ix9,
                                                        allowDrawingOutsideViewBox: true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(size: 2.1, end: 2.5),
                                                      Pin(size: 2.1, middle: 0.2932),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.all(
                                                              Radius.elliptical(9999.0, 9999.0)),
                                                          color: const Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 96.0, middle: 0.4979),
                  Pin(size: 80.0, start: 3.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 19.0, end: 0.0),
                        child: Text(
                          'Sujen Matin',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 17,
                            color: const Color(0xffffffff),
                            fontWeight: FontWeight.w700,
                            height: 0.8823529411764706,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 17.0, end: 18.0),
                        Pin(size: 61.0, start: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(38.0),
                            image: DecorationImage(
                              image: const AssetImage(''),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 25.3, end: 30.3),
            Pin(size: 21.9, end: 39.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_tjds53,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_nn7ad =
    '<svg viewBox="0.0 0.0 375.0 812.0" ><path  d="M 0 0 L 375 0 L 375 812 L 0 812 L 0 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_azsewr =
    '<svg viewBox="99.5 4.3 9.4 8.5" ><path transform="translate(168.8, 61.01)" d="M -59.98715591430664 -54.07463455200195 C -59.54228591918945 -52.58687591552734 -60.56329345703125 -50.74176406860352 -62.18232345581055 -49.51655578613281 C -63.80864715576172 -48.29134368896484 -66.02569580078125 -47.67873764038086 -67.50616455078125 -48.6268196105957 C -68.98662567138672 -49.57489776611328 -69.73050689697266 -52.08366394042969 -69.05955505371094 -53.87772369384766 C -68.39590454101562 -55.66448974609375 -66.32470703125 -56.73654937744141 -64.333740234375 -56.70737838745117 C -62.34276962280273 -56.68550109863281 -60.43202209472656 -55.56239318847656 -59.98715591430664 -54.07463455200195 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_m04p2i =
    '<svg viewBox="77.4 129.8 235.0 132.0" ><path transform="translate(77.39, 129.81)" d="M 41.5 0 L 193.5 0 C 216.4198150634766 0 235 18.58018112182617 235 41.5 L 235 132 L 41.5 132 C 18.58018112182617 132 0 113.4198150634766 0 90.5 L 0 41.5 C 0 18.58018112182617 18.58018112182617 0 41.5 0 Z" fill="#115173" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_wnefp =
    '<svg viewBox="78.2 379.8 235.6 64.2" ><path transform="translate(78.22, 379.81)" d="M 32.08093643188477 0 L 203.4722290039062 0 C 221.1900482177734 0 235.5531768798828 14.36312389373779 235.5531768798828 32.08093643188477 L 235.5531768798828 64.16187286376953 L 32.08093643188477 64.16187286376953 C 14.36312389373779 64.16187286376953 0 49.79874801635742 0 32.08093643188477 C 0 14.36312389373779 14.36312389373779 0 32.08093643188477 0 Z" fill="#115173" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_kx7cpj =
    '<svg viewBox="0.0 0.0 29.3 29.3" ><path  d="M 0 0 L 29.333984375 0 L 29.333984375 29.333984375 L 0 29.333984375 L 0 0 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_io510 =
    '<svg viewBox="76.0 736.0 282.0 49.0" ><path transform="translate(76.0, 736.0)" d="M 24.5 0 L 257.5 0 C 271.0309753417969 0 282 10.96902275085449 282 24.5 C 282 38.03097534179688 271.0309753417969 49 257.5 49 L 24.5 49 C 10.96902275085449 49 0 38.03097534179688 0 24.5 C 0 10.96902275085449 10.96902275085449 0 24.5 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_vbumi6 =
    '<svg viewBox="0.0 0.0 22.1 17.4" ><path transform="translate(0.0, -44.8)" d="M 21.3242301940918 47.50484466552734 C 20.8839054107666 47.04355239868164 20.27584075927734 46.77097320556641 19.58390235900879 46.77097320556641 L 16.10325050354004 46.77097320556641 L 16.10325050354004 46.72903442382812 C 16.10325050354004 46.20484161376953 15.89357280731201 45.70161437988281 15.5371208190918 45.36612701416016 C 15.18066883087158 45.00967788696289 14.69841003417969 44.79999923706055 14.17421436309814 44.79999923706055 L 7.883877277374268 44.79999923706055 C 7.338715076446533 44.79999923706055 6.856455326080322 45.00967788696289 6.500003337860107 45.36612701416016 C 6.143550395965576 45.72257995605469 5.933872699737549 46.20484161376953 5.933872699737549 46.72903442382812 L 5.933872699737549 46.77097320556641 L 2.474187612533569 46.77097320556641 C 1.7822505235672 46.77097320556641 1.174184679985046 47.04355239868164 0.7338611483573914 47.50484466552734 C 0.2935376465320587 47.94516754150391 -1.1444091796875e-05 48.57420349121094 -1.1444091796875e-05 49.24517059326172 L -1.1444091796875e-05 59.68712615966797 C -1.084419818653259e-05 60.37906646728516 0.2725704312324524 60.98713684082031 0.7338617444038391 61.42745208740234 C 1.174185276031494 61.86777496337891 1.803218960762024 62.16133117675781 2.474188566207886 62.16133117675781 L 19.58390426635742 62.16133117675781 C 20.27584075927734 62.16133117675781 20.8839054107666 61.88874816894531 21.32423210144043 61.42745208740234 C 21.76455497741699 60.98713684082031 22.05810546875 60.35810089111328 22.05810546875 59.68712615966797 L 22.05810546875 49.24517059326172 C 22.05810356140137 48.55323028564453 21.78552055358887 47.94516754150391 21.3242301940918 47.50484466552734 Z M 20.9677791595459 59.68712615966797 L 20.94681167602539 59.68712615966797 C 20.94681167602539 60.06455230712891 20.80003547668457 60.40003204345703 20.54842376708984 60.65164184570312 C 20.29680824279785 60.90325927734375 19.96132278442383 61.05003356933594 19.58390426635742 61.05003356933594 L 2.474188566207886 61.05003356933594 C 2.096768140792847 61.05003356933594 1.761283278465271 60.90325927734375 1.509669899940491 60.65164184570312 C 1.258056402206421 60.40003204345703 1.111281991004944 60.06454467773438 1.111281991004944 59.68712615966797 L 1.111281991004944 49.24517059326172 C 1.111281991004944 48.86775207519531 1.258056402206421 48.53226470947266 1.509669899940491 48.2806510925293 C 1.761283397674561 48.02903747558594 2.096768140792847 47.88226318359375 2.474188566207886 47.88226318359375 L 6.520970821380615 47.88226318359375 C 6.835487842559814 47.88226318359375 7.087101459503174 47.63065338134766 7.087101459503174 47.31613540649414 L 7.087101459503174 46.70806884765625 C 7.087101459503174 46.47742080688477 7.170973300933838 46.26774597167969 7.317747116088867 46.12096786499023 C 7.464520454406738 45.97419738769531 7.674199104309082 45.89032363891602 7.904844760894775 45.89032363891602 L 14.17421436309814 45.89032363891602 C 14.40485954284668 45.89032363891602 14.61453723907471 45.97419738769531 14.76131248474121 46.12096786499023 C 14.9080867767334 46.26774597167969 14.99195861816406 46.47742462158203 14.99195861816406 46.70806884765625 L 14.99195861816406 47.31613159179688 C 14.99195861816406 47.63065338134766 15.24357128143311 47.88226318359375 15.55808925628662 47.88226318359375 L 19.60487174987793 47.88226318359375 C 19.98229217529297 47.88226318359375 20.31777763366699 48.02903747558594 20.56939125061035 48.2806510925293 C 20.82100296020508 48.53226470947266 20.9677791595459 48.86774826049805 20.9677791595459 49.24517059326172 L 20.9677791595459 59.68712615966797 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lp1ix9 =
    '<svg viewBox="5.9 4.5 10.3 10.3" ><path transform="translate(-106.13, -126.29)" d="M 117.1580581665039 130.8000030517578 C 115.7322463989258 130.8000030517578 114.4322509765625 131.3870849609375 113.5096664428711 132.3096771240234 C 112.5661163330078 133.2532348632812 111.9999847412109 134.5322723388672 111.9999847412109 135.9580688476562 C 111.9999847412109 137.3838806152344 112.5870819091797 138.6838836669922 113.5096664428711 139.6064758300781 C 114.4532089233398 140.5500183105469 115.7322463989258 141.1161499023438 117.1580581665039 141.1161499023438 C 118.583869934082 141.1161499023438 119.8838729858398 140.529052734375 120.8064575195312 139.6064758300781 C 121.75 138.6629180908203 122.3161392211914 137.3838806152344 122.3161392211914 135.9580688476562 C 122.3161392211914 134.5322723388672 121.7290420532227 133.2322692871094 120.8064575195312 132.3096771240234 C 119.8838729858398 131.3870849609375 118.583869934082 130.8000030517578 117.1580581665039 130.8000030517578 Z M 120.0096817016602 138.8306579589844 C 119.2758102416992 139.5435638427734 118.2693557739258 140.0048522949219 117.1580581665039 140.0048522949219 C 116.0467681884766 140.0048522949219 115.0403137207031 139.5435638427734 114.3064422607422 138.8306579589844 C 113.5725708007812 138.0967864990234 113.1322479248047 137.09033203125 113.1322479248047 135.9790344238281 C 113.1322479248047 134.8677520751953 113.5935363769531 133.8612976074219 114.3064422607422 133.1274261474609 C 115.0403137207031 132.3935546875 116.0467681884766 131.9532318115234 117.1580581665039 131.9532318115234 C 118.2693557739258 131.9532318115234 119.2758102416992 132.4145202636719 120.0096817016602 133.1274261474609 C 120.7435531616211 133.8612976074219 121.1838760375977 134.8677520751953 121.1838760375977 135.9790344238281 C 121.2048416137695 137.09033203125 120.7435531616211 138.0967864990234 120.0096817016602 138.8306579589844 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tjds53 =
    '<svg viewBox="-6.0 68.0 25.3 21.9" ><path transform="translate(-6.0, 32.89)" d="M 23.8277530670166 43.78146743774414 L 3.385984420776367 35.29932022094727 C 2.524804830551147 34.94194412231445 1.551889300346375 35.09915542602539 0.8469818830490112 35.70940017700195 C 0.1420744508504868 36.31974411010742 -0.1527544558048248 37.2601432800293 0.07764557003974915 38.1635856628418 L 1.897142887115479 45.29886245727539 L 10.80564785003662 45.29886245727539 C 11.21557807922363 45.29886245727539 11.54796504974365 45.63119888305664 11.54796504974365 46.04117584228516 C 11.54796504974365 46.45110702514648 11.21562671661377 46.78349685668945 10.80564785003662 46.78349685668945 L 1.897142887115479 46.78349685668945 L 0.07764557003974915 53.91872406005859 C -0.1527544558048248 54.82220840454102 0.1420249789953232 55.76261520385742 0.8469817638397217 56.37290954589844 C 1.553324222564697 56.98439025878906 2.526338815689087 57.13967132568359 3.386033773422241 56.78298568725586 L 23.82780265808105 48.3008918762207 C 24.75850677490234 47.91471481323242 25.33663558959961 47.04883193969727 25.33663558959961 46.04117584228516 C 25.33663558959961 45.03352355957031 24.75850677490234 44.16759490966797 23.8277530670166 43.78146743774414 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
