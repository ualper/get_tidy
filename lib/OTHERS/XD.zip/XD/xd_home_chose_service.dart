import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_home_service_recipient.dart';
import 'package:adobe_xd/page_link.dart';
import 'xdlabel.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDHomeChoseService extends StatelessWidget {
  XDHomeChoseService({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 199.0, middle: 0.5),
            Pin(size: 71.0, middle: 0.2634),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 27,
                  color: const Color(0xffffffff),
                  height: 1.3333333333333333,
                ),
                children: [
                  TextSpan(
                    text: 'Hi ! Choose your\n ',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'Service Type',
                    style: TextStyle(
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 166.0, start: 16.0),
            Pin(size: 129.0, middle: 0.4466),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 129.0, middle: 0.4451),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 166.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.5306, endFraction: 0.0321),
                  Pin(size: 52.0, middle: 0.6502),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Provider',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.0, endFraction: 0.5335),
                  Pin(size: 52.0, middle: 0.6502),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Recipient',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, start: 26.0),
            Pin(size: 2.0, middle: 0.4309),
            child: SvgPicture.string(
              _svg_x07t56,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 24.0),
            Pin(size: 12.0, middle: 0.6738),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, middle: 0.5022),
            Pin(size: 50.0, end: 55.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDHomeServiceRecipient(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.0),
                        color: const Color(0xff053f5e),
                        border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 56.0, middle: 0.5),
                    Pin(size: 14.0, middle: 0.5278),
                    child: Text(
                      'Continue',
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 14,
                        color: const Color(0xffffffff),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, end: 35.0),
            Pin(size: 2.0, middle: 0.4309),
            child: SvgPicture.string(
              _svg_gumch4,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 26.0, end: 25.0),
            Pin(size: 196.0, middle: 0.7776),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 21,
                  color: const Color(0xff115173),
                ),
                children: [
                  TextSpan(
                    text: 'WHAT DO YOU NEED?\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Recipient: \n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text:
                        'Do you want to dry-clean your clothes \nor find the nearest ironing service\n without wasting your time?\n',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  TextSpan(
                    text: '\n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Provider: \n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: ' ',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text:
                        'Are you seeking service for your dry cleaning \nor serving people by ironing from your home?',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 12.5, end: 12.5),
            Pin(size: 13.0, middle: 0.563),
            child: SvgPicture.string(
              _svg_a7g5yb,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, start: 29.0),
            Pin(size: 2.0, middle: 0.5062),
            child: SvgPicture.string(
              _svg_faakc,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, end: 35.0),
            Pin(size: 2.0, middle: 0.5037),
            child: SvgPicture.string(
              _svg_b2og,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.3, end: 18.8),
            Pin(size: 81.7, start: 97.3),
            child: XDLABEL(),
          ),
        ],
      ),
    );
  }
}

const String _svg_x07t56 =
    '<svg viewBox="26.0 349.0 140.0 2.0" ><path transform="translate(24.0, 289.0)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gumch4 =
    '<svg viewBox="200.0 349.0 140.0 2.0" ><path transform="translate(198.0, 289.0)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_a7g5yb =
    '<svg viewBox="12.5 449.8 350.0 13.0" ><path transform="translate(10.5, 389.82)" d="M 346.1666259765625 73.01165771484375 L 7.833333969116211 73.01165771484375 C 4.611672878265381 73.01165771484375 1.999999761581421 70.09886932373047 1.999999761581421 66.50578308105469 C 1.999999761581421 62.91275787353516 4.611672878265381 60 7.833333969116211 60 L 346.1666259765625 60 C 349.3883056640625 60 351.9999694824219 62.91275787353516 351.9999694824219 66.50578308105469 C 351.9999694824219 70.09886932373047 349.3883056640625 73.01165771484375 346.1666259765625 73.01165771484375 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_faakc =
    '<svg viewBox="29.0 410.0 140.0 2.0" ><path transform="translate(27.0, 350.0)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b2og =
    '<svg viewBox="200.0 408.0 140.0 2.0" ><path transform="translate(198.0, 348.0)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
