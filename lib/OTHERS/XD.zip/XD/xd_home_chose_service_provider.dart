import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component21.dart';
import 'xd_provider_main.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDHomeChoseServiceProvider extends StatelessWidget {
  XDHomeChoseServiceProvider({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 199.0, start: 32.3),
            Pin(size: 71.0, middle: 0.2065),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 27,
                  color: const Color(0xffffffff),
                  height: 1.3333333333333333,
                ),
                children: [
                  TextSpan(
                    text: 'Hi ! Choose your\n ',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'Service Type',
                    style: TextStyle(
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.5, end: 21.5),
            Pin(size: 1.0, start: 118.0),
            child: SvgPicture.string(
              _svg_ei5636,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 166.0, start: 17.0),
            Pin(size: 244.0, middle: 0.4577),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 24.0, start: 8.0),
                  Pin(size: 24.0, start: 9.0),
                  child:
                      // Adobe XD layer: 'Radio Button' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Dot 2' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                            color: const Color(0x0f000000),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 5.0, end: 5.0),
                        Pin(start: 5.0, end: 5.0),
                        child:
                            // Adobe XD layer: 'Dot 2' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                            color: const Color(0xfffffcfc),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 20.0, end: 15.0),
            Pin(size: 244.0, middle: 0.456),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 166.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.5353, endFraction: 0.0235),
                  Pin(size: 52.0, middle: 0.9167),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Provider',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 24.0, middle: 0.5759),
                  Pin(size: 24.0, start: 9.0),
                  child:
                      // Adobe XD layer: 'Radio Button' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Dot 2' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                            color: const Color(0x0f000000),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 5.0, end: 5.0),
                        Pin(start: 5.0, end: 5.0),
                        child:
                            // Adobe XD layer: 'Dot 2' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                            color: const Color(0xff022c43),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.0, endFraction: 0.5294),
                  Pin(size: 52.0, middle: 0.9167),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Recipient',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, start: 30.0),
            Pin(size: 2.0, middle: 0.5308),
            child: SvgPicture.string(
              _svg_nm0cc,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 267.0, start: 22.0),
            Pin(size: 60.0, start: 44.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 209.0, end: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: XDComponent21(),
                      ),
                      Pinned.fromPins(
                        Pin(size: 9.4, middle: 0.51),
                        Pin(size: 8.5, start: 5.3),
                        child:
                            // Adobe XD layer: 'blob (1)' (shape)
                            SvgPicture.string(
                          _svg_y89p,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 26.0),
            Pin(size: 12.0, middle: 0.7163),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, middle: 0.5109),
            Pin(size: 50.0, end: 21.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDProviderMain(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.0),
                        color: const Color(0xff053f5e),
                        border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 56.0, middle: 0.5),
                    Pin(size: 14.0, middle: 0.5278),
                    child: Text(
                      'Continue',
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 14,
                        color: const Color(0xffffffff),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, end: 31.0),
            Pin(size: 2.0, middle: 0.5308),
            child: SvgPicture.string(
              _svg_gex6cv,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 36.0, end: 35.0),
            Pin(size: 186.0, end: 101.0),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 20,
                  color: const Color(0xff115173),
                ),
                children: [
                  TextSpan(
                    text: 'WHAT DO YOU NEED?\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Recipient: \n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text:
                        'Do you want to dry-clean your clothes \nor find the nearest ironing service\n without wasting your time?\n',
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                  TextSpan(
                    text: '\n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Provider: \n',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: ' ',
                    style: TextStyle(
                      fontSize: 15,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text:
                        'Are you seeking service for your dry cleaning \nor serving people by ironing from your home?',
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 15.0, end: 10.0),
            Pin(size: 2.0, middle: 0.6444),
            child: SvgPicture.string(
              _svg_y62wxz,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ei5636 =
    '<svg viewBox="21.5 118.0 332.0 1.0" ><path transform="translate(21.5, 118.0)" d="M 0 0 L 332 0" fill="none" stroke="#febf48" stroke-width="1" stroke-dasharray="4 4" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_y89p =
    '<svg viewBox="101.8 5.3 9.4 8.5" ><path transform="translate(171.1, 62.01)" d="M -59.98715591430664 -54.07463455200195 C -59.54228591918945 -52.58687591552734 -60.56329345703125 -50.74176406860352 -62.18232345581055 -49.51655578613281 C -63.80864715576172 -48.29134368896484 -66.02569580078125 -47.67873764038086 -67.50616455078125 -48.6268196105957 C -68.98662567138672 -49.57489776611328 -69.73050689697266 -52.08366394042969 -69.05955505371094 -53.87772369384766 C -68.39590454101562 -55.66448974609375 -66.32470703125 -56.73654937744141 -64.333740234375 -56.70737838745117 C -62.34276962280273 -56.68550109863281 -60.43202209472656 -55.56239318847656 -59.98715591430664 -54.07463455200195 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nm0cc =
    '<svg viewBox="30.0 429.9 140.0 2.0" ><path transform="translate(28.0, 369.93)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gex6cv =
    '<svg viewBox="204.0 429.9 140.0 2.0" ><path transform="translate(202.0, 369.93)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_y62wxz =
    '<svg viewBox="15.0 522.0 350.0 2.0" ><path transform="translate(13.0, 462.0)" d="M 346.1666259765625 62.00000381469727 L 7.833333969116211 62.00000381469727 C 4.611672878265381 62.00000381469727 1.999999761581421 61.55228424072266 1.999999761581421 61 C 1.999999761581421 60.44771957397461 4.611672878265381 60.00000381469727 7.833333969116211 60.00000381469727 L 346.1666259765625 60.00000381469727 C 349.3883056640625 60.00000381469727 351.9999694824219 60.44771957397461 351.9999694824219 61 C 351.9999694824219 61.55228424072266 349.3883056640625 62.00000381469727 346.1666259765625 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
