import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component71.dart';
import 'xd_checkout_edit_card3.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_checkout_order_summary2.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDCheckoutEditCard2 extends StatelessWidget {
  XDCheckoutEditCard2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 21.0, end: 15.0),
            Pin(size: 1.0, middle: 0.2121),
            child:
                // Adobe XD layer: 'Divider' (shape)
                Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                border: Border.all(width: 0.5, color: const Color(0xffebebeb)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 329.0, middle: 0.7453),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28.0),
                      color: const Color(0xffffffff),
                      border: Border.all(width: 0.6, color: const Color(0xffe2e2e2)),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x0a000000),
                          offset: Offset(0, 3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 21.0, end: 20.0),
                  Pin(start: 34.0, end: 33.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 153.0, end: 0.0),
                        Pin(size: 64.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'CVV' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 1.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Field' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(width: 0.5, color: const Color(0xffdddddd)),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 27.0, start: 0.0),
                              Pin(size: 16.0, middle: 0.7708),
                              child: Text(
                                '908',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 16,
                                  color: const Color(0xff000000),
                                  height: 2,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 29.0, start: 0.0),
                              Pin(size: 14.0, start: 0.0),
                              child: Text(
                                'CVV',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 14,
                                  color: const Color(0x80000000),
                                  height: 2.2857142857142856,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 153.0, start: 0.0),
                        Pin(size: 64.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Expiry' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 1.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Field' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(width: 0.5, color: const Color(0xffdddddd)),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 49.0, start: 0.0),
                              Pin(size: 16.0, middle: 0.7708),
                              child: Text(
                                '08 / 20',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 16,
                                  color: const Color(0xff000000),
                                  height: 2,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 72.0, start: 0.0),
                              Pin(size: 14.0, start: 0.0),
                              child: Text(
                                'Expiry Date',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 14,
                                  color: const Color(0x80000000),
                                  height: 2.2857142857142856,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 64.0, middle: 0.5101),
                        child:
                            // Adobe XD layer: 'Card Number' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 1.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Field' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(width: 0.5, color: const Color(0xffdddddd)),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 182.0, start: 0.0),
                              Pin(size: 16.0, middle: 0.7708),
                              child: Text(
                                '4960   5689   3124   4748',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 16,
                                  color: const Color(0xff000000),
                                  height: 2,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 84.0, start: 0.0),
                              Pin(size: 14.0, start: 0.0),
                              child: Text(
                                'Card Number',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 14,
                                  color: const Color(0x80000000),
                                  height: 2.2857142857142856,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 42.0, end: 0.3),
                              Pin(size: 30.0, middle: 0.6534),
                              child:
                                  // Adobe XD layer: 'Icon_MasterCard' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: SvgPicture.string(
                                      _svg_xis5,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 20.0, end: 5.0),
                                    Pin(start: 5.0, end: 5.0),
                                    child: SvgPicture.string(
                                      _svg_rngui,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 20.0, start: 4.0),
                                    Pin(start: 5.0, end: 5.0),
                                    child: SvgPicture.string(
                                      _svg_gyw7ol,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 66.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'Card Holder' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 1.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Field' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(width: 0.5, color: const Color(0xffdddddd)),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 95.0, start: 0.0),
                              Pin(size: 18.0, middle: 0.7708),
                              child: Text(
                                'Sujen Matin',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 18,
                                  color: const Color(0xff000000),
                                  height: 1.7777777777777777,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 91.0, start: 0.0),
                              Pin(size: 14.0, start: 0.0),
                              child: Text(
                                'Name on Card',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 14,
                                  color: const Color(0x80000000),
                                  height: 2.2857142857142856,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: -286.0, end: -287.0),
            Pin(size: 190.0, middle: 0.2444),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 299.0, start: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20.0),
                                  gradient: LinearGradient(
                                    begin: Alignment(-0.31, -1.0),
                                    end: Alignment(1.0, 1.44),
                                    colors: [
                                      const Color(0xffe2b34b),
                                      const Color(0xff52d9b5),
                                      const Color(0xffeb4cf8)
                                    ],
                                    stops: [0.0, 0.502, 1.0],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xffc3cfe2),
                                      offset: Offset(0, 1),
                                      blurRadius: 30,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 207.0, start: 31.0),
                              Pin(size: 29.0, middle: 0.5875),
                              child: Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(size: 130.0, start: 0.0),
                                    Pin(size: 22.0, end: 0.0),
                                    child: Text(
                                      '****  ****  ****',
                                      style: TextStyle(
                                        fontFamily: 'Karla',
                                        fontSize: 22,
                                        color: const Color(0xffffffff),
                                        letterSpacing: 0.22,
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 60.0, end: 0.0),
                                    Pin(start: 0.0, end: 2.0),
                                    child: Text(
                                      '2486',
                                      style: TextStyle(
                                        fontFamily: 'Karla',
                                        fontSize: 27,
                                        color: const Color(0xffffffff),
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 55.5, start: 29.2),
                              Pin(size: 33.4, middle: 0.1928),
                              child:
                                  // Adobe XD layer: 'Mastercard' (group)
                                  Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(size: 33.2, end: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: SvgPicture.string(
                                      _svg_eqha6,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 1.1, end: 1.1),
                                    Pin(size: 1.1, middle: 0.7881),
                                    child: SvgPicture.string(
                                      _svg_om42,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 33.2, start: 0.0),
                                    Pin(start: 0.0, end: 0.0),
                                    child: SvgPicture.string(
                                      _svg_b580j7,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 1.1, end: 1.1),
                                    Pin(size: 1.1, middle: 0.6202),
                                    child: SvgPicture.string(
                                      _svg_zhnhu4,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 1.6, end: 1.6),
                                    Pin(size: 8.8, middle: 0.5058),
                                    child: SvgPicture.string(
                                      _svg_x4nhq3,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 75.0, start: 29.0),
                              Pin(size: 12.0, middle: 0.8192),
                              child: Text(
                                'Expires 21-24',
                                style: TextStyle(
                                  fontFamily: 'Karla',
                                  fontSize: 12,
                                  color: const Color(0xffffffff),
                                  letterSpacing: 0.12,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 299.0, end: 0.0),
                  Pin(start: 1.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20.0),
                            gradient: LinearGradient(
                              begin: Alignment(-1.0, -1.0),
                              end: Alignment(1.64, 1.8),
                              colors: [
                                const Color(0xff7ee2d2),
                                const Color(0xff829df7),
                                const Color(0xffa234fb),
                                const Color(0xff5489f9),
                                const Color(0xff4994f9)
                              ],
                              stops: [0.0, 0.256, 0.602, 0.953, 1.0],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xffc3cfe2),
                                offset: Offset(0, 1),
                                blurRadius: 30,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 207.0, start: 31.0),
                        Pin(size: 29.0, middle: 0.5875),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 130.0, start: 0.0),
                              Pin(size: 22.0, end: 0.0),
                              child: Text(
                                '****  ****  ****',
                                style: TextStyle(
                                  fontFamily: 'Karla',
                                  fontSize: 22,
                                  color: const Color(0xffffffff),
                                  letterSpacing: 0.22,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 60.0, end: 0.0),
                              Pin(start: 0.0, end: 2.0),
                              child: Text(
                                '2486',
                                style: TextStyle(
                                  fontFamily: 'Karla',
                                  fontSize: 27,
                                  color: const Color(0xffffffff),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 55.5, start: 29.2),
                        Pin(size: 33.4, middle: 0.1928),
                        child:
                            // Adobe XD layer: 'Mastercard' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 33.2, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: SvgPicture.string(
                                _svg_eqha6,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.1, end: 1.1),
                              Pin(size: 1.1, middle: 0.7881),
                              child: SvgPicture.string(
                                _svg_om42,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 33.2, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: SvgPicture.string(
                                _svg_b580j7,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.1, end: 1.1),
                              Pin(size: 1.1, middle: 0.6202),
                              child: SvgPicture.string(
                                _svg_zhnhu4,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 1.6, end: 1.6),
                              Pin(size: 8.8, middle: 0.5058),
                              child: SvgPicture.string(
                                _svg_x4nhq3,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 75.0, start: 29.0),
                        Pin(size: 12.0, middle: 0.8192),
                        child: Text(
                          'Expires 21-24',
                          style: TextStyle(
                            fontFamily: 'Karla',
                            fontSize: 12,
                            color: const Color(0xffffffff),
                            letterSpacing: 0.12,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 299.0, middle: 0.5008),
                  Pin(start: 0.0, end: 0.1),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.9, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20.0),
                            gradient: LinearGradient(
                              begin: Alignment(1.0, 1.38),
                              end: Alignment(-0.77, -1.0),
                              colors: [
                                const Color(0xffe45ae5),
                                const Color(0xfff7a482),
                                const Color(0xffa234fb),
                                const Color(0xff4994f9)
                              ],
                              stops: [0.0, 0.377, 0.741, 1.0],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xffc3cfe2),
                                offset: Offset(0, 1),
                                blurRadius: 30,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 217.9, end: 15.1),
                        Pin(start: 0.0, end: 1.0),
                        child: SvgPicture.string(
                          _svg_atkter,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 217.9, start: 0.0),
                        Pin(start: 0.0, end: 1.0),
                        child: SvgPicture.string(
                          _svg_m88ne,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 165.9, start: 0.0),
                        Pin(start: 0.5, end: 1.0),
                        child: SvgPicture.string(
                          _svg_gmmrz,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 207.0, start: 31.0),
                        Pin(size: 29.0, middle: 0.5898),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 130.0, start: 0.0),
                              Pin(size: 22.0, end: 0.0),
                              child: Text(
                                '****  ****  ****',
                                style: TextStyle(
                                  fontFamily: 'Karla',
                                  fontSize: 22,
                                  color: const Color(0xffffffff),
                                  letterSpacing: 0.22,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 60.0, end: 0.0),
                              Pin(start: 0.0, end: 2.0),
                              child: Text(
                                '4748',
                                style: TextStyle(
                                  fontFamily: 'Karla',
                                  fontSize: 27,
                                  color: const Color(0xffffffff),
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 55.5, start: 29.2),
                        Pin(size: 33.4, middle: 0.1975),
                        child:
                            // Adobe XD layer: 'Mastercard' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 33.2, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: SvgPicture.string(
                                _svg_eqha6,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.1, end: 1.1),
                              Pin(size: 1.1, middle: 0.7881),
                              child: SvgPicture.string(
                                _svg_om42,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 33.2, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: SvgPicture.string(
                                _svg_b580j7,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.1, end: 1.1),
                              Pin(size: 1.1, middle: 0.6202),
                              child: SvgPicture.string(
                                _svg_zhnhu4,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 1.6, end: 1.6),
                              Pin(size: 8.8, middle: 0.5058),
                              child: SvgPicture.string(
                                _svg_x4nhq3,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 75.0, start: 29.0),
                        Pin(size: 12.0, middle: 0.8201),
                        child: Text(
                          'Expires 21-24',
                          style: TextStyle(
                            fontFamily: 'Karla',
                            fontSize: 12,
                            color: const Color(0xffffffff),
                            letterSpacing: 0.12,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: XDComponent71(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 84.0, end: 0.0),
            child:
                // Adobe XD layer: 'Bottom' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'BG' (shape)
                      SvgPicture.string(
                    _svg_izk15e,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 146.0, end: 30.0),
                  Pin(size: 50.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Primary Button - Sm…' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Button' (shape)
                            PageLink(
                          links: [
                            PageLinkInfo(
                              transition: LinkTransition.Fade,
                              ease: Curves.easeOut,
                              duration: 0.3,
                              pageBuilder: () => XDCheckoutEditCard3(),
                            ),
                          ],
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25.0),
                              color: const Color(0xffff7f00),
                            ),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 26.0, middle: 0.5),
                        Pin(size: 14.0, middle: 0.5278),
                        child: Text(
                          'PAY',
                          style: TextStyle(
                            fontFamily: 'SF Pro Text',
                            fontSize: 14,
                            color: const Color(0xffffffff),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 146.0, start: 30.0),
                  Pin(size: 50.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Secondary Button - …' (group)
                      PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => XDCheckoutOrderSummary2(),
                      ),
                    ],
                    child: Stack(
                      children: <Widget>[
                        Pinned.fromPins(
                          Pin(start: 0.0, end: 0.0),
                          Pin(start: 0.0, end: 0.0),
                          child:
                              // Adobe XD layer: 'Button' (shape)
                              Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25.0),
                              border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                            ),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 38.0, middle: 0.5),
                          Pin(size: 14.0, middle: 0.5278),
                          child: Text(
                            'BACK',
                            style: TextStyle(
                              fontFamily: 'SF Pro Text',
                              fontSize: 14,
                              color: const Color(0xffffffff),
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_xis5 =
    '<svg viewBox="0.0 0.0 42.0 30.0" ><path transform="translate(-3.0, -9.0)" d="M 45 35 C 45 37.21089935302734 43.21089935302734 39 41 39 L 7 39 C 4.789060115814209 39 3 37.21089935302734 3 35 L 3 13 C 3 10.78909969329834 4.789060115814209 9 7 9 L 41 9 C 43.21089935302734 9 45 10.78909969329834 45 13 L 45 35 Z" fill="#3f51b5" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_rngui =
    '<svg viewBox="17.0 5.0 20.0 20.0" ><path transform="translate(-3.0, -9.0)" d="M 40 24 C 40 29.52339935302734 35.52339935302734 34 30 34 C 24.47660064697266 34 20 29.52339935302734 20 24 C 20 18.47660064697266 24.47660064697266 14 30 14 C 35.52339935302734 14 40 18.47660064697266 40 24 Z" fill="#ffc107" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gyw7ol =
    '<svg viewBox="4.0 5.0 20.0 20.0" ><path transform="translate(-3.0, -9.0)" d="M 22.01560020446777 30 C 21.55080032348633 29.38279914855957 21.15229988098145 28.71479988098145 20.83979988098145 28 L 26.16410064697266 28 C 26.4414005279541 27.36330032348633 26.66020011901855 26.69529914855957 26.80080032348633 26 L 20.20310020446777 26 C 20.07029914855957 25.35549926757812 20 24.6875 20 24 L 27 24 C 27 23.3125 26.92970085144043 22.64450073242188 26.80080032348633 22 L 20.19919967651367 22 C 20.34379959106445 21.30470085144043 20.5585994720459 20.63669967651367 20.83979988098145 20 L 26.16410064697266 20 C 25.85160064697266 19.28520011901855 25.45310020446777 18.61720085144043 24.98830032348633 18 L 22.01560020446777 18 C 22.44919967651367 17.42189979553223 22.94529914855957 16.8789005279541 23.4960994720459 16.40629959106445 C 21.7460994720459 14.91020011901855 19.48049926757812 14 17 14 C 11.47659969329834 14 7 18.47660064697266 7 24 C 7 29.52339935302734 11.47659969329834 34 17 34 C 20.26950073242188 34 23.16020011901855 32.42580032348633 24.98439979553223 30 L 22.01560020446777 30 Z" fill="#ff3d00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_eqha6 =
    '<svg viewBox="22.3 0.0 33.2 33.4" ><path transform="translate(-833.93, 0.1)" d="M 861.674560546875 28.96328163146973 C 864.5977172851562 31.65764427185059 868.52490234375 33.29091262817383 872.7952880859375 33.29091262817383 C 881.9654541015625 33.29091262817383 889.387939453125 25.81118583679199 889.387939453125 16.60977172851562 C 889.387939453125 7.382350444793701 881.9654541015625 -0.0999755859375 872.7952880859375 -0.0999755859375 C 868.52490234375 -0.0999755859375 864.5977172851562 1.533288598060608 861.674560546875 4.227653503417969 C 858.3222045898438 7.296525001525879 856.2000122070312 11.70998001098633 856.2000122070312 16.61237144470215 C 856.2000122070312 21.51216506958008 858.3222045898438 25.92561721801758 861.674560546875 28.96328163146973 L 861.674560546875 28.96328163146973 Z" fill="#e9b040" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_om42 =
    '<svg viewBox="53.3 25.5 1.1 1.1" ><path transform="translate(-1994.25, -954.22)" d="M 2047.499877929688 980.2149658203125 C 2047.499877929688 979.9288330078125 2047.728881835938 979.699951171875 2048.014892578125 979.699951171875 C 2048.329345703125 979.699951171875 2048.55810546875 979.9288330078125 2048.55810546875 980.2149658203125 C 2048.55810546875 980.5296630859375 2048.329345703125 980.7584228515625 2048.014892578125 980.7584228515625 C 2047.728881835938 980.7584228515625 2047.499877929688 980.5296630859375 2047.499877929688 980.2149658203125 Z M 2048.014892578125 980.6466064453125 C 2048.24365234375 980.6466064453125 2048.44384765625 980.4464111328125 2048.44384765625 980.217529296875 C 2048.44384765625 979.9886474609375 2048.24365234375 979.8170166015625 2048.014892578125 979.8170166015625 C 2047.814575195312 979.8170166015625 2047.614379882812 979.9886474609375 2047.614379882812 980.217529296875 C 2047.614379882812 980.44384765625 2047.814575195312 980.6466064453125 2048.014892578125 980.6466064453125 Z M 2047.957641601562 980.472412109375 L 2047.843139648438 980.472412109375 L 2047.843139648438 979.986083984375 L 2048.04345703125 979.986083984375 C 2048.07177734375 979.986083984375 2048.129150390625 979.986083984375 2048.157958984375 980.0146484375 C 2048.215087890625 980.043212890625 2048.215087890625 980.0718994140625 2048.215087890625 980.1290283203125 C 2048.215087890625 980.186279296875 2048.186279296875 980.2435302734375 2048.129150390625 980.2435302734375 L 2048.24365234375 980.472412109375 L 2048.100341796875 980.472412109375 L 2048.04345703125 980.2720947265625 L 2047.957641601562 980.2720947265625 L 2047.957641601562 980.472412109375 L 2047.957641601562 980.186279296875 L 2048.07177734375 980.186279296875 C 2048.100341796875 980.186279296875 2048.100341796875 980.15771484375 2048.100341796875 980.1290283203125 C 2048.100341796875 980.1004638671875 2048.100341796875 980.1004638671875 2048.07177734375 980.0718994140625 L 2047.957641601562 980.0718994140625 L 2047.957641601562 980.472412109375 Z" fill="#e9b040" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b580j7 =
    '<svg viewBox="0.0 0.0 33.2 33.4" ><path transform="translate(0.0, 0.0)" d="M 33.10220718383789 14.93084144592285 C 33.04499053955078 14.33007144927979 32.93055725097656 13.75530624389648 32.81612396240234 13.15453720092773 L 22.67064094543457 13.15453720092773 C 22.78507423400879 12.55376625061035 22.95672416687012 11.97900295257568 23.12837219238281 11.40684032440186 L 32.32718658447266 11.40684032440186 C 32.12692642211914 10.80346870422363 31.89806175231934 10.21049976348877 31.64058685302734 9.630535125732422 L 23.84357261657715 9.630535125732422 C 24.12965393066406 9.024563789367676 24.44694519042969 8.431594848632812 24.79024124145508 7.854230880737305 L 30.66530990600586 7.854230880737305 C 30.28820419311523 7.243057727813721 29.86688613891602 6.657891750335693 29.40395355224609 6.106534957885742 L 26.05159950256348 6.106534957885742 C 26.56914710998535 5.471954822540283 27.13610649108887 4.878986358642578 27.74208068847656 4.330230236053467 C 24.79024124145508 1.661872267723083 20.89173698425293 0 16.59271430969238 0 C 7.451117038726807 0 0 7.479725360870361 0 16.70974731445312 C 0 25.91116142272949 7.451117038726807 33.39088821411133 16.59271430969238 33.39088821411133 C 20.89173698425293 33.39088821411133 24.79024124145508 31.75762176513672 27.74208068847656 29.06325721740723 C 28.34025001525879 28.52230262756348 28.89680862426758 27.93973922729492 29.40395355224609 27.3155632019043 L 26.05159950256348 27.3155632019043 C 25.59387016296387 26.74340057373047 25.19075584411621 26.16863632202148 24.79024124145508 25.53925895690918 L 30.66530990600586 25.53925895690918 C 31.03461647033691 24.97229766845703 31.35970687866211 24.37932777404785 31.64058685302734 23.76295280456543 L 23.84357261657715 23.76295280456543 C 23.58610153198242 23.1907901763916 23.32862854003906 22.61602783203125 23.12577056884766 22.01525688171387 L 32.32718658447266 22.01525688171387 C 32.52743911743164 21.44309425354004 32.67048263549805 20.8397216796875 32.81352233886719 20.23895072937012 C 32.92795562744141 19.66679000854492 33.04238891601562 19.06341743469238 33.09960174560547 18.462646484375 C 33.15681457519531 17.88268280029297 33.18542861938477 17.29751586914062 33.18542861938477 16.71495056152344 C 33.18802642822266 16.10637474060059 33.15942001342773 15.50560569763184 33.10220718383789 14.93084144592285 L 33.10220718383789 14.93084144592285 Z" fill="#cc2131" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_zhnhu4 =
    '<svg viewBox="53.3 20.0 1.1 1.1" ><path transform="translate(-1994.25, -750.26)" d="M 2047.499877929688 770.8435668945312 C 2047.499877929688 770.5288696289062 2047.728881835938 770.2999877929688 2048.014892578125 770.2999877929688 C 2048.329345703125 770.2999877929688 2048.55810546875 770.5288696289062 2048.55810546875 770.8435668945312 C 2048.55810546875 771.1295776367188 2048.329345703125 771.3870849609375 2048.014892578125 771.3870849609375 C 2047.728881835938 771.3896484375 2047.499877929688 771.1295776367188 2047.499877929688 770.8435668945312 Z M 2048.014892578125 771.2466430664062 C 2048.24365234375 771.2466430664062 2048.44384765625 771.074951171875 2048.44384765625 770.8461303710938 C 2048.44384765625 770.6173095703125 2048.24365234375 770.4456787109375 2048.014892578125 770.4456787109375 C 2047.814575195312 770.4456787109375 2047.614379882812 770.6173095703125 2047.614379882812 770.8461303710938 C 2047.614379882812 771.0723876953125 2047.814575195312 771.2466430664062 2048.014892578125 771.2466430664062 Z M 2047.957641601562 771.0723876953125 L 2047.843139648438 771.0723876953125 L 2047.843139648438 770.6146850585938 L 2048.157958984375 770.6146850585938 C 2048.215087890625 770.643310546875 2048.215087890625 770.7005004882812 2048.215087890625 770.7576904296875 C 2048.215087890625 770.786376953125 2048.186279296875 770.8435668945312 2048.129150390625 770.8721313476562 L 2048.24365234375 771.0723876953125 L 2048.100341796875 771.0723876953125 L 2048.04345703125 770.9007568359375 L 2047.957641601562 770.9007568359375 L 2047.957641601562 771.0723876953125 L 2047.957641601562 770.8148803710938 L 2048.014892578125 770.8148803710938 C 2048.04345703125 770.8148803710938 2048.07177734375 770.8148803710938 2048.07177734375 770.786376953125 C 2048.100341796875 770.786376953125 2048.100341796875 770.7576904296875 2048.100341796875 770.7291870117188 C 2048.100341796875 770.7291870117188 2048.100341796875 770.7005004882812 2048.07177734375 770.7005004882812 C 2048.07177734375 770.671875 2048.04345703125 770.7005004882812 2048.014892578125 770.7005004882812 L 2047.957641601562 770.7005004882812 L 2047.957641601562 771.0723876953125 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_x4nhq3 =
    '<svg viewBox="1.6 12.4 52.2 8.8" ><path transform="translate(-60.1, -465.76)" d="M 98.81514739990234 478.6316528320312 L 98.50045013427734 480.4652099609375 C 97.87107086181641 480.1505126953125 97.41073608398438 480.0075073242188 96.89580535888672 480.0075073242188 C 95.54860687255859 480.0075073242188 94.60194396972656 481.3260498046875 94.60194396972656 483.188232421875 C 94.60194396972656 484.4782104492188 95.2313232421875 485.2506103515625 96.29242706298828 485.2506103515625 C 96.7215576171875 485.2506103515625 97.23909759521484 485.1076049804688 97.81125640869141 484.8214721679688 L 97.49657440185547 486.7408447265625 C 96.83598327636719 486.9124755859375 96.4068603515625 486.9983520507812 95.92052459716797 486.9983520507812 C 93.97257232666016 486.9983520507812 92.76842498779297 485.5938720703125 92.76842498779297 483.3312377929688 C 92.76842498779297 480.3222045898438 94.43030548095703 478.2000122070312 96.80997467041016 478.2000122070312 C 97.12466430664062 478.2000122070312 97.41074371337891 478.2285766601562 97.63961791992188 478.2858276367188 L 98.357421875 478.4574584960938 C 98.58627319335938 478.5458984375 98.64348602294922 478.5745239257812 98.81514739990234 478.6316528320312 L 98.81514739990234 478.6316528320312 Z M 93.02589416503906 479.8931274414062 L 92.85424041748047 479.8931274414062 C 92.25347900390625 479.8931274414062 91.90757751464844 480.1791381835938 91.36402130126953 481.0114135742188 L 91.53566741943359 479.9503173828125 L 89.89980316162109 479.9503173828125 L 88.78148651123047 486.8292236328125 L 90.58640289306641 486.8292236328125 C 91.24440002441406 482.6160278320312 91.41603851318359 481.9008178710938 92.27688598632812 481.9008178710938 L 92.39131164550781 481.9008178710938 C 92.56295776367188 481.068603515625 92.79183197021484 480.4678955078125 93.07791137695312 479.92431640625 L 93.02589416503906 479.8931274414062 L 93.02589416503906 479.8931274414062 Z M 82.65154266357422 486.743408203125 C 82.16520690917969 486.9150390625 81.76209259033203 486.9722900390625 81.36158752441406 486.9722900390625 C 80.44351959228516 486.9722900390625 79.92857360839844 486.4573364257812 79.92857360839844 485.4534301757812 C 79.92857360839844 485.2818603515625 79.95717620849609 485.052978515625 79.98580169677734 484.85009765625 L 80.10022735595703 484.1635131835938 L 80.18605041503906 483.6199340820312 L 80.96106719970703 478.92041015625 L 82.73737335205078 478.92041015625 L 82.53711700439453 479.952880859375 L 83.45517730712891 479.952880859375 L 83.22631072998047 481.6433715820312 L 82.30564880371094 481.6433715820312 L 81.81930541992188 484.5093994140625 C 81.79070281982422 484.6238403320312 81.79070281982422 484.7096557617188 81.79070281982422 484.7954711914062 C 81.79070281982422 485.1387329101562 81.96235656738281 485.2818603515625 82.39147186279297 485.2818603515625 C 82.59172821044922 485.2818603515625 82.76337432861328 485.2818603515625 82.87781524658203 485.2245483398438 L 82.65154266357422 486.743408203125 L 82.65154266357422 486.743408203125 Z M 75.74398040771484 482.1271362304688 C 75.74398040771484 482.9879150390625 76.14450073242188 483.5887451171875 77.09116363525391 484.0464477539062 C 77.83757781982422 484.3897094726562 77.95201873779297 484.5042114257812 77.95201873779297 484.7929077148438 C 77.95201873779297 485.2219848632812 77.6373291015625 485.4222412109375 76.91951751708984 485.4222412109375 C 76.37596893310547 485.4222412109375 75.88702392578125 485.3363647460938 75.31485748291016 485.164794921875 L 75.05738830566406 486.7408447265625 L 75.14321136474609 486.7694091796875 L 75.45790100097656 486.82666015625 C 75.57233428955078 486.855224609375 75.71537780761719 486.8838500976562 75.94423675537109 486.8838500976562 C 76.34474945068359 486.9410400390625 76.69064331054688 486.9410400390625 76.91951751708984 486.9410400390625 C 78.81025695800781 486.9410400390625 79.69970703125 486.2232666015625 79.69970703125 484.647216796875 C 79.69970703125 483.7005615234375 79.32780456542969 483.156982421875 78.43834686279297 482.7278442382812 C 77.663330078125 482.3845825195312 77.57750701904297 482.2987670898438 77.57750701904297 481.9815063476562 C 77.57750701904297 481.6094970703125 77.89218902587891 481.4379272460938 78.46695709228516 481.4379272460938 C 78.81025695800781 481.4379272460938 79.2991943359375 481.4664916992188 79.75692749023438 481.5237426757812 L 80.014404296875 479.9476318359375 C 79.55667114257812 479.8618774414062 78.8388671875 479.8046264648438 78.43834686279297 479.8046264648438 C 76.43058013916016 479.8072509765625 75.71537780761719 480.8683471679688 75.74398040771484 482.1271362304688 L 75.74398040771484 482.1271362304688 Z M 112.5418319702148 486.8292236328125 L 110.8513641357422 486.8292236328125 L 110.9371871948242 486.1686401367188 C 110.4508361816406 486.6835327148438 109.9332962036133 486.9150390625 109.2753143310547 486.9150390625 C 107.9567413330078 486.9150390625 107.0984954833984 485.7967529296875 107.0984954833984 484.0776977539062 C 107.0984954833984 481.7838134765625 108.4456787109375 479.8358154296875 110.021728515625 479.8358154296875 C 110.7395324707031 479.8358154296875 111.2544860839844 480.1505126953125 111.7408065795898 480.782470703125 L 112.1413269042969 478.374267578125 L 113.9176254272461 478.374267578125 L 112.5418319702148 486.8292236328125 L 112.5418319702148 486.8292236328125 Z M 109.9046859741211 485.2245483398438 C 110.736930847168 485.2245483398438 111.3090896606445 484.2493286132812 111.3090896606445 482.9021606445312 C 111.3090896606445 482.0126953125 110.9943923950195 481.5549926757812 110.3624267578125 481.5549926757812 C 109.5587921142578 481.5549926757812 108.9580154418945 482.5016479492188 108.9580154418945 483.8488159179688 C 108.9606246948242 484.7642822265625 109.2753143310547 485.2245483398438 109.9046859741211 485.2245483398438 L 109.9046859741211 485.2245483398438 Z M 88.15211486816406 486.6836547851562 C 87.52013397216797 486.8838500976562 86.94797515869141 486.9697265625 86.28997802734375 486.9697265625 C 84.28482055664062 486.9697265625 83.2523193359375 485.9085693359375 83.2523193359375 483.8748168945312 C 83.2523193359375 481.5237426757812 84.57089996337891 479.7760620117188 86.37580108642578 479.7760620117188 C 87.86602783203125 479.7760620117188 88.81269836425781 480.7513427734375 88.81269836425781 482.2701416015625 C 88.81269836425781 482.7850952148438 88.75547790527344 483.2740478515625 88.58383178710938 483.9892578125 L 85.02861785888672 483.9892578125 C 85.00001525878906 484.0750122070312 85.00001525878906 484.13232421875 85.00001525878906 484.1895141601562 C 85.00001525878906 484.9931030273438 85.54356384277344 485.3936767578125 86.57605743408203 485.3936767578125 C 87.23404693603516 485.3936767578125 87.80881500244141 485.2791748046875 88.43819427490234 484.9644775390625 L 88.15211486816406 486.6836547851562 L 88.15211486816406 486.6836547851562 Z M 87.15081787109375 482.5874633789062 L 87.15081787109375 482.244140625 C 87.15081787109375 481.6719360351562 86.83614349365234 481.3546752929688 86.28997802734375 481.3546752929688 C 85.71781921386719 481.3546752929688 85.31471252441406 481.7838134765625 85.14305877685547 482.5874633789062 L 87.15081787109375 482.5874633789062 L 87.15081787109375 482.5874633789062 Z M 68.89363098144531 486.8292236328125 L 67.11733245849609 486.8292236328125 L 68.14982604980469 480.3222045898438 L 65.82736968994141 486.8292236328125 L 64.59461975097656 486.8292236328125 L 64.45158386230469 480.37939453125 L 63.36186599731445 486.8292236328125 L 61.70000076293945 486.8292236328125 L 63.10439682006836 478.374267578125 L 65.684326171875 478.374267578125 L 65.77014923095703 483.6199340820312 L 67.48924255371094 478.374267578125 L 70.29804229736328 478.374267578125 L 68.89363098144531 486.8292236328125 L 68.89363098144531 486.8292236328125 Z M 73.33570098876953 483.7630004882812 C 73.16405487060547 483.7630004882812 73.07823181152344 483.734375 72.93518829345703 483.734375 C 71.93129730224609 483.734375 71.41635131835938 484.1062622070312 71.41635131835938 484.7954711914062 C 71.41635131835938 485.2245483398438 71.64522552490234 485.4820556640625 72.04573059082031 485.4820556640625 C 72.79214477539062 485.4820556640625 73.30709075927734 484.7929077148438 73.33570098876953 483.7630004882812 L 73.33570098876953 483.7630004882812 Z M 74.65427398681641 486.8292236328125 L 73.16405487060547 486.8292236328125 L 73.19265747070312 486.1114501953125 C 72.73493194580078 486.6836547851562 72.13156127929688 486.9437255859375 71.30192565917969 486.9437255859375 C 70.32664489746094 486.9437255859375 69.66865539550781 486.197265625 69.66865539550781 485.08154296875 C 69.66865539550781 483.39111328125 70.81558227539062 482.415771484375 72.82075500488281 482.415771484375 C 73.02101135253906 482.415771484375 73.27848052978516 482.4443969726562 73.56716156005859 482.4730224609375 C 73.6243896484375 482.244140625 73.6243896484375 482.1583251953125 73.6243896484375 482.0438842773438 C 73.6243896484375 481.5861206054688 73.30970001220703 481.41455078125 72.47746276855469 481.41455078125 C 71.96251678466797 481.41455078125 71.38774871826172 481.4717407226562 70.98722839355469 481.5861206054688 L 70.72975921630859 481.6719360351562 L 70.55811309814453 481.7005615234375 L 70.81558227539062 480.1531372070312 C 71.70503234863281 479.8956909179688 72.30581665039062 479.809814453125 72.96640014648438 479.809814453125 C 74.51383972167969 479.809814453125 75.34607696533203 480.4964599609375 75.34607696533203 481.8150634765625 C 75.34607696533203 482.1583251953125 75.31746673583984 482.4183959960938 75.20303344726562 483.1907958984375 L 74.80252838134766 485.6277465820312 L 74.74530792236328 486.0568237304688 L 74.71669769287109 486.400146484375 L 74.68808746337891 486.6575927734375 L 74.65427398681641 486.8292236328125 L 74.65427398681641 486.8292236328125 Z M 101.7097625732422 483.7630004882812 C 101.5095062255859 483.7630004882812 101.4236755371094 483.734375 101.3092422485352 483.734375 C 100.2767562866211 483.734375 99.76181030273438 484.1062622070312 99.76181030273438 484.7954711914062 C 99.76181030273438 485.2245483398438 100.0192794799805 485.4820556640625 100.4223937988281 485.4820556640625 C 101.1375961303711 485.4820556640625 101.68115234375 484.7929077148438 101.7097625732422 483.7630004882812 L 101.7097625732422 483.7630004882812 Z M 103.0283355712891 486.8292236328125 L 101.5381164550781 486.8292236328125 L 101.5667190551758 486.1114501953125 C 101.1089935302734 486.6836547851562 100.505615234375 486.9437255859375 99.67598724365234 486.9437255859375 C 98.70070648193359 486.9437255859375 98.04271697998047 486.197265625 98.04271697998047 485.08154296875 C 98.04271697998047 483.39111328125 99.18964385986328 482.415771484375 101.1948165893555 482.415771484375 C 101.3950653076172 482.415771484375 101.6551513671875 482.4443969726562 101.9126205444336 482.4730224609375 C 101.9698333740234 482.244140625 101.9984436035156 482.1583251953125 101.9984436035156 482.0438842773438 C 101.9984436035156 481.5861206054688 101.6837615966797 481.41455078125 100.8515167236328 481.41455078125 C 100.3339691162109 481.41455078125 99.73320007324219 481.4717407226562 99.33268737792969 481.5861206054688 L 99.10382080078125 481.6719360351562 L 98.93217468261719 481.7005615234375 L 99.18964385986328 480.1531372070312 C 100.0790939331055 479.8956909179688 100.6798629760742 479.809814453125 101.3404541015625 479.809814453125 C 102.8878936767578 479.809814453125 103.691520690918 480.4964599609375 103.691520690918 481.8150634765625 C 103.691520690918 482.1583251953125 103.691520690918 482.4183959960938 103.5484848022461 483.1907958984375 L 103.1765823364258 485.6277465820312 L 103.1193618774414 486.0568237304688 L 103.062141418457 486.400146484375 L 103.0335388183594 486.6575927734375 L 103.0283355712891 486.8292236328125 L 103.0283355712891 486.8292236328125 L 103.0283355712891 486.8292236328125 Z M 107.8423080444336 479.8931274414062 L 107.670654296875 479.8931274414062 C 107.0698852539062 479.8931274414062 106.7239837646484 480.1791381835938 106.1804275512695 481.0114135742188 L 106.3520812988281 479.9503173828125 L 104.7188186645508 479.9503173828125 L 103.6291046142578 486.8292236328125 L 105.4054107666016 486.8292236328125 C 106.0660018920898 482.6160278320312 106.2376556396484 481.9008178710938 107.0959014892578 481.9008178710938 L 107.2103271484375 481.9008178710938 C 107.3819732666016 481.068603515625 107.6108474731445 480.4678955078125 107.8969192504883 479.92431640625 L 107.8423080444336 479.8931274414062 L 107.8423080444336 479.8931274414062 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_atkter =
    '<svg viewBox="6555.0 1835.1 217.9 188.9" ><defs><linearGradient id="gradient" x1="1.103719" y1="0.974894" x2="0.165567" y2="-0.06619"><stop offset="0.0" stop-color="#ffe45ae5"  /><stop offset="0.377233" stop-color="#fff7a482"  /><stop offset="0.740897" stop-color="#ffa234fb"  /><stop offset="1.0" stop-color="#ff4994f9"  /></linearGradient></defs><path transform="translate(6554.94, 1835.0)" d="M 20.05830001831055 189 C 9.012599945068359 189 0.05850000306963921 180.0458984375 0.05850000306963921 169.0001983642578 L 0.05850000306963921 19.99979972839355 C 0.05850000306963921 11.36967277526855 5.525270938873291 4.016078948974609 13.18421459197998 1.212635278701782 C 57.83877944946289 -1.728087902069092 198.8025360107422 -4.878925800323486 165.3632965087891 76.1885986328125 C 125.7660064697266 172.1844024658203 217.9485015869141 189 217.9485015869141 189 L 20.05830001831055 189 Z" fill="url(#gradient)" fill-opacity="0.5" stroke="none" stroke-width="1" stroke-opacity="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_m88ne =
    '<svg viewBox="6489.0 1835.1 217.9 188.9" ><defs><linearGradient id="gradient" x1="1.0" y1="1.192057" x2="0.113893" y2="0.0"><stop offset="0.0" stop-color="#ffe45ae5"  /><stop offset="0.377233" stop-color="#fff7a482"  /><stop offset="0.740897" stop-color="#ffa234fb"  /><stop offset="1.0" stop-color="#ff4994f9"  /></linearGradient></defs><path transform="translate(6488.94, 1835.0)" d="M 20.05830001831055 189 C 9.012599945068359 189 0.05850000306963921 180.0458984375 0.05850000306963921 169.0001983642578 L 0.05850000306963921 19.99979972839355 C 0.05850000306963921 11.36967277526855 5.525270938873291 4.016078948974609 13.18421459197998 1.212635278701782 C 57.83877944946289 -1.728087902069092 198.8025360107422 -4.878925800323486 165.3632965087891 76.1885986328125 C 125.7660064697266 172.1844024658203 217.9485015869141 189 217.9485015869141 189 L 20.05830001831055 189 Z" fill="url(#gradient)" fill-opacity="0.66" stroke="none" stroke-width="1" stroke-opacity="0.66" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gmmrz =
    '<svg viewBox="6489.0 1835.5 165.9 188.5" ><defs><linearGradient id="gradient" x1="1.0" y1="1.192057" x2="0.113893" y2="0.0"><stop offset="0.0" stop-color="#ffe45ae5"  /><stop offset="0.377233" stop-color="#fff7a482"  /><stop offset="0.740897" stop-color="#ffa234fb"  /><stop offset="1.0" stop-color="#ff4994f9"  /></linearGradient></defs><path transform="translate(6436.94, 1835.0)" d="M 72.05850219726562 189 C 61.01280212402344 189 52.05780029296875 180.0458984375 52.05780029296875 169.0001983642578 L 52.05780029296875 19.99979972839355 C 52.05780029296875 10.55931377410889 58.59989929199219 2.646549701690674 67.39713287353516 0.5461227893829346 C 123.1039123535156 3.107523202896118 189.4421539306641 17.81365394592285 165.3632965087891 76.1885986328125 C 125.7660064697266 172.1844024658203 217.9485015869141 189 217.9485015869141 189 L 72.05850219726562 189 Z" fill="url(#gradient)" fill-opacity="0.44" stroke="none" stroke-width="1" stroke-opacity="0.44" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_izk15e =
    '<svg viewBox="475.0 874.0 375.0 84.0" ><path transform="translate(475.0, 918.0)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 40.00000381469727 L 0 40.00000381469727 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
