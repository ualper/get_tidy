import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';

class XDComponent401 extends StatelessWidget {
  XDComponent401({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Pinned.fromPins(
          Pin(start: 0.0, end: 0.0),
          Pin(start: 0.0, end: 0.0),
          child: Text.rich(
            TextSpan(
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 27,
                color: const Color(0xffffffff),
                height: 1.3333333333333333,
              ),
              children: [
                TextSpan(
                  text: 'Hi ! Choose your\n ',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                TextSpan(
                  text: 'Service Type',
                  style: TextStyle(
                    color: const Color(0xff022c43),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            textHeightBehavior:
                TextHeightBehavior(applyHeightToFirstAscent: false),
            textAlign: TextAlign.left,
          ),
        ),
      ],
    );
  }
}
