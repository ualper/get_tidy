import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component71.dart';
import 'xd_checkout_order_summary2.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDCheckoutPaymentsCashOnDelivery2 extends StatelessWidget {
  XDCheckoutPaymentsCashOnDelivery2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff2f4f3),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 91.0, middle: 0.2108),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28.0),
                      color: const Color(0xffffffff),
                      border: Border.all(width: 0.6, color: const Color(0xffe2e2e2)),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x0a000000),
                          offset: Offset(0, 3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 23.0, end: 22.0),
                  Pin(size: 44.0, middle: 0.5106),
                  child:
                      // Adobe XD layer: 'Standard' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 24.0, end: 0.0),
                        Pin(size: 24.0, middle: 0.5),
                        child:
                            // Adobe XD layer: 'Radio Button' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Dot 2' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                  color: const Color(0x0f000000),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 5.0, end: 5.0),
                              Pin(start: 5.0, end: 5.0),
                              child:
                                  // Adobe XD layer: 'Dot 2' (shape)
                                  SvgPicture.string(
                                _svg_pbspbi,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 60.0),
                        Pin(start: 0.0, end: 0.0),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 14.0, end: 0.0),
                              child: Text(
                                'Pay once you got order at your home',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 14,
                                  color: const Color(0xa8000000),
                                  height: 1.6428571428571428,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 128.0, start: 0.0),
                              Pin(size: 16.0, start: 0.0),
                              child: Text(
                                'Cash on delivery',
                                style: TextStyle(
                                  fontFamily: 'SF Pro Display',
                                  fontSize: 16,
                                  color: const Color(0xff383838),
                                  fontWeight: FontWeight.w700,
                                  height: 1.625,
                                ),
                                textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: XDComponent71(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 84.0, end: 0.0),
            child:
                // Adobe XD layer: 'Bottom' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDCheckoutOrderSummary2(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'BG' (shape)
                        SvgPicture.string(
                      _svg_izk15e,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 146.0, end: 30.0),
                    Pin(size: 50.0, middle: 0.5),
                    child:
                        // Adobe XD layer: 'Primary Button - Sm…' (group)
                        Stack(
                      children: <Widget>[
                        Pinned.fromPins(
                          Pin(start: 0.0, end: 0.0),
                          Pin(start: 0.0, end: 0.0),
                          child:
                              // Adobe XD layer: 'Button' (shape)
                              Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25.0),
                              color: const Color(0xffff7f00),
                            ),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 38.0, middle: 0.5),
                          Pin(size: 14.0, middle: 0.5278),
                          child: Text(
                            'NEXT',
                            style: TextStyle(
                              fontFamily: 'SF Pro Text',
                              fontSize: 14,
                              color: const Color(0xffffffff),
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 16.0, end: 16.0),
            Pin(size: 60.0, end: 104.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 105.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Saved Card' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'BG' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30.0),
                            color: const Color(0xffff7f00),
                            border: Border.all(width: 0.5, color: const Color(0xffebebeb)),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(43.0, 22.0),
                        child: SizedBox(
                          width: 18.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'Icon_Saved Cards' (group)
                              Stack(
                            children: <Widget>[
                              SizedBox(
                                width: 17.0,
                                height: 17.0,
                                child: SvgPicture.string(
                                  _svg_vektqv,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                              Transform.translate(
                                offset: Offset(10.0, 7.8),
                                child: SizedBox(
                                  width: 9.0,
                                  height: 6.0,
                                  child: Stack(
                                    children: <Widget>[
                                      SizedBox(
                                        width: 9.0,
                                        height: 6.0,
                                        child: SvgPicture.string(
                                          _svg_w527k,
                                          allowDrawingOutsideViewBox: true,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 105.0, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Credit Card' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'BG' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(43.0, 21.0),
                        child: SizedBox(
                          width: 19.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'Icon_Credit Card' (group)
                              Stack(
                            children: <Widget>[
                              SizedBox(
                                width: 19.0,
                                height: 17.0,
                                child: Stack(
                                  children: <Widget>[
                                    SizedBox(
                                      width: 19.0,
                                      height: 17.0,
                                      child: SvgPicture.string(
                                        _svg_x3qbpf,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 105.0, middle: 0.5042),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'PayPal' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'BG' (shape)
                            SvgPicture.string(
                          _svg_puxcq,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(43.5, 22.0),
                        child: SizedBox(
                          width: 17.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'icons8_PayPal_1' (group)
                              Stack(
                            children: <Widget>[
                              SizedBox(
                                width: 17.0,
                                height: 17.0,
                                child: SvgPicture.string(
                                  _svg_so1gr,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_pbspbi =
    '<svg viewBox="5.2 5.0 14.0 14.0" ><path transform="translate(5.19, 5.0)" d="M 7 0 C 10.86599254608154 0 14 3.134007215499878 14 7 C 14 10.86599254608154 10.86599254608154 14 7 14 C 3.134007215499878 14 0 10.86599254608154 0 7 C 0 3.134007215499878 3.134007215499878 0 7 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_izk15e =
    '<svg viewBox="475.0 874.0 375.0 84.0" ><path transform="translate(475.0, 918.0)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 40.00000381469727 L 0 40.00000381469727 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w527k =
    '<svg viewBox="0.0 0.0 8.5 5.5" ><path transform="translate(-27.0, -21.0)" d="M 33.65217590332031 22.84782600402832 L 33.65217590332031 24.69565200805664 L 28.84782791137695 24.69565200805664 L 28.84782791137695 22.84782600402832 L 33.65217590332031 22.84782600402832 M 33.91087341308594 21 L 28.58913040161133 21 C 27.70217514038086 21 27 21.70217323303223 27 22.58913040161133 L 27 24.954345703125 C 27 25.84130477905273 27.70217514038086 26.54347801208496 28.58913040161133 26.54347801208496 L 33.91086959838867 26.54347801208496 C 34.79782867431641 26.54347801208496 35.5 25.84130477905273 35.5 24.95434761047363 L 35.5 22.58913040161133 C 35.5 21.70217323303223 34.79782867431641 21 33.91087341308594 21 L 33.91087341308594 21 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_vektqv =
    '<svg viewBox="0.0 0.0 17.4 17.0" ><path  d="M 17.36956596374512 8.869565010070801 L 17.36956596374512 7.02173900604248 C 17.36956596374512 5.395652294158936 16.03913116455078 4.0652174949646 14.41304397583008 4.0652174949646 L 2.95652174949646 4.0652174949646 C 2.328260898590088 4.0652174949646 1.84782612323761 3.547826290130615 1.84782612323761 2.919565200805664 C 1.884782552719116 2.291304349899292 2.40217399597168 1.84782612323761 2.993478298187256 1.84782612323761 L 14.41304397583008 1.84782612323761 C 14.81956481933594 1.84782612323761 15.18912982940674 2.069565296173096 15.3739128112793 2.439130306243896 C 15.55869483947754 2.77173924446106 15.85434818267822 2.95652174949646 16.22391319274902 2.95652174949646 C 16.92608833312988 2.95652174949646 17.36956596374512 2.2173912525177 17.03695678710938 1.589130520820618 C 16.55652236938477 0.6282609105110168 15.55869483947754 0 14.41304397583008 0 L 2.95652174949646 0 C 1.330434799194336 0 0 1.330434799194336 0 2.95652174949646 L 0 2.95652174949646 L 0 2.95652174949646 L 0 14.04347801208496 C 0 15.66956615447998 1.330434799194336 17 2.95652174949646 17 L 14.41304397583008 17 C 16.03913116455078 17 17.36956596374512 15.66956615447998 17.36956596374512 14.04347801208496 L 17.36956596374512 12.19565200805664 L 15.52173900604248 12.19565200805664 L 15.52173900604248 14.04347801208496 C 15.52173900604248 14.63478183746338 15.04130458831787 15.15217399597168 14.41304397583008 15.15217399597168 L 2.95652174949646 15.15217399597168 C 2.365217447280884 15.15217399597168 1.84782612323761 14.67173957824707 1.84782612323761 14.04347801208496 L 1.84782612323761 5.691304206848145 C 2.180434942245483 5.839130401611328 2.549999952316284 5.91304349899292 2.95652174949646 5.91304349899292 L 14.41304397583008 5.91304349899292 C 15.00434684753418 5.91304349899292 15.52173900604248 6.393477916717529 15.52173900604248 7.02173900604248 L 15.52173900604248 8.869565010070801 L 17.36956596374512 8.869565010070801 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_x3qbpf =
    '<svg viewBox="0.0 0.0 18.9 17.0" ><path transform="translate(0.0, 0.0)" d="M 16.50889015197754 3.815556287765503 L 15.3000020980835 1.548888921737671 C 14.73333358764648 0.5666666626930237 13.71333122253418 -2.073205074282214e-08 12.61777973175049 -2.073205074282214e-08 C 12.12666797637939 -2.073205074282214e-08 11.63555717468262 0.1133333221077919 11.18222427368164 0.3777778148651123 L 4.911111354827881 3.777777433395386 L 3.022222518920898 3.777777433395386 C 1.359999895095825 3.777777433395386 0 5.137777805328369 0 6.799998760223389 L 0 13.97777938842773 C 0 15.64000129699707 1.359999895095825 17 3.022222518920898 17 L 15.86666584014893 17 C 17.52889060974121 17 18.88888931274414 15.64000129699707 18.88888931274414 13.97777938842773 L 18.88888931274414 6.799998760223389 C 18.88888931274414 5.326666831970215 17.86888694763184 4.117776870727539 16.50889015197754 3.815556287765503 Z M 12.08889007568359 2.039999961853027 C 12.27777671813965 1.926666617393494 12.42888832092285 1.888888716697693 12.61777973175049 1.888888716697693 C 13.03333473205566 1.888888716697693 13.41111183166504 2.115555286407471 13.59999752044678 2.493333101272583 L 14.27999973297119 3.777777433395386 L 8.877777099609375 3.777777433395386 L 12.08889007568359 2.039999961853027 Z M 17 13.97777938842773 C 17 14.58222007751465 16.50889015197754 15.11110973358154 15.86666584014893 15.11110973358154 L 3.022222518920898 15.11110973358154 C 2.41777777671814 15.11110973358154 1.888888716697693 14.61999607086182 1.888888716697693 13.97777938842773 L 1.888888716697693 6.799998760223389 C 1.888888716697693 6.195554256439209 2.379999876022339 5.666666507720947 3.022222518920898 5.666666507720947 L 15.86666584014893 5.666666507720947 C 16.47110748291016 5.666666507720947 17 6.157776832580566 17 6.799998760223389 L 17 13.97777938842773 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-6.22, -12.44)" d="M 20.38888740539551 21.88888740539551 L 10.94444370269775 21.88888740539551 C 10.41555500030518 21.88888740539551 9.999999046325684 21.47333335876465 9.999999046325684 20.9444408416748 L 9.999999046325684 20.9444408416748 C 9.999999046325684 20.41555404663086 10.41555500030518 19.99999809265137 10.94444370269775 19.99999809265137 L 20.38888740539551 19.99999809265137 C 20.91777610778809 19.99999809265137 21.33333206176758 20.41555404663086 21.33333206176758 20.9444408416748 L 21.33333206176758 20.9444408416748 C 21.33333206176758 21.4355525970459 20.91777610778809 21.88888740539551 20.38888740539551 21.88888740539551 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_so1gr =
    '<svg viewBox="0.0 0.0 16.9 17.0" ><path transform="translate(-0.37, -0.12)" d="M 3.366504669189453 0.125 L 0.375 13.82402896881104 L 4.336164951324463 13.82402896881104 L 5.305825233459473 9.285194396972656 L 8.132281303405762 9.285194396972656 C 10.83495140075684 9.285194396972656 13.07858943939209 7.619226932525635 13.68203926086426 4.787621021270752 C 14.36801338195801 1.58206832408905 12.06766700744629 0.125 10.09223365783691 0.125 L 3.366504669189453 0.125 Z M 6.708737850189209 2.910194158554077 L 8.648058891296387 2.910194158554077 C 9.615143775939941 2.910194158554077 10.2727632522583 3.748343467712402 9.989077568054199 4.787621021270752 C 9.746654510498047 5.829506397247314 8.728008270263672 6.665048599243164 7.719659805297852 6.665048599243164 L 5.862864017486572 6.665048599243164 L 6.708737850189209 2.910194158554077 Z M 15.12621402740479 3.714805603027344 C 15.12363815307617 4.127427101135254 15.08495140075684 4.571011543273926 14.98179626464844 5.055825233459473 C 14.71359252929688 6.31689453125 14.17203521728516 7.420673847198486 13.4138355255127 8.294902801513672 C 13.094069480896 9.236207962036133 12.14504051208496 9.966019630432129 11.20631122589111 9.966019630432129 L 11.16504859924316 9.966019630432129 C 10.25470733642578 10.38121509552002 9.238635063171387 10.60558319091797 8.132281303405762 10.60558319091797 L 6.378640651702881 10.60558319091797 L 5.635921955108643 14.0922327041626 L 5.408980369567871 15.14441776275635 L 4.315533638000488 15.14441776275635 L 3.882281303405762 17.125 L 7.822815418243408 17.125 L 8.792475700378418 12.58616542816162 L 11.61893177032471 12.58616542816162 C 14.32160186767578 12.58616542816162 16.58329391479492 10.92019748687744 17.1893196105957 8.088592529296875 C 17.69737243652344 5.708295345306396 16.55233192443848 4.287325859069824 15.12621402740479 3.714805603027344 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_puxcq =
    '<svg viewBox="0.5 0.0 105.0 60.0" ><path transform="translate(0.46, 0.0)" d="M 30 0 L 75 0 C 91.56854248046875 0 105 13.43145751953125 105 30 C 105 46.56854248046875 91.56854248046875 60 75 60 L 30 60 C 13.43145751953125 60 0 46.56854248046875 0 30 C 0 13.43145751953125 13.43145751953125 0 30 0 Z" fill="#ffffff" stroke="#ebebeb" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
