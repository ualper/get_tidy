import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_vetx_verify_success1.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_component21.dart';
import 'xd_login_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDSIGNUP extends StatelessWidget {
  XDSIGNUP({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -6.0, end: -5.0),
            Pin(size: 326.0, middle: 0.4547),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 320.7, start: 0.0),
                  Pin(size: 232.7, end: 0.0),
                  child: SvgPicture.string(
                    _svg_kv0vu,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 298.7, end: 0.0),
                  Pin(size: 254.7, start: 0.0),
                  child: SvgPicture.string(
                    _svg_ncyk2w,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 18.0, end: 17.0),
            Pin(start: 51.0, end: 82.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 150.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 59.0, end: 70.0),
                        child: SvgPicture.string(
                          _svg_lmdotw,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 180.0, middle: 0.5156),
                        Pin(size: 18.0, end: 0.0),
                        child: Text(
                          'Don\'t have an account?',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 14,
                            color: const Color(0xffffffff),
                            letterSpacing: 0.7000000000000001,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 46.0, end: 47.0),
                        Pin(size: 56.0, middle: 0.7927),
                        child: PageLink(
                          links: [
                            PageLinkInfo(
                              transition: LinkTransition.Fade,
                              ease: Curves.easeOut,
                              duration: 0.3,
                              pageBuilder: () => XDVetxVerifySuccess1(),
                            ),
                          ],
                          child: Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(start: 0.0, end: 0.0),
                                Pin(start: 0.0, end: 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(28.0),
                                    color: const Color(0xffff7f00),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0x29000000),
                                        offset: Offset(0, 3),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 74.0, middle: 0.5),
                                Pin(size: 20.0, middle: 0.4706),
                                child: Text(
                                  'SIGNUP',
                                  style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    fontSize: 17,
                                    color: const Color(0xffffffff),
                                    letterSpacing: 0.8500000000000001,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 108.0, middle: 0.4978),
                        Pin(size: 46.0, start: 0.0),
                        child: Text(
                          'Sign Up',
                          style: TextStyle(
                            fontFamily: 'Source Sans Pro',
                            fontSize: 32,
                            color: const Color(0xff312c66),
                            fontWeight: FontWeight.w700,
                            height: 1.40625,
                          ),
                          textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 16.0, start: 0.0),
                  Pin(size: 16.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'ic_arrow_forward_24…' (shape)
                      SvgPicture.string(
                    _svg_xweay0,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 39.0, end: 39.0),
            Pin(size: 99.0, start: 32.0),
            child: XDComponent21(),
          ),
          Pinned.fromPins(
            Pin(size: 247.0, middle: 0.5156),
            Pin(size: 56.0, end: 24.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28.0),
                border: Border.all(width: 2.0, color: const Color(0xff022c43)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 72.0, middle: 0.505),
            Pin(size: 20.0, end: 43.1),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDLoginUI(),
                ),
              ],
              child: Text(
                'SIGN IN',
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 17,
                  color: const Color(0xff022c43),
                  letterSpacing: 0.8500000000000001,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 31.0, end: 30.0),
            Pin(size: 249.0, middle: 0.5293),
            child: Scrollbar(
              child: SingleChildScrollView(
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 20,
                  runSpacing: 15,
                  children: [
                    {
                      'text': 'First Name',
                    },
                    {
                      'text': 'Last Name',
                    },
                    {
                      'text': 'Email',
                    },
                    {
                      'text': 'Password',
                    },
                    {
                      'text': 'Phone Number',
                    },
                    {
                      'text': 'Zip Code',
                    }
                  ].map((itemData) {
                    final text = itemData['text']!;
                    return SizedBox(
                      width: 314.0,
                      height: 27.0,
                      child: Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(size: 71.0, start: 3.0),
                            Pin(size: 16.0, start: 0.0),
                            child:
                                // Adobe XD layer: 'SIGN UP' (group)
                                Stack(
                              children: <Widget>[
                                Pinned.fromPins(
                                  Pin(start: 0.0, end: 0.0),
                                  Pin(start: 0.0, end: 0.0),
                                  child: Text(
                                    text,
                                    style: TextStyle(
                                      fontFamily: 'Arial',
                                      fontSize: 14,
                                      color: const Color(0xff5d5e60),
                                      letterSpacing: -0.19999999809265134,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 1.0, end: -1.0),
                            child: SvgPicture.string(
                              _svg_cknz7y,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 204.0, middle: 0.5088),
            Pin(size: 18.0, end: 104.0),
            child: Text(
              'Already have an account?',
              style: TextStyle(
                fontFamily: 'HelveticaNeue',
                fontSize: 16,
                color: const Color(0xff022c43),
                letterSpacing: 0.8,
                height: 1.375,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 21.1, middle: 0.6531),
            Pin(size: 19.2, start: 41.4),
            child:
                // Adobe XD layer: 'blob (1)' (shape)
                SvgPicture.string(
              _svg_czymg0,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_cknz7y =
    '<svg viewBox="30.0 275.5 314.0 1.0" ><path transform="translate(30.0, 275.5)" d="M 0 0 L 314 0" fill="none" stroke="#b1b3b7" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_kv0vu =
    '<svg viewBox="-6.0 314.3 320.7 232.7" ><path transform="translate(-12.0, 973.0)" d="M 6 -616 L 12 -426 L 278.6666870117188 -658.6666870117188 L 326.6666870117188 -609.3333129882812 L 6 -616 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ncyk2w =
    '<svg viewBox="81.3 221.0 298.7 254.7" ><path transform="translate(-12.0, 973.0)" d="M 93.33334350585938 -610.6666870117188 L 129.3333435058594 -497.3333435058594 L 388 -752 L 392 -604 L 93.33334350585938 -610.6666870117188 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lmdotw =
    '<svg viewBox="-2.0 164.0 340.0 400.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(-2.0, 164.0)" d="M 23.92961883544922 0 L 316.0703735351562 0 C 329.2863464355469 0 340 8.06391429901123 340 18.01125717163086 L 340 381.9888000488281 C 340 391.9360961914062 329.2863464355469 400.0000305175781 316.0703735351562 400.0000305175781 L 23.92961883544922 400.0000305175781 C 10.71365451812744 400.0000305175781 0 391.9360961914062 0 381.9888000488281 L 0 18.01125717163086 C 0 8.06391429901123 10.71365451812744 0 23.92961883544922 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_xweay0 =
    '<svg viewBox="17.0 51.0 16.0 16.0" ><path transform="translate(13.0, 47.0)" d="M 12 20 L 13.40999984741211 18.59000015258789 L 7.829999923706055 13 L 20 13 L 20 11 L 7.829999923706055 11 L 13.40999984741211 5.409999847412109 L 12 4 L 4 12 L 12 20 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_czymg0 =
    '<svg viewBox="231.1 41.4 21.1 19.2" ><path transform="translate(300.42, 98.13)" d="M -48.40910339355469 -50.80363845825195 C -47.41164398193359 -47.46786117553711 -49.70090484619141 -43.33084106445312 -53.33101654052734 -40.5837287902832 C -56.97747802734375 -37.83661651611328 -61.94844436645508 -36.46305847167969 -65.26786804199219 -38.58880233764648 C -68.58729553222656 -40.71454620361328 -70.25518798828125 -46.33958435058594 -68.75082397460938 -50.36213684082031 C -67.26280212402344 -54.36834335327148 -62.61886978149414 -56.77206802368164 -58.15481567382812 -56.70666122436523 C -53.69075775146484 -56.6576042175293 -49.40657043457031 -54.13941955566406 -48.40910339355469 -50.80363845825195 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
