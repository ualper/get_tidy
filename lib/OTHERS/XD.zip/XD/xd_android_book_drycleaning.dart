import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component371.dart';
import 'xd_component41.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDAndroidBookDrycleaning extends StatelessWidget {
  XDAndroidBookDrycleaning({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -29.0, end: -521.0),
            Pin(size: 420.0, start: 95.0),
            child: XDComponent371(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_r03onj,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.0, end: 23.0),
            Pin(size: 69.2, middle: 0.1939),
            child: SvgPicture.string(
              _svg_f8740g,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 205.0, start: 33.0),
            Pin(size: 45.0, middle: 0.2218),
            child: Text(
              'Salacak, 34674 Üsküdar/İstanbul\n',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xff383838),
                height: 1.8571428571428572,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 33.0),
            Pin(size: 12.0, middle: 0.1923),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 3,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 52.0, start: 51.0),
            Pin(size: 16.0, middle: 0.1909),
            child: Text(
              'Service at',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                color: const Color(0x99383838),
                height: 2.1666666666666665,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 1.0, middle: 0.5036),
            Pin(size: 116.0, middle: 0.3143),
            child: SvgPicture.string(
              _svg_c7wum9,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 44.0, start: 44.0),
            child: XDComponent41(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 197.0, middle: 0.7659),
            child: SvgPicture.string(
              _svg_qd5xuc,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 230.0, end: 0.0),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_fcjf9m,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, end: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Button' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25.0),
                      color: const Color(0xffff7f00),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 64.0, middle: 0.5),
                  Pin(size: 14.0, middle: 0.5278),
                  child: Text(
                    'Book Now',
                    style: TextStyle(
                      fontFamily: 'SF Pro Text',
                      fontSize: 14,
                      color: const Color(0xffffffff),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, start: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Button' (shape)
                Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25.0),
                border: Border.all(width: 2.0, color: const Color(0xffffffff)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 82.0, middle: 0.2121),
            Pin(size: 14.0, end: 34.0),
            child: Text(
              'Service Later',
              style: TextStyle(
                fontFamily: 'SF Pro Text',
                fontSize: 14,
                color: const Color(0xffffffff),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 160.0, middle: 0.3016),
            Pin(size: 32.0, middle: 0.7554),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 24,
                  color: const Color(0xffffffff),
                  height: 1.5,
                ),
                children: [
                  TextSpan(
                    text: 'Per Outfit : £',
                  ),
                  TextSpan(
                    text: '10',
                    style: TextStyle(
                      color: const Color(0xffff7f00),
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 173.0, start: 27.0),
            Pin(size: 18.0, middle: 0.7829),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 13,
                  color: const Color(0xffff7f00),
                ),
                children: [
                  TextSpan(
                    text: 'Note: ',
                  ),
                  TextSpan(
                    text: 'Parts price is additional ',
                    style: TextStyle(
                      color: const Color(0xffffffff),
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 76.0, end: 87.0),
            child: SvgPicture.string(
              _svg_gbyb,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.0, start: 47.0),
            Pin(size: 17.0, end: 131.0),
            child: Text(
              'Enter job description for service..',
              style: TextStyle(
                fontFamily: 'Lato',
                fontSize: 14,
                color: const Color(0xffb7bec6),
                height: 1.4285714285714286,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 52.0),
            Pin(size: 30.0, middle: 0.4512),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, start: 51.0),
            Pin(size: 30.0, middle: 0.381),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 22.0),
            Pin(size: 30.0, start: 114.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, end: 15.0),
            Pin(size: 30.0, middle: 0.3274),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.5027),
            Pin(size: 40.0, middle: 0.406),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, middle: 0.733),
            Pin(size: 30.0, middle: 0.2607),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, middle: 0.7225),
            Pin(size: 30.0, middle: 0.5643),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.0, start: 24.0),
            Pin(size: 30.0, middle: 0.5131),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 111.5, middle: 0.6717),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_g5t2ts,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 224.6, middle: 0.5831),
            Pin(size: 111.0, middle: 0.6719),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_r03onj =
    '<svg viewBox="0.0 0.0 412.0 44.0" ><path transform="translate(0.0, 44.0)" d="M 0 -44 L 412 -44 L 412 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_f8740g =
    '<svg viewBox="24.0 155.2 365.0 69.2" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(24.0, 155.24)" d="M 169.1460113525391 55.99980163574219 L 6.00029993057251 55.99980163574219 C 2.686500072479248 55.99980163574219 0 53.31330108642578 0 50.00040054321289 L 0 6.00029993057251 C 0 2.686500072479248 2.686500072479248 0 6.00029993057251 0 L 359.0001220703125 0 C 362.3139038085938 0 365.0003967285156 2.686500072479248 365.0003967285156 6.00029993057251 L 365.0003967285156 50.00040054321289 C 365.0003967285156 53.20977401733398 362.4791870117188 55.83127975463867 359.3088684082031 55.99198913574219 C 359.2066040039062 55.99717330932617 359.1036682128906 55.99980163574219 359.0001220703125 55.99980163574219 L 195.8535003662109 55.99980163574219 L 181.9440002441406 69.24960327148438 L 169.1460113525391 55.99980163574219 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_c7wum9 =
    '<svg viewBox="207.0 237.0 1.0 116.0" ><path transform="translate(207.0, 237.0)" d="M 0 0 L 0 116" fill="none" stroke="#022c43" stroke-width="2" stroke-dasharray="4 9" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_qd5xuc =
    '<svg viewBox="0.0 515.4 412.0 197.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="-1" stdDeviation="16"/></filter></defs><path transform="translate(0.0, 515.42)" d="M 0 0 L 412 0 L 412 197 L 0 197 L 0 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_fcjf9m =
    '<svg viewBox="0.0 640.0 412.0 230.0" ><path transform="translate(0.0, 684.04)" d="M 0 -43.99999618530273 L 412 -43.99999618530273 L 412 185.9560852050781 L 0 185.9560852050781 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gbyb =
    '<svg viewBox="17.0 707.0 380.0 76.0" ><path transform="translate(17.0, 707.0)" d="M 12.58278274536133 0 L 367.417236328125 0 C 374.3665466308594 0 380.0000305175781 5.148725032806396 380.0000305175781 11.5 L 380.0000305175781 64.5 C 380.0000305175781 70.85127258300781 374.3665466308594 76 367.417236328125 76 L 12.58278274536133 76 C 5.633502960205078 76 0 70.85127258300781 0 64.5 L 0 11.5 C 0 5.148725032806396 5.633502960205078 0 12.58278274536133 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_g5t2ts =
    '<svg viewBox="0.0 509.5 412.0 111.5" ><path transform="translate(0.0, 553.48)" d="M 0 -44 L 412 -44 L 412 67.52203369140625 L 0 67.52203369140625 L 0 -44 Z" fill="#ffa700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
