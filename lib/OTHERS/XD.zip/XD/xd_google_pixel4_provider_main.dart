import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import 'package:get_tidy/OTHERS/XD/xdiconbac_k.dart';
import 'xd_icon_back.dart';
import 'xd_home_chose_service_provider.dart';
import 'package:adobe_xd/page_link.dart';
import 'xd_component_avatar.dart';
import 'xd_component281.dart';
import 'xd_component291.dart';
import 'xd_component_mesage.dart';
import 'xd_component341.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDGooglePixel4ProviderMain extends StatelessWidget {
  XDGooglePixel4ProviderMain({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: SvgPicture.string(
              _svg_cwuek1,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 202.5, end: 48.0),
            Pin(size: 126.7, middle: 0.3327),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 122.0, start: 0.0),
                  Pin(start: 0.0, end: 4.7),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 122.0, end: 0.0),
                  Pin(start: 4.7, end: 0.0),
                  child:
                      // Adobe XD layer: 'Thumb' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Thumb' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Base' (shape)
                                  BlendMask(
                                blendMode: BlendMode.lighten,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                                    color: const Color(0xfff4f5f7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(end: 27.0, startFraction: 0.835),
            Pin(start: 74.0, endFraction: 0.8678),
            child:
                // Adobe XD layer: 'icon-arrow-left' (component)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDHomeChoseServiceProvider(),
                ),
              ],
              child: XDiconBack(),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 18.0, end: 18.0),
            Pin(size: 666.0, end: 44.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 426.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(36.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 1),
                          blurRadius: 7,
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 104.0, middle: 0.5),
                  Pin(size: 90.0, start: 0.0),
                  child: XDcomponent_avatar(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 56.0, middle: 0.4475),
                  child: XDComponent281(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 55.0, middle: 0.5777),
                  child: XDComponent291(),
                ),
                Pinned.fromPins(
                  Pin(size: 86.0, middle: 0.5),
                  Pin(size: 77.0, middle: 0.1935),
                  child: XDcomponent_mesage(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 56.0, middle: 0.7082),
                  child: XDComponent281(),
                ),
                Pinned.fromPins(
                  Pin(start: 10.0, end: 9.0),
                  Pin(size: 55.0, end: 90.0),
                  child: XDComponent291(),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.5, end: 21.5),
            Pin(size: 81.7, start: 54.2),
            child: XDComponent341(),
          ),
        ],
      ),
    );
  }
}

const String _svg_cwuek1 =
    '<svg viewBox="0.0 0.0 412.0 870.0" ><path  d="M 0 0 L 412 0 L 412 870 L 0 870 L 0 0 Z" fill="#ff7f00" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
