import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component21.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDgetTidyLabel extends StatelessWidget {
  XDgetTidyLabel({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Pinned.fromPins(
          Pin(start: 0.0, end: 0.0),
          Pin(start: 0.0, end: 0.0),
          child: Stack(
            children: <Widget>[
              Pinned.fromPins(
                Pin(start: 0.0, end: 0.0),
                Pin(size: 1.0, end: -1.0),
                child: SvgPicture.string(
                  _svg_ij8fk3,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                ),
              ),
              Pinned.fromPins(
                Pin(start: 55.5, end: 54.5),
                Pin(start: 0.0, end: 12.7),
                child: XDComponent21(),
              ),
              Pinned.fromPins(
                Pin(size: 11.0, middle: 0.5986),
                Pin(size: 10.0, start: 6.4),
                child:
                    // Adobe XD layer: 'blob (1)' (shape)
                    SvgPicture.string(
                  _svg_fkszhc,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                ),
              ),
              Pinned.fromPins(
                Pin(start: 0.0, end: 0.0),
                Pin(size: 1.0, end: 80.7),
                child: SvgPicture.string(
                  _svg_kwfwlz,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

const String _svg_ij8fk3 =
    '<svg viewBox="5.5 91.7 332.0 1.0" ><path transform="translate(5.5, 91.67)" d="M 0 0 L 332 0" fill="none" stroke="#111973" stroke-width="1" stroke-dasharray="4 4" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_fkszhc =
    '<svg viewBox="197.7 16.4 11.0 10.0" ><path transform="translate(266.97, 73.08)" d="M -58.43007659912109 -53.63473510742188 C -57.91089630126953 -51.89844512939453 -59.10246276855469 -49.74510192871094 -60.99195098876953 -48.31522369384766 C -62.88995361328125 -46.88533782958984 -65.47736358642578 -46.17039489746094 -67.20514678955078 -47.27685546875 C -68.93292236328125 -48.3833122253418 -69.80107116699219 -51.3111686706543 -69.01803588867188 -53.40493011474609 C -68.24352264404297 -55.49017715454102 -65.82632446289062 -56.7413215637207 -63.50276184082031 -56.70727920532227 C -61.17919921875 -56.6817512512207 -58.94926452636719 -55.37102127075195 -58.43007659912109 -53.63473510742188 Z" fill="#ffffff" stroke="#707070" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_kwfwlz =
    '<svg viewBox="5.5 10.0 332.0 1.0" ><path transform="translate(5.5, 10.0)" d="M 0 0 L 332 0" fill="none" stroke="#111973" stroke-width="1" stroke-dasharray="4 4" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
