import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xdlabel.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDGooglePixel4HOME2 extends StatelessWidget {
  XDGooglePixel4HOME2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -1.0, end: 0.0),
            Pin(start: 0.0, end: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 199.0, middle: 0.4977),
            Pin(size: 71.0, middle: 0.2634),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 27,
                  color: const Color(0xffffffff),
                  height: 1.3333333333333333,
                ),
                children: [
                  TextSpan(
                    text: 'Hi ! Choose your\n ',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'Service Type',
                    style: TextStyle(
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 166.0, start: 15.0),
            Pin(size: 129.0, middle: 0.4467),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0x29000000),
                          offset: Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 15.0, end: 16.0),
            Pin(size: 129.0, middle: 0.4453),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 166.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.5853, endFraction: 0.021),
                  Pin(size: 52.0, middle: 0.6478),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Provider',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
                Pinned.fromPins(
                  Pin(startFraction: 0.0, endFraction: 0.5801),
                  Pin(size: 52.0, middle: 0.6478),
                  child:
                      // Adobe XD layer: 'Home' (text)
                      Text.rich(
                    TextSpan(
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 18,
                        color: const Color(0xffff7f00),
                      ),
                      children: [
                        TextSpan(
                          text: 'I wanna be\n',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        TextSpan(
                          text: ' Service Recipient',
                          style: TextStyle(
                            color: const Color(0xff2f2f2f),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, start: 25.0),
            Pin(size: 2.0, middle: 0.4309),
            child: SvgPicture.string(
              _svg_htsbzs,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 23.3, end: 18.8),
            Pin(size: 81.7, start: 97.3),
            child: XDLABEL(),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 23.0),
            Pin(size: 12.0, middle: 0.6737),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: const Color(0xffff7f00),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, middle: 0.5),
            Pin(size: 50.0, end: 55.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Button' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25.0),
                      color: const Color(0xff053f5e),
                      border: Border.all(width: 2.0, color: const Color(0xffffffff)),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 56.0, middle: 0.5),
                  Pin(size: 14.0, middle: 0.5278),
                  child: Text(
                    'Continue',
                    style: TextStyle(
                      fontFamily: 'SF Pro Text',
                      fontSize: 14,
                      color: const Color(0xffffffff),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, end: 35.0),
            Pin(size: 2.0, middle: 0.4309),
            child: SvgPicture.string(
              _svg_n2ez8,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 324.0, start: 25.0),
            Pin(size: 196.0, middle: 0.7774),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 21,
                  color: const Color(0xff115173),
                ),
                children: [
                  TextSpan(
                    text: 'WHAT DO YOU NEED?\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Recipient: \n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text:
                        'Do you want to dry-clean your clothes \nor find the nearest ironing service\n without wasting your time?\n',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  TextSpan(
                    text: '\n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text: 'As a Service Provider: \n',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xff022c43),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: ' ',
                    style: TextStyle(
                      fontSize: 16,
                      color: const Color(0xffffffff),
                    ),
                  ),
                  TextSpan(
                    text:
                        'Are you seeking service for your dry cleaning \nor serving people by ironing from your home?',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 11.5, end: 12.5),
            Pin(size: 13.0, middle: 0.563),
            child: SvgPicture.string(
              _svg_sy6zfm,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, start: 28.0),
            Pin(size: 2.0, middle: 0.5062),
            child: SvgPicture.string(
              _svg_hjs86p,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 140.0, end: 35.0),
            Pin(size: 2.0, middle: 0.5037),
            child: SvgPicture.string(
              _svg_v3qher,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_htsbzs =
    '<svg viewBox="25.0 374.0 140.0 2.0" ><path transform="translate(23.0, 313.99)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n2ez8 =
    '<svg viewBox="237.0 374.0 140.0 2.0" ><path transform="translate(235.0, 313.99)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_sy6zfm =
    '<svg viewBox="11.5 482.5 388.0 13.0" ><path transform="translate(9.5, 422.47)" d="M 383.5332946777344 73.01165771484375 L 8.466667175292969 73.01165771484375 C 4.895225524902344 73.01165771484375 1.999999761581421 70.09886932373047 1.999999761581421 66.50578308105469 C 1.999999761581421 62.91275787353516 4.895225524902344 60 8.466667175292969 60 L 383.5332946777344 60 C 387.1047668457031 60 389.9999694824219 62.91275787353516 389.9999694824219 66.50578308105469 C 389.9999694824219 70.09886932373047 387.1047668457031 73.01165771484375 383.5332946777344 73.01165771484375 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hjs86p =
    '<svg viewBox="28.0 439.4 140.0 2.0" ><path transform="translate(26.0, 379.36)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_v3qher =
    '<svg viewBox="237.0 437.2 140.0 2.0" ><path transform="translate(235.0, 377.21)" d="M 139.6666717529297 62.00000381469727 L 4.333333969116211 62.00000381469727 C 3.044669151306152 62.00000381469727 2 61.55228424072266 2 61 C 2 60.44771957397461 3.044669151306152 60.00000381469727 4.333333969116211 60.00000381469727 L 139.6666717529297 60.00000381469727 C 140.9553375244141 60.00000381469727 142.0000152587891 60.44771957397461 142.0000152587891 61 C 142.0000152587891 61.55228424072266 140.9553375244141 62.00000381469727 139.6666717529297 62.00000381469727 Z" fill="#333333" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
