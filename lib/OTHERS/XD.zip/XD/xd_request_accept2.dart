import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component41.dart';
import 'xd_request_accept3.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDRequestAccept2 extends StatelessWidget {
  XDRequestAccept2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -33.0, end: -425.0),
            Pin(size: 431.0, start: 98.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 99.0, start: 0.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, start: 0.0),
            child:
                // Adobe XD layer: 'Status Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'bg' (shape)
                      SvgPicture.string(
                    _svg_mhz2ca,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 24.0, end: 23.0),
            Pin(size: 69.2, middle: 0.1939),
            child: SvgPicture.string(
              _svg_ls1dav,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 223.0, start: 33.0),
            Pin(size: 45.0, middle: 0.2216),
            child: Text(
              'Sultantepe, 34674 Üsküdar/İstanbul\n',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: const Color(0xff383838),
                height: 1.8571428571428572,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 12.0, start: 33.0),
            Pin(size: 12.0, middle: 0.1925),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffff7f00),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x29000000),
                    offset: Offset(0, 1),
                    blurRadius: 3,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 52.0, start: 51.0),
            Pin(size: 16.0, middle: 0.191),
            child: Text(
              'Service at',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                color: const Color(0x99383838),
                height: 2.1666666666666665,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 1.0, middle: 0.5027),
            Pin(size: 116.0, middle: 0.3147),
            child: SvgPicture.string(
              _svg_bozojd,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 44.0, start: 44.0),
            child: XDComponent41(),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 283.0, end: 0.0),
            child: SvgPicture.string(
              _svg_u8359,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 84.0, end: 0.0),
            child:
                // Adobe XD layer: 'BG' (shape)
                SvgPicture.string(
              _svg_o4yqo0,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, end: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Primary Button - Sm…' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => XDRequestAccept3(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.0),
                        color: const Color(0xffff7f00),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 20.0, end: 20.0),
                    Pin(size: 14.0, middle: 0.5278),
                    child: Text(
                      'Rate For Service',
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 14,
                        color: const Color(0xffffffff),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 146.0, start: 30.0),
            Pin(size: 50.0, end: 17.0),
            child:
                // Adobe XD layer: 'Button' (shape)
                Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25.0),
                border: Border.all(width: 2.0, color: const Color(0xffffffff)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 32.0, middle: 0.2536),
            Pin(size: 14.0, end: 34.0),
            child: Text(
              'Later',
              style: TextStyle(
                fontFamily: 'SF Pro Text',
                fontSize: 14,
                color: const Color(0xffffffff),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 180.0, middle: 0.5026),
            Pin(size: 34.0, middle: 0.8059),
            child: Text(
              'Hızır Ali Karayel',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 26,
                color: const Color(0xffff7f00),
                height: 1.3846153846153846,
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 174.0, middle: 0.4975),
            Pin(size: 25.0, middle: 0.7433),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 13,
                  color: const Color(0xffffffff),
                ),
                children: [
                  TextSpan(
                    text: 'How was your Job ? ',
                    style: TextStyle(
                      fontSize: 19,
                    ),
                  ),
                ],
              ),
              textHeightBehavior: TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.left,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 195.4, middle: 0.501),
            Pin(size: 27.0, end: 106.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 28.4, start: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_z8cvms,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 28.4, middle: 0.2515),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_nkh4s4,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 28.4, middle: 0.503),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_w1pr7w,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 28.4, middle: 0.7485),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_frd4hg,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 28.4, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'star' (shape)
                      SvgPicture.string(
                    _svg_nkyc5,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 40.0, middle: 0.5015),
            Pin(size: 40.0, middle: 0.4067),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ls1dav =
    '<svg viewBox="24.0 144.0 328.0 69.2" ><defs><filter id="shadow"><feDropShadow dx="0" dy="3" stdDeviation="6"/></filter></defs><path transform="translate(1282.0, 144.0)" d="M -1106.000122070312 55.99980163574219 L -1251.999877929688 55.99980163574219 C -1255.313720703125 55.99980163574219 -1258.000244140625 53.31330108642578 -1258.000244140625 50.00040054321289 L -1258.000244140625 6.00029993057251 C -1258.000244140625 2.686500072479248 -1255.313720703125 0 -1251.999877929688 0 L -936 0 C -932.6862182617188 0 -929.9996948242188 2.686500072479248 -929.9996948242188 6.00029993057251 L -929.9996948242188 50.00040054321289 C -929.9996948242188 53.31330108642578 -932.6862182617188 55.99980163574219 -936 55.99980163574219 L -1081.999877929688 55.99980163574219 L -1094.499877929688 69.24960327148438 L -1106.000122070312 55.99980163574219 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_bozojd =
    '<svg viewBox="188.0 219.0 1.0 116.0" ><path transform="translate(188.0, 219.0)" d="M 0 0 L 0 116" fill="none" stroke="#022c43" stroke-width="2" stroke-dasharray="4 9" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_u8359 =
    '<svg viewBox="0.0 529.0 375.0 283.0" ><defs><filter id="shadow"><feDropShadow dx="0" dy="-5" stdDeviation="12"/></filter></defs><path transform="translate(0.0, 529.0)" d="M 18 0 L 359 0 C 367.8365478515625 0 375 7.163443565368652 375 16 L 375 283 L 0 283 L 0 16 C 0 7.163443565368652 9.163443565368652 0 18 0 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" filter="url(#shadow)"/></svg>';
const String _svg_o4yqo0 =
    '<svg viewBox="0.0 728.0 375.0 84.0" ><path transform="translate(0.0, 772.0)" d="M 0 -43.99999618530273 L 375 -43.99999618530273 L 375 40.00000381469727 L 0 40.00000381469727 L 0 -43.99999618530273 Z" fill="#022c43" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_z8cvms =
    '<svg viewBox="82.0 652.0 28.4 27.0" ><path transform="translate(82.0, 650.68)" d="M 14.17726421356201 1.318000078201294 L 18.5577220916748 10.1947135925293 L 28.35400390625 11.61854553222656 L 21.26537132263184 18.52768516540527 L 22.9387035369873 28.28449058532715 L 14.17726421356201 23.67822074890137 L 5.415299892425537 28.28449058532715 L 7.088632106781006 18.52768516540527 L 0 11.61854553222656 L 9.796282768249512 10.1947135925293 L 14.17726421356201 1.318000078201294 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nkh4s4 =
    '<svg viewBox="124.0 652.0 28.4 27.0" ><path transform="translate(124.0, 650.68)" d="M 14.17726421356201 1.318000078201294 L 18.5577220916748 10.1947135925293 L 28.35400390625 11.61854553222656 L 21.26537132263184 18.52768516540527 L 22.9387035369873 28.28449058532715 L 14.17726421356201 23.67822074890137 L 5.415299892425537 28.28449058532715 L 7.088632106781006 18.52768516540527 L 0 11.61854553222656 L 9.796282768249512 10.1947135925293 L 14.17726421356201 1.318000078201294 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w1pr7w =
    '<svg viewBox="166.0 652.0 28.4 27.0" ><path transform="translate(166.0, 650.68)" d="M 14.17726421356201 1.318000078201294 L 18.5577220916748 10.1947135925293 L 28.35400390625 11.61854553222656 L 21.26537132263184 18.52768516540527 L 22.9387035369873 28.28449058532715 L 14.17726421356201 23.67822074890137 L 5.415299892425537 28.28449058532715 L 7.088632106781006 18.52768516540527 L 0 11.61854553222656 L 9.796282768249512 10.1947135925293 L 14.17726421356201 1.318000078201294 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_frd4hg =
    '<svg viewBox="207.0 652.0 28.4 27.0" ><path transform="translate(207.0, 650.68)" d="M 14.17726421356201 1.318000078201294 L 18.5577220916748 10.1947135925293 L 28.35400390625 11.61854553222656 L 21.26537132263184 18.52768516540527 L 22.9387035369873 28.28449058532715 L 14.17726421356201 23.67822074890137 L 5.415299892425537 28.28449058532715 L 7.088632106781006 18.52768516540527 L 0 11.61854553222656 L 9.796282768249512 10.1947135925293 L 14.17726421356201 1.318000078201294 Z" fill="#efce4a" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nkyc5 =
    '<svg viewBox="249.0 652.0 28.4 27.0" ><path transform="translate(249.0, 650.68)" d="M 14.17726421356201 1.318000078201294 L 18.5577220916748 10.1947135925293 L 28.35400390625 11.61854553222656 L 21.26537132263184 18.52768516540527 L 22.9387035369873 28.28449058532715 L 14.17726421356201 23.67822074890137 L 5.415299892425537 28.28449058532715 L 7.088632106781006 18.52768516540527 L 0 11.61854553222656 L 9.796282768249512 10.1947135925293 L 14.17726421356201 1.318000078201294 Z" fill="#a4a4a4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
