import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'xd_component21.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDgettidylabelup extends StatelessWidget {
  XDgettidylabelup({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Pinned.fromPins(
          Pin(start: 5.5, end: 0.0),
          Pin(size: 1.0, end: -1.0),
          child: SvgPicture.string(
            _svg_q63z5t,
            allowDrawingOutsideViewBox: true,
            fit: BoxFit.fill,
          ),
        ),
        Pinned.fromPins(
          Pin(start: 0.0, end: 39.5),
          Pin(size: 67.0, start: 0.0),
          child: Stack(
            children: <Widget>[
              Pinned.fromPins(
                Pin(size: 209.0, end: 0.0),
                Pin(start: 1.0, end: 0.0),
                child: Stack(
                  children: <Widget>[
                    Pinned.fromPins(
                      Pin(start: 0.0, end: 0.0),
                      Pin(start: 0.0, end: 0.0),
                      child: XDComponent21(),
                    ),
                    Pinned.fromPins(
                      Pin(size: 9.4, middle: 0.5094),
                      Pin(size: 8.5, start: 5.4),
                      child:
                          // Adobe XD layer: 'blob (1)' (shape)
                          SvgPicture.string(
                        _svg_y89p,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      ),
                    ),
                  ],
                ),
              ),
              Container(),
            ],
          ),
        ),
      ],
    );
  }
}

const String _svg_y89p =
    '<svg viewBox="101.8 5.3 9.4 8.5" ><path transform="translate(171.1, 62.01)" d="M -59.98715591430664 -54.07463455200195 C -59.54228591918945 -52.58687591552734 -60.56329345703125 -50.74176406860352 -62.18232345581055 -49.51655578613281 C -63.80864715576172 -48.29134368896484 -66.02569580078125 -47.67873764038086 -67.50616455078125 -48.6268196105957 C -68.98662567138672 -49.57489776611328 -69.73050689697266 -52.08366394042969 -69.05955505371094 -53.87772369384766 C -68.39590454101562 -55.66448974609375 -66.32470703125 -56.73654937744141 -64.333740234375 -56.70737838745117 C -62.34276962280273 -56.68550109863281 -60.43202209472656 -55.56239318847656 -59.98715591430664 -54.07463455200195 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_q63z5t =
    '<svg viewBox="5.5 91.7 332.0 1.0" ><path transform="translate(5.5, 91.67)" d="M 0 0 L 332 0" fill="none" stroke="#111973" stroke-width="3" stroke-dasharray="4 4" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
